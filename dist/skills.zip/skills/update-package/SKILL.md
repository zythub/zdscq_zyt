---
name: update-package
description: |
  bestdt 二次开发"现场更新包"生成器。开发完成后一键产出：分割好的 SQL（MongoDB 表单设计段 + 业务库段，
  文件名【库类型】-【表单名】.sql）+ Word 更新说明（现场执行步骤 + 本次更新内容）+ 开发记录 + 技术栈总结。
  核心接口：POST /apis/dynamic/download/data/form（formIds + targetFormCategoryId + targetDatabase，
  支持 DM / MYSQL / POSTGRESQL，默认 POSTGRESQL）；数据表 Excel 导出：
  POST /apis/dynamic/form/table/excel/export（id + fileName，页面入口 custom/data/define）。
  用于：开发收尾打更新包、导出数据表 Excel、上传 OM 系统、给现场人员发升级说明。
  关键词：更新包、打包 SQL、表单设计导出、download/data/form、MongoDB、达梦、DM、MYSQL、
  POSTGRESQL、Excel 导出、excel/export、数据定义页、custom/data/define、现场升级、开发记录、更新说明、OM、分割。
user-invocable: true
---

# update-package —— 现场更新包生成

## 触发

用户说"打更新包"、"打包 SQL 给现场"、"生成更新说明"、"这次开发完要发版"等，或开发收尾时主动提醒。

## 前置信息（缺了要问用户，**不落库**）

| 参数 | 说明 |
| :--- | :--- |
| host | 环境地址（如 `http://<ip>:<port>`，每次由使用者提供） |
| token | 登录后 `localStorage.access_token` |
| formIds | 本次开发涉及的表单 formId，**可多个**（逗号分隔） |
| targetFormCategoryId | **自动抓取**（表单记录里的 `dyFormCategoryId` 字段；也可手动传） |
| targetDatabase | `POSTGRESQL`（默认）/ `MYSQL` / `DM` |
| excelTables（可选） | 要一并导出 Excel 的**数据表**：`表单id:表名`，多个用英文逗号分隔（如 `e8bcde…:tud_tzsbtz`） |

## 工作目录约定

`D:\zyt\工作文件\prp2.0\<更新名>\`（如 `2026年10月10日新增预警数据`），不存在则创建：

```
<更新名>/
├── 开发记录.md        ← 本次改了什么：新增/修改的表单、视图、字段、接口、脚本、事件代码
├── 技术栈总结.md       ← 本次用到的技术/技巧（累积，之后择优进知识库）
└── 更新包/            ← 交付物（可整体上传 OM）
    ├── 原始下载.sql
    ├── 【MongoDB】-【表单名,表单名】.sql
    ├── 【DM】-【表单名,表单名】.sql          （按所选 targetDatabase 命名）
    ├── Excel/                               ← 数据表 Excel 导出（如有）
    │   └── tud_tzsbtz.xlsx
    └── 更新说明.docx
```

## 流程

### 1. 建工作目录
按上面结构创建；`开发记录.md` 先写骨架（更新名 / 日期 / 涉及表单 / 变更清单），随开发补充。

### 2. 下载打包 SQL
```bash
python <skill目录>/scripts/download_form_sql.py \
  --host <host> --token <token> \
  --form-ids "<id1>,<id2>" \
  --database POSTGRESQL \
  --out "<更新名>/更新包/原始下载.sql"
```
- **树 id 不用问用户**：脚本按 formId 调 `GET /apis/dynamic/form/attribute/{formId}` 自动抓
  `dyFormCategoryId`；跨多个分类时会按分类分组分别下载（文件名自动加 -1/-2）。
- 响应是**一个 sql 文本文件**（浏览器下载同款）。若文件头像 JSON（`{` 开头），多半是报错/token 过期，检查后重试。
- 换数据库类型 = 换 `--database` 再下载一次。

### 2b. 导出数据表 Excel（可选）
本次开发涉及**数据表数据导出**时做（页面同款操作在 custom/data/define 数据定义页）：
```bash
python <skill目录>/scripts/download_table_excel.py \
  --host <host> --token <token> \
  --form-id <表单id> \
  --table <数据表名，如 tud_tzsbtz> \
  --out "<更新名>/更新包/Excel/<数据表名>.xlsx"
```
- 接口：`POST /apis/dynamic/form/table/excel/export`，body `{"id":"<formId>","fileName":"<数据表名>"}`。
- 多个表 = 多次调用（每个表一条）；响应是 xlsx 二进制，返回 JSON = 报错/token 过期。
- 产出放 `更新包/Excel/`，随更新包整体上传 OM。

### 3. 收集开发内容
问用户（或读开发记录）：新增/修改了哪些表单、视图、字段、接口、脚本、事件代码；
对现场的影响（要不要先备份数据、有没有数据迁移）。

### 4. 分割 + 生成更新说明
```bash
python <skill目录>/scripts/pack_update.py \
  --sql "<更新名>/更新包/原始下载.sql" \
  --forms "<表单名1>,<表单名2>" \
  --out-dir "<更新名>/更新包" \
  --notes-file "<更新名>/开发记录.md"
```
- 按分隔行 `<------ 【MongoDB】 ------>`、`<------ 【DM】 ------>` 等自动分割；
  每段输出 `【段名】-【表单名,表单名】.sql`（表单名多个用英文逗号分隔）。
- 同时生成 `更新说明.docx`（现场执行步骤 + 本次更新内容；未装 python-docx 时降级为 .md）。

### 5. 技术栈总结
把本次用到的技巧写进 `技术栈总结.md`（追加式）：用了什么接口/工具/踩了什么坑。
攒到一定量，择优整理进知识库 `01-自定义开发`。

### 6. 校验与交付
- 分割出的 .sql 数量 = 原始文件里的分段标记数（MongoDB 段 + 业务库段）；
- 文件名格式核对：`【库类型】-【表单名】.sql`；
- 提醒用户：更新包目录可整体上传 OM 系统。

## SQL 文件内容说明

- **【MongoDB】 段**：表单设计相关数据（表单 JSON、字段、事件、按钮等，存 MongoDB 集合）——
  换库不影响这段，**任何数据库类型的更新包里都含它**。
- **【DM】/【MYSQL】/【POSTGRESQL】 段**：所选业务库的配套 SQL（建表/改表/元数据）。
- 段的具体集合名/表名以实际文件为准；发现新结构记得回填本说明与知识库。

## 硬性约定

- 环境地址与 token **不写进任何文档与记录**（脚本参数传入，用完即弃）。
- SQL 文件**不做任何内容修改**，只做分割与命名。
- 更新说明必须写"先备份、先 MongoDB 后业务库、执行后重新发布表单"三件事。

## 自定义表单批量配置 · 打包与上传（知识库内容并入）

原知识库里单列的《批量配置与自动化》《表单打包导出 SQL》已并入本技能包，知识库不再单独列文件：

- `references/自定义表单批量配置.md` —— 给大量表单批量注入「创建后」编号事件、清理旧回填、批量回归测试；批量操作遵循 dry → one → all。
- `references/表单打包导出SQL.md` —— 把表单设计（字段/事件/按钮/布局）导出成 SQL，用于现场更新包；环境地址与 token 每次单独提供。

### 打包技能包

`dist/skills.zip` 由 `.workbuddy/gen-skills-zip.py` 生成，包含 `.claude/skills/` 下全部对外技能（12 个），
供发布页面「下载技能包」按钮使用。改完任一技能后重跑：

```
python .workbuddy/gen-skills-zip.py
```

### 上传 / 发布

发布产物在 `dist/`（`index.html` 离线手册 + `skills.zip` + `tools/`），应用标识 `.wbapp_*.genie` 复用既有 locator，
**不重复新建应用**；更新后重新发布 `dist/` 即可让在线链接与技能包同步生效。

### 归属

批量配置、打包、上传的方法只写在本技能包；知识库 `自定义表单配置方法/总览.md` 只作入口引用，不复述细节。

## 达梦 SQL 交付规范与工具（知识库「工具/」并入）

原知识库顶层 `工具/` 已删除，内容全部并入本技能包，通用、不绑定项目：

- `references/达梦SQL交付规范.md` —— VARCHAR 按字节、ALTER/CREATE 幂等写法、时间列格式、幂等去重；交付前必读。
- `scripts/dm_sql_lint.py` —— 字节级静态体检：逐值校验列名/长度/时间格式/类型/值个数，0 问题才交付。
- `scripts/dm_schema_snapshot.py` —— 导出现网表结构快照，给建表 DDL 提供真实列定义。

用法：拿到待交付 SQL 后先跑 `dm_sql_lint.py`，再按本技能流程打包；换环境只给 host + token，不落库。
