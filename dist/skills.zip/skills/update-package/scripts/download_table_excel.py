#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""导出自定义表单数据表为 Excel（页面入口：custom/data/define 数据定义页的导出操作）。
POST {host}/apis/dynamic/form/table/excel/export
body: {"id":"<formId>", "fileName":"<数据表名>"}

响应为 xlsx 文件二进制（浏览器下载同款）；若返回 JSON 说明报错/token 过期。
"""
import argparse, json, os, ssl, sys, urllib.request

CTX = ssl.create_default_context()
CTX.check_hostname = False
CTX.verify_mode = ssl.CERT_NONE  # 现场自签 https 兜底

def export_excel(host, token, form_id, table_name, out):
    body = json.dumps({'id': form_id, 'fileName': table_name}).encode('utf-8')
    req = urllib.request.Request(
        host.rstrip('/') + '/apis/dynamic/form/table/excel/export',
        data=body, method='POST', headers={
            'Authorization': 'Bearer ' + token,
            'Content-Type': 'application/json',
            'User-Agent': 'update-package/1.2',
        })
    with urllib.request.urlopen(req, context=CTX, timeout=300) as r:
        data = r.read()
        ctype = r.headers.get('Content-Type', '')

    # 报错甄别：JSON 响应 = 失败（xlsx 是二进制，不会以 { 开头）
    head = data[:200].lstrip()
    if head.startswith(b'{'):
        try:
            err = json.loads(data.decode('utf-8', errors='replace'))
            msg = err.get('msg') or err.get('message') or json.dumps(err, ensure_ascii=False)
        except Exception:
            msg = data[:300].decode('utf-8', errors='replace')
        sys.exit('FAIL: 接口返回 JSON（疑似报错/token 过期/参数错误）：%s' % msg[:400])

    os.makedirs(os.path.dirname(os.path.abspath(out)) or '.', exist_ok=True)
    with open(out, 'wb') as f:
        f.write(data)
    print('saved:', out, '(%d bytes, %s)' % (len(data), ctype))
    # xlsx 实锤校验：PK 魔数
    if not data[:2] == b'PK':
        print('⚠️ 文件头不是 PK（xlsx 魔数），请人工核对文件内容')

def main():
    ap = argparse.ArgumentParser(description='导出自定义表单数据表为 Excel')
    ap.add_argument('--host', required=True, help='环境地址（每次单独提供，不落库）')
    ap.add_argument('--token', required=True, help='Bearer token（localStorage.access_token）')
    ap.add_argument('--form-id', required=True, help='表单 formId（数据定义页那条数据的 id）')
    ap.add_argument('--table', required=True, help='数据表名（即 body 里的 fileName，如 tud_tzsbtz）')
    ap.add_argument('--out', required=True, help='输出 xlsx 路径（更新包里建议放 更新包/Excel/）')
    a = ap.parse_args()

    out = a.out
    if not out.lower().endswith('.xlsx'):
        out += '.xlsx'
    export_excel(a.host, a.token, a.form_id, a.table, out)

if __name__ == '__main__':
    main()
