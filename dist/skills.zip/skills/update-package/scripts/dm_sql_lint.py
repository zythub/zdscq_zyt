# -*- coding: utf-8 -*-
"""达梦 SQL 静态体检器：对任意 .sql 文件里的 INSERT 语句逐值校验。
校验项（对应达梦真实报错码）：
  -2111 无效列名   → 列名必须存在于表
  -6169 列长度超出 → VARCHAR(n) 按【字节】算，UTF-8 汉字 3 字节
  -6118 非法时间日期 → TIMESTAMP/DATE 列的值必须可解析
  类型错配         → BIT 只收 0/1，INT/BIGINT 只收整数
  值数不符         → VALUES 里值的个数必须等于列数
用法: python dm_sql_lint.py <file.sql> [更多文件...]
"""
import re
import sys
import io
import datetime
from dm_schema_snapshot import SCHEMA

# ---------------- SQL 值解析 ----------------

def split_top_level(s):
    """按逗号切分，忽略引号内/括号内的逗号。返回顶层片段列表。"""
    out, buf, depth, i, n = [], [], 0, 0, len(s)
    while i < n:
        ch = s[i]
        if ch == "'":
            buf.append(ch)
            i += 1
            while i < n:
                buf.append(s[i])
                if s[i] == "'":
                    if i + 1 < n and s[i + 1] == "'":
                        buf.append(s[i + 1])
                        i += 2
                        continue
                    i += 1
                    break
                i += 1
            continue
        if ch == '"':
            buf.append(ch)
            i += 1
            while i < n:
                buf.append(s[i])
                if s[i] == '"':
                    i += 1
                    break
                i += 1
            continue
        if ch == '(':
            depth += 1
        elif ch == ')':
            depth -= 1
        if ch == ',' and depth == 0:
            out.append("".join(buf).strip())
            buf = []
            i += 1
            continue
        buf.append(ch)
        i += 1
    if buf:
        out.append("".join(buf).strip())
    return out


def parse_value(tok):
    """返回 (kind, value)。kind: str/num/null/expr"""
    t = tok.strip()
    if t.upper() == "NULL":
        return ("null", None)
    if len(t) >= 2 and t[0] == "'" and t[-1] == "'":
        return ("str", t[1:-1].replace("''", "'"))
    if re.fullmatch(r"[-+]?\d+", t):
        return ("num", int(t))
    if re.fullmatch(r"[-+]?\d*\.\d+", t):
        return ("num", float(t))
    return ("expr", t)


# ---------------- 值校验 ----------------

TS_FORMATS = (
    "%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d",
    "%Y/%m/%d %H:%M:%S", "%Y/%m/%d", "%Y%m%d%H%M%S", "%Y%m%d",
)


def check_datetime(v):
    s = v.strip()
    for f in TS_FORMATS:
        try:
            datetime.datetime.strptime(s, f)
            return True
        except ValueError:
            continue
    return False


def lint_insert(table, cols, vals, line_no, errs):
    t = table.upper()
    if t not in SCHEMA:
        errs.append((line_no, "表 %s 不在列定义快照里，跳过（未知表）" % table))
        return
    tcols = SCHEMA[t]

    if len(cols) != len(vals):
        errs.append((line_no, "-4024 个数不匹配：列 %d 个，值 %d 个 → 槽位错位" %
                     (len(cols), len(vals))))

    # 重复列名检查（达梦会报 -4024 / 列名重复）
    seen = {}
    for col in cols:
        cu = col.strip().upper()
        seen[cu] = seen.get(cu, 0) + 1
    for cu, n in seen.items():
        if n > 1:
            errs.append((line_no, "-4024 列名重复：%s 出现了 %d 次（列清单里已有，VALUES 末尾又拼了一次）" %
                         (cu, n)))

    for col, raw in zip(cols, vals):
        cu = col.strip().upper()
        if cu not in tcols:
            errs.append((line_no, "-2111 无效列名[%s]（表 %s 无此列）" % (col, table)))
            continue
        dtype, dlen = tcols[cu]
        kind, v = parse_value(raw)
        if kind == "null":
            continue
        if dtype == "VARCHAR":
            if kind == "str":
                blen = len(v.encode("utf-8"))
                if blen > dlen:
                    errs.append((line_no, "-6169 列[%s] 字节长度 %d > 定义 %d → 值=%r" %
                                 (col, blen, dlen, v)))
            elif kind == "num":
                errs.append((line_no, "列[%s] 是 VARCHAR(%d)，却给了数字" % (col, dlen)))
        elif dtype in ("TIMESTAMP", "DATE"):
            if kind == "str":
                if not check_datetime(v):
                    errs.append((line_no, "-6118 非法时间日期：列[%s] 值=%r" % (col, v)))
            elif kind == "num":
                errs.append((line_no, "列[%s] 是 %s，却给了数字 %s" % (col, dtype, v)))
        elif dtype in ("INT", "BIGINT", "TINYINT"):
            if kind == "num":
                if isinstance(v, float) and v != int(v):
                    errs.append((line_no, "列[%s] 是 %s，值 %s 非整数" % (col, dtype, v)))
                elif dtype == "TINYINT" and not (0 <= v <= 1):
                    errs.append((line_no, "列[%s] 是 TINYINT(1)，值 %s 越界" % (col, v)))
            elif kind == "str":
                if not re.fullmatch(r"[-+]?\d+", v.strip()):
                    errs.append((line_no, "列[%s] 是 %s，却给了字符串 %r" % (col, dtype, v)))
        elif dtype == "BIT":
            if kind == "str":
                errs.append((line_no, "列[%s] 是 BIT，却给了字符串 %r（BIT 只能 0/1）" % (col, v)))
            elif kind == "num" and v not in (0, 1):
                errs.append((line_no, "列[%s] 是 BIT，值 %s 越界" % (col, v)))


# ---------------- 主流程 ----------------

CREATE_RE = re.compile(
    r"^\s*CREATE\s+TABLE\s+([A-Za-z_][\w$]*)\s*\((.*)\)\s*$", re.I | re.S)


def split_statements(text):
    """把 SQL 文本切成语句列表：(语句文本, 起始行号)。尊重引号内的分号。"""
    stmts, buf, i, n = [], [], 0, len(text)
    start_line = 1
    line = 1
    while i < n:
        ch = text[i]
        if ch == "'":
            buf.append(ch)
            i += 1
            while i < n:
                buf.append(text[i])
                if text[i] == "'":
                    if i + 1 < n and text[i + 1] == "'":
                        buf.append(text[i + 1])
                        i += 2
                        continue
                    i += 1
                    break
                if text[i] == "\n":
                    line += 1
                i += 1
            continue
        if ch == '"':
            buf.append(ch)
            i += 1
            while i < n:
                buf.append(text[i])
                if text[i] == '"':
                    i += 1
                    break
                if text[i] == "\n":
                    line += 1
                i += 1
            continue
        if ch == "-" and i + 1 < n and text[i + 1] == "-":
            while i < n and text[i] != "\n":
                i += 1
            continue
        if ch == "/" and i + 1 < n and text[i + 1] == "*":
            i += 2
            while i + 1 < n and not (text[i] == "*" and text[i + 1] == "/"):
                if text[i] == "\n":
                    line += 1
                i += 1
            i += 2
            continue
        if ch == ";":
            stmts.append(("".join(buf), start_line))
            buf = []
            i += 1
            while i < n and text[i] in " \t\r\n":
                if text[i] == "\n":
                    line += 1
                i += 1
            start_line = line
            continue
        if ch == "\n":
            line += 1
        buf.append(ch)
        i += 1
    if "".join(buf).strip():
        stmts.append(("".join(buf), start_line))
    return stmts


INSERT_RE = re.compile(
    r"^\s*/?\s*INSERT\s+INTO\s+([A-Za-z_][\w$]*)\s*\((.*)\)\s*VALUES\s*\((.*)\)\s*$",
    re.I | re.S)


def lint_file(path):
    errs = []
    with io.open(path, encoding="utf-8") as f:
        text = f.read()

    stmts = split_statements(text)

    # 1) 建表 DDL：校验 DDL 里的列宽是不是比真实表小（新建表才对）
    for stmt, line_no in stmts:
        m = CREATE_RE.match(stmt)
        if not m:
            continue
        tname, body = m.group(1), m.group(2)
        tu = tname.upper()
        if tu not in SCHEMA:
            continue
        for row in body.split("\n"):
            row = row.strip().rstrip(",")
            mm = re.match(r"^(\w+)\s+(VARCHAR\(\d+\)|TIMESTAMP|BIT|INT|BIGINT|DATE|TINYINT)", row, re.I)
            if not mm:
                continue
            col, typ = mm.group(1), mm.group(2).upper()
            cu = col.upper()
            if cu not in SCHEMA[tu]:
                errs.append((line_no, "DDL 列[%s] 不在真实表 %s 里" % (col, tname)))
                continue
            rtype, rlen = SCHEMA[tu][cu]
            if rtype == "VARCHAR" and typ.startswith("VARCHAR"):
                dlen = int(re.search(r"\((\d+)\)", typ).group(1))
                if dlen < rlen:
                    errs.append((line_no, "DDL 列[%s] VARCHAR(%d) 比真实表窄(VARCHAR(%d)) → 装不下中文" %
                                 (col, dlen, rlen)))

    # 2) INSERT 逐值校验
    n_ins = 0
    for stmt, line_no in stmts:
        m = INSERT_RE.match(stmt)
        if not m:
            continue
        n_ins += 1
        table = m.group(1)
        cols = split_top_level(m.group(2))
        vals = split_top_level(m.group(3))
        lint_insert(table, cols, vals, line_no, errs)

    return n_ins, errs


def main():
    files = sys.argv[1:]
    if not files:
        print("用法: python dm_sql_lint.py <file.sql> [...]")
        return 1
    total_bad = 0
    for path in files:
        n_ins, errs = lint_file(path)
        print("=" * 70)
        print("文件: %s" % path)
        print("INSERT 语句: %d 条" % n_ins)
        if not errs:
            print("✅ 全部通过：列名/字节长度/类型/时间格式/槽位 均无问题")
        else:
            print("❌ 发现 %d 个问题：" % len(errs))
            for ln, e in errs:
                print("   第 %d 行  %s" % (ln, e))
            total_bad += len(errs)
    print("=" * 70)
    print("合计问题: %d" % total_bad)
    return 1 if total_bad else 0


if __name__ == "__main__":
    sys.exit(main())
