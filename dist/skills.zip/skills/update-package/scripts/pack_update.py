#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""分割打包 SQL 并生成现场更新说明。
输入：download_form_sql.py 下载的原始 sql 文件
输出：每段一个 【段名】-【表单名】.sql + 更新说明.docx（未装 python-docx 时降级 .md）
分隔行形如： <---------------------------------------- 【MongoDB】 ---------------------------------------->
"""
import argparse, datetime, os, re, sys

MARKER = re.compile(r'^<\s*-{6,}\s*【(.+?)】\s*-{6,}>\s*$')

def split_sql(text):
    """按分隔行切段，返回 [(段名, 文本)]；分隔行之前的内容归 '文件头'（若有）。"""
    sections, cur_name, cur = [], '文件头', []
    for line in text.splitlines():
        m = MARKER.match(line.strip())
        if m:
            if ''.join(cur).strip():
                sections.append((cur_name, '\n'.join(cur).strip('\n') + '\n'))
            cur_name, cur = m.group(1).strip(), []
        else:
            cur.append(line)
    if ''.join(cur).strip():
        sections.append((cur_name, '\n'.join(cur).strip('\n') + '\n'))
    return sections

def notes_text(path):
    if not path or not os.path.exists(path):
        return ''
    return open(path, encoding='utf-8').read().strip()

def write_docx(out, forms, date, body):
    try:
        from docx import Document
    except ImportError:
        alt = out[:-5] + '.md'
        with open(alt, 'w', encoding='utf-8') as f:
            f.write(body)
        print('⚠️ 未装 python-docx（pip install python-docx），已降级输出', alt)
        return alt
    doc = Document()
    doc.add_heading('更新说明（%s）' % date, 0)
    doc.add_heading('一、本次更新内容', level=1)
    for line in body.splitlines():
        if line.strip():
            doc.add_paragraph(line.strip().lstrip('# ').strip())
    doc.add_heading('二、涉及表单', level=1)
    doc.add_paragraph(forms)
    doc.add_heading('三、现场执行步骤', level=1)
    for s in [
        '1. 执行前备份：完整备份业务数据库与 MongoDB（表单设计数据存 MongoDB）。',
        '2. 按现场数据库类型选文件：【DM】=达梦、【MYSQL】=MySQL、【POSTGRESQL】=PostgreSQL/GaussDB。文件名已标明，禁止跨库执行。',
        '3. 先执行 【MongoDB】 段文件（导入表单设计数据），再执行业务库段文件。',
        '4. 执行完成后在平台重新发布本次更新的表单（表单发布 → 勾选涉及表单）。',
        '5. 清浏览器缓存后验证：打开涉及表单，对照更新内容逐项核对。',
    ]:
        doc.add_paragraph(s)
    doc.add_heading('四、注意事项', level=1)
    for s in ['执行顺序不可颠倒（先 MongoDB 后业务库）。',
              '如执行报错，停止执行并联系开发，不要反复重试。',
              '本更新包由开发生成于 %s，问题反馈请附本说明与执行截图。' % date]:
        doc.add_paragraph(s)
    doc.save(out)
    return out

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--sql', required=True, help='download_form_sql.py 下载的原始 sql 文件')
    ap.add_argument('--forms', required=True, help='本次更新的表单名，多个用英文逗号分隔（用于文件名）')
    ap.add_argument('--out-dir', required=True, help='更新包目录')
    ap.add_argument('--notes-file', help='更新内容说明（开发记录.md 等），写入更新说明第一节')
    ap.add_argument('--date', default=datetime.date.today().strftime('%Y-%m-%d'))
    a = ap.parse_args()

    if not os.path.exists(a.sql):
        sys.exit('FAIL: 找不到 %s' % a.sql)
    text = open(a.sql, encoding='utf-8', errors='replace').read()
    sections = split_sql(text)
    real = [s for s in sections if s[0] != '文件头']
    if not real:
        sys.exit('FAIL: 没找到任何分段标记（<--- 【段名】 --->），原始文件格式可能变了，人工检查')
    os.makedirs(a.out_dir, exist_ok=True)

    print('分割结果：%d 段' % len(real))
    for label, content in real:
        out = os.path.join(a.out_dir, '【%s】-【%s】.sql' % (label, a.forms))
        with open(out, 'w', encoding='utf-8') as f:
            f.write(content)
        print('  [OK]', os.path.basename(out), '(%d chars)' % len(content))

    body = notes_text(a.notes_file) or '（开发未填更新内容，请补开发记录）'
    docx = write_docx(os.path.join(a.out_dir, '更新说明.docx'), a.forms, a.date, body)
    print('更新说明:', docx)
    print('更新包就绪：%s' % a.out_dir)

if __name__ == '__main__':
    main()
