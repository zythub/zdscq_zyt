#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""下载自定义表单打包 SQL。
POST {host}/apis/dynamic/download/data/form
body: {"formIds":[...], "targetFormCategoryId":"<树id>", "targetDatabase":"POSTGRESQL|MYSQL|DM"}

targetFormCategoryId 可自动获取：表单记录（存 MongoDB 的 dy_form 集合）里有 dyFormCategoryId 字段，
GET {host}/apis/dynamic/form/attribute/{formId} 即返回。不传 --category-id 时按表单自动分组下载。
"""
import argparse, json, os, ssl, sys, urllib.request

CTX = ssl.create_default_context()
CTX.check_hostname = False
CTX.verify_mode = ssl.CERT_NONE  # 现场自签 https 兜底

def http_json(url, token):
    req = urllib.request.Request(url, headers={
        'Authorization': 'Bearer ' + token,
        'Content-Type': 'application/json',
    })
    with urllib.request.urlopen(req, context=CTX, timeout=60) as r:
        return json.loads(r.read().decode('utf-8'))

def get_category(host, token, form_id):
    d = http_json(host.rstrip('/') + '/apis/dynamic/form/attribute/' + form_id, token)
    dd = d.get('data') or {}
    cat = dd.get('dyFormCategoryId')
    name = dd.get('name') or form_id
    if not cat:
        sys.exit('FAIL: 表单 %s（%s）没有 dyFormCategoryId —— 表单可能不存在或 token 无效' % (form_id, name))
    return cat, name

def download(host, token, form_ids, category_id, database, out):
    body = json.dumps({
        'formIds': form_ids,
        'targetFormCategoryId': category_id,
        'targetDatabase': database,
    }).encode('utf-8')
    req = urllib.request.Request(
        host.rstrip('/') + '/apis/dynamic/download/data/form',
        data=body, method='POST', headers={
            'Authorization': 'Bearer ' + token,
            'Content-Type': 'application/json',
            'User-Agent': 'update-package/1.1',
        })
    with urllib.request.urlopen(req, context=CTX, timeout=180) as r:
        data = r.read()
        ctype = r.headers.get('Content-Type', '')
    os.makedirs(os.path.dirname(os.path.abspath(out)) or '.', exist_ok=True)
    with open(out, 'wb') as f:
        f.write(data)
    print('saved:', out, '(%d bytes, %s)' % (len(data), ctype))
    head = data[:200].lstrip()
    if head.startswith(b'{'):
        print('⚠️ 响应以 { 开头，疑似 JSON 报错或 envelope，请人工检查文件头')
    return data

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--host', required=True, help='环境地址（每次单独提供，不落库）')
    ap.add_argument('--token', required=True, help='Bearer token（localStorage.access_token）')
    ap.add_argument('--form-ids', required=True, help='表单 formId，多个用英文逗号分隔')
    ap.add_argument('--category-id', help='树 id（targetFormCategoryId）。**省略则自动抓取**')
    ap.add_argument('--database', default='POSTGRESQL', help='POSTGRESQL(默认) / MYSQL / DM')
    ap.add_argument('--out', required=True, help='输出文件；自动分组时多个输出会自动加 -N 序号')
    a = ap.parse_args()

    form_ids = [x.strip() for x in a.form_ids.split(',') if x.strip()]
    if not form_ids:
        sys.exit('FAIL: --form-ids 为空')

    if a.category_id:
        groups = [(a.category_id, form_ids)]
    else:
        cat_map = {}
        for fid in form_ids:
            cat, name = get_category(a.host, a.token, fid)
            print('auto: %s(%s) -> category %s' % (name, fid[:8], cat))
            cat_map.setdefault(cat, []).append(fid)
        groups = [(c, f) for c, f in cat_map.items()]
        if len(groups) > 1:
            print('⚠️ 表单分布在 %d 个分类下，将分别下载（一次下载只能属于一个分类）' % len(groups))

    if len(groups) == 1:
        download(a.host, a.token, groups[0][1], groups[0][0], a.database, a.out)
        return

    base, ext = os.path.splitext(a.out)
    for i, (cat, fids) in enumerate(groups, 1):
        out = '%s-%d%s' % (base, i, ext)
        print('-- 分类 %s（%d 个表单）--' % (cat, len(fids)))
        download(a.host, a.token, fids, cat, a.database, out)

if __name__ == '__main__':
    main()
