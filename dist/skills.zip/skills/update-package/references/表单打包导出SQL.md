---
type: 接口
status: 可用
created: 2026-10-10
updated: 2026-10-21
tags:
  - 自定义接口
  - 表单设计
  - 打包
  - SQL
  - MongoDB
  - 达梦
  - Excel
---

# 表单设计打包导出 SQL

> 把自定义表单的**表单设计**（字段、事件、按钮、布局等）从平台导出成 SQL，用于打现场更新包。
> ⚠️ 环境地址与 token 每次由使用者单独提供，本页一律写 `<host>`。

---

## 1. 接口

```
POST <host>/apis/dynamic/download/data/form
Authorization: Bearer <token>
Content-Type: application/json

{
  "formIds": ["50b5ddccd80f19c8f7cb3d1f6f78d3a2"],
  "targetFormCategoryId": "3fe4e6aebb80b09fc5de1b400a397305",
  "targetDatabase": "DM"
}
```

| 参数 | 说明 |
| :--- | :--- |
| `formIds` | 表单定义 id，**数组、可多个**（一次打多个表单） |
| `targetFormCategoryId` | 表单设计所在的**树 id** —— **可自动获取**，见 §1.1 |
| `targetDatabase` | 目标业务库：`POSTGRESQL`（**默认**）/ `MYSQL` / `DM` |

- 响应就是一个 **sql 文本文件**（浏览器里表现为下载）。
- 想要别的库类型 = 换 `targetDatabase` 再下载一次。

### 1.1 树 id（targetFormCategoryId）怎么来的 —— 不用点树，接口直接给

**它存在表单数据里**：`GET <host>/apis/dynamic/form/attribute/{formId}` 返回的 `data.dyFormCategoryId`
就是该表单所在的分类（树）id。

- **为什么从数据库查不到**：表单设计记录（含 `dyFormCategoryId`）存在 **MongoDB 的 `dy_form` 集合**里，
  业务库 schema 里没有这一列 —— 所以感觉"只有点了表单才知道在哪个树下"，其实一个 GET 就能拿。
- **实锤记录**（2026-10-10，1102 环境）：取 `成品修复报审表` 的 `dyFormCategoryId = 4c4924e1…`，
  直接当 `targetFormCategoryId` 调下载接口 → 成功返回 166KB sql（【MongoDB】+【POSTGRESQL】两段）；
  且 mongo 段开头就是 `db.dy_form.insert({_id:…, dyFormCategoryId: "4c4924e1…", …})` —— 存储位置实锤。
- 跨多个分类的表单要分开下载（一次下载只接受一个 category），`download_form_sql.py` 会自动分组。

### 1.2 数据表 Excel 导出（数据定义页的导出操作）

页面入口：**custom/data/define**（数据定义）页的导出按钮。接口：

```
POST <host>/apis/dynamic/form/table/excel/export
Authorization: Bearer <token>
Content-Type: application/json

{ "id": "<表单formId>", "fileName": "<数据表名，如 tud_tzsbtz>" }
```

| 参数 | 说明 |
| :--- | :--- |
| `id` | 该条数据定义的**表单 formId**（32 位十六进制） |
| `fileName` | **数据表名**（导出文件内容的表；文件名脚本里另起） |

- 响应是 **xlsx 二进制**（浏览器下载同款）；返回 JSON = 报错 / token 过期。
- 实测样本（2026-10-21，8700 环境）：`{"id":"e8bcde0b…","fileName":"tud_tzsbtz"}` 成功返回 Excel。
- 技能里用 `update-package` 的 `download_table_excel.py` 一键导出，产出放更新包 `Excel/` 子目录。

## 2. 返回文件的结构（关键）

文件内部用分隔行分段，形如（一行一个标记，段内容跟在后面）：

```
<---------------------------------------- 【MongoDB】 ---------------------------------------->
（MongoDB 脚本：表单设计数据）
<---------------------------------------- 【DM】 ---------------------------------------->
（业务库脚本：随 targetDatabase 变化）
```

| 段 | 内容 |
| :--- | :--- |
| **【MongoDB】** | **表单设计数据**（表单 JSON、字段、事件、按钮等，存 MongoDB 集合）——选任何目标库都包含它 |
| **【DM】/【MYSQL】/【POSTGRESQL】** | 所选业务库的配套 SQL（表单/字段/视图等的 DDL、平台元数据） |

> mongo 段的具体集合名与业务段的具体表名，以实际导出文件为准；发现新结构回填本页。

## 3. 更新包怎么打（有现成技能）

**用 `update-package` 技能**（[[00-技能调用指南]]），或手动跑两个脚本：

```bash
# ① 下载（树 id 自动抓取；环境参数每次由使用者提供）
python .claude/skills/update-package/scripts/download_form_sql.py \
  --host <host> --token <token> \
  --form-ids "<id1>,<id2>" \
  --database POSTGRESQL --out "更新包/原始下载.sql"

# ② 分割 + 生成 Word 更新说明
python .claude/skills/update-package/scripts/pack_update.py \
  --sql "更新包/原始下载.sql" --forms "<表单名1>,<表单名2>" \
  --out-dir "更新包" --notes-file "开发记录.md"

# ③ 数据表 Excel 导出（可选，见 §1.2）
python .claude/skills/update-package/scripts/download_table_excel.py \
  --host <host> --token <token> \
  --form-id <表单id> --table <数据表名> \
  --out "更新包/Excel/<数据表名>.xlsx"
```

分割约定（脚本自动做）：每段输出 **`【段名】-【表单名,表单名】.sql`**，如
`【MongoDB】-【预警数据,预警明细】.sql`、`【DM】-【预警数据,预警明细】.sql`。

## 4. 现场执行顺序（写进更新说明的三件事）

1. 先备份业务库 + MongoDB；
2. 先执行 【MongoDB】 段，再执行业务库段（顺序不可颠倒，文件名已标库类型，禁止跨库执行）；
3. 执行完在平台**重新发布**涉及的表单，清缓存验证。

## 关联

- [[00-技能调用指南]]（update-package 技能入口）

