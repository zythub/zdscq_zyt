---
name: bsk-page-debug
description: 用 bsk 调试 Web 页面功能（如 PRP 低代码系统）的固定流程。解决 daemon 自动升级导致 session 反复丢失、element ref 失效、React 受控组件填表等坑，一条命令跑全流程，几分钟出结果。触发词：浏览器调试、页面新增失败、bsk、打开页面看报错。
---

# bsk 页面调试固定流程（踩坑沉淀 2026-10-19）

## 必须避免的三个坑（不按这个来，每次都要折腾半小时）

0. **WorkBuddy Bash 工具的环境级限制（2026-10-22 实测，先看这条）**
   - **沙箱拦截 bsk**：沙箱内 bsk 报 `ensure daemon is running` 或直接无响应 → **bsk 命令一律 `dangerouslyDisableSandbox: true`**。
   - **daemon 活不过命令结束**：每条 Bash 命令结束时子进程被 job 对象清理，daemon 跟着死 → **session 也必死**（"session not registered"）。→ 每个"交互批次"必须自包含：start→navigate→所有操作→取结果 塞进同一条命令；长任务写 **python 脚本（subprocess 循环调 bsk）放 run_in_background 整体跑**，日志落盘监控。
   - **复杂命令随机 SIGTERM**（空输出+Signal: SIGTERM）：带管道/`$()`/多段的命令有概率被杀 → ①能简则简；②被杀就原样重试（读操作无害）；③输出重定向到文件再 cat，别用管道。
   - **`bsk update` 在这环境禁跑**：daemon 活不到升级完成 → 崩溃循环+反复重装；版本代差（CLI 0.1.11/扩展0.1.7）doctor 实测兼容，版本提示直接忽略。
   - daemon 启动：`bsk daemon start` 会阻塞 → 必须 run_in_background。

1. **daemon 自动升级反复重启 → session 全部丢失**
   - 症状：`bsk status` 的 pid/uptime 每条命令都在变（uptime 1s），session 建好下一条命令就 `session not registered`。
   - 解法：`export BSK_AUTO_UPDATE=off` 写进 `~/.bashrc`（一次性，已做），并且**每条 Bash 命令开头都重新 export**（WorkBuddy 每条命令是新 shell，环境变量不跨命令继承）。
   - 升级提示 "A new bsk version is available" 出现不影响功能，忽略即可。

2. **WorkBuddy 每条 Bash 命令都是新 shell**
   - 环境变量不继承、session 不保活。所以**从 start 到 snapshot 必须塞进同一条 Bash 命令**，变量用 `S=$(...)` 在命令内传递。

3. **element ref（@eN）跨导航/跨命令失效**
   - `bsk snapshot` 的 @eN ref 只在"当前 tab 状态"下有效；navigate 之后旧 ref 全部作废。
   - 点按钮不要用 ref，**用 `bsk evaluate` 按 textContent 找元素点击**，稳定且不怕 ref 失效：
     ```js
     [...document.querySelectorAll('button')].find(x => x.textContent.replace(/\s/g,'') === '新增').click()
     ```

## 标准一条命令模板（复制改两处就能用）

```bash
timeout 15 bsk status >/dev/null 2>&1; sleep 8        # 拉起 daemon + 等扩展重连
S=$(timeout 30 bsk session start --browser 1e0a4085 --no-focus 2>/dev/null | tail -1)
echo "session=$S"
timeout 30 bsk navigate "http://172.19.18.223:1112/web/#/customform/XXX" --session "$S" 2>&1 | grep reached
sleep 5
# 点按钮（替换按钮文字）
timeout 30 bsk evaluate "(() => { const b = [...document.querySelectorAll('button')].find(x => x.textContent.replace(/\s/g,'') === '新增'); if (b) { b.click(); return 'clicked'; } return 'not-found'; })()" --session "$S" 2>&1 | grep -v version
sleep 3
timeout 40 bsk snapshot --session "$S" 2>&1 | grep -v "bsk version"   # 观察结果
```

## 填 React 受控表单（antd input 直接赋值无效，必须触发 input 事件）

```js
(() => {
  const inputs = document.querySelectorAll('.ant-modal input.ant-input');
  const setVal = (el, v) => {
    const d = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value').set;
    d.call(el, v); el.dispatchEvent(new Event('input', {bubbles:true}));
  };
  setVal(inputs[0], '测试值');
  [...document.querySelectorAll('.ant-modal button')].find(b => b.textContent.includes('保存')).click();
  return 'saved';
})()
```

## 验证"操作到底成没成功"：别信页面提示，直接查库

页面 toast 可能一闪而过、接口 200 不代表业务成功。保存后直接连目标库 `SELECT` 目标表，按 `sys_createtime` 倒序看最新一条，一步到位。

## 会话管理

- 浏览器实例 id 用 `bsk browsers` 查（当前是 `1e0a4085`，chrome 155）。
- 结束后 `bsk session stop --all`；闲置 5 分钟也会自动关。
- 遇到登录页/浏览器授权弹窗：用 `bsk request-help --prompt "登录系统后点 Done"` 让用户本人操作（用户已确认此方式）。

## 批量 UI 操作模式（58 个功能发布实测沉淀 2026-10-22）

**生命周期铁律**：session 只在"发起它的那条 Bash 命令"内存活，命令结束 Agent Window 关闭、页面状态全丢。→
- 侦察：一条命令 start→navigate→snapshot 落盘，session 自然消亡。
- 批量执行：**python 脚本（subprocess 循环调 bsk）用 run_in_background 一条跑完全部**，日志落盘，脚本进程活着 daemon 就活着。
- 千万别跨命令复用 session id（必报 session not registered）。

**弹窗内 checkbox 的选中态快照看不出来**（VOM 里 `checkbox "新增" ="7ddeb880…"` 的值是权限 id 不是勾选态）→ 用 evaluate 读：
```js
[...document.querySelectorAll('.ant-modal .ant-checkbox-wrapper')].map(w=>({label:w.textContent.trim(), checked:w.querySelector('input').checked}))
```
勾选 = 对未选中的 input 调 `.click()`（antd checkbox 响应原生 click）。

**antd Select 筛选器的坑**：合成事件(mousedown/click dispatch)和 CDP 真点击都可能选不中选项（Agent Window 视口小 706x243，下拉可能渲染在视口外）。→ 能用搜索框就别用下拉筛选：React input 填值(native setter+input事件) → 点查询按钮(textContent.replace(/\s/g,'') 匹配"查 询"这种带空格的) → 表格里按唯一 code 定位行再点行内按钮。

**窗口太小先 resize**：`bsk window resize --width 1400 --height 900 --session $S`（Agent Window 默认只有 706x243，弹窗/下拉渲染不全）。

**长脚本骨架**（python + subprocess + 日志落盘 + run_in_background）：
```python
import subprocess, time, json
LOG=open(r'...\auto.log','a',encoding='utf-8')
def log(*a): LOG.write(' '.join(map(str,a))+'\n'); LOG.flush()
def bsk(args, timeout=60):
    return subprocess.run(['bsk']+args, capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=timeout)
r=bsk(['session','start','--browser','1e0a4085']); SID=r.stdout.strip().split('\n')[-1].strip()
log('session',SID)
bsk(['navigate',URL,'--session',SID]); time.sleep(6)
bsk(['window','resize','--width','1400','--height','900','--session',SID]); time.sleep(1)
# ... 逐项 evaluate/click，每步 log 返回值
bsk(['session','stop',SID])
```
evaluate 的 JS 里有单引号时，作为 subprocess 参数列表传递无需 shell 转义（别用 shell=True）。

## 流程没把握时：让用户演示一遍（bsk record），禁止瞎试（2026-10-22 用户明确要求）

顺序必须是：**先查本 skill/知识库 → 查不到就让用户录一遍 → 回放**，不要自己点着试错。

```bash
# 1. 启动录制（阻塞到用户点 Finish，放 run_in_background）
bsk record start --browser 1e0a4085 \
  --url "http://…" \
  --purpose "演示:<要用户做什么,一句话>" \
  --output <目录名>
# 2. 用户在 Agent Window 里操作, 完成后点面板上的 Finish
# 3. 产出 trace/<目录>/trace.json（v3: steps[] 每步带 action 前后 observe 状态, states/sN.txt 全页面快照）
# 4. 回放: 按 steps 顺序用 target/value 执行; 批量场景=把单次流程参数化后循环
```
- 录制会话期间 daemon 活着（record 进程不退出）✓
- 录完先读 trace.json 的 steps（每步有 target.role/name 和前后页面状态），**照抄用户的真实操作路径**，不要自己发明捷径。
- 回放批量化的循环变量（如 58 个功能名）从数据库拿，不从页面猜。

## PRP 系统速查（172.19.18.223:1112）

- 动态表单页 URL：`/web/#/customform/<SCHEME>`（如 JC_videoinfo、JC_videopowergroup）
- 保存接口：`POST /apis/dynamic/form/scheme/data/<schemeId>`，200 但需查库确认
- 元数据两层：物理表 + `dy_table`/`dy_table_field` 注册；表单元数据缺失会导致新增报 `违反列[id]非空约束`
- 对应达梦库：prp20（dbx 连接），物理表 owner=PRPNEW
