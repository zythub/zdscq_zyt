---
name: handbook-site-maintain
description: |
  维护并重新发布「自定义表单配置方法」单文件手册站（dist/index.html / skills.zip / dist/tools / 在线应用）。
  覆盖：React 中文文档风格视觉规范（字体、搜索框、夜间切换、背景）、构建、应用发布与账号坑、
  工具站外链与内嵌子应用裁剪、官方文档校订、工具站文档快照同步、发布前后自检。
  用于：页面可读性改造、改字体/配色、重新发布在线手册、技能包重打包上传、
  工具跳转修复、知识库笔记整理后重建、对照 bestdt 官方文档补 API。
  关键词：手册站、dist/index.html、build-viewer、viewer-template、skills.zip、重新发布、上线、
  在线链接、sharecode、夜间模式、搜索框、可读性、字体、工具跳转、zdscq、sync-handbook、官方文档校订。
user-invocable: true
---

# handbook-site-maintain —— 单文件手册站的维护与发布

## 触发

用户说「手册站页面看不清 / 改下字体 / 搜索框和夜间切换照 React 文档改 / 重新发布在线手册 /
工具跳转坏了 / 技能包重新打包上传 / 把知识库改动发到线上 / 官方文档更新了整理一下」等。

## 0. 先认清组件地图（不要一上来就改 HTML）

| 角色 | 位置 | 说明 |
| :--- | :--- | :--- |
| **正文源** | `<VAULT>/自定义表单配置方法/ | 唯一内容源，Markdown |
| **技能主本** | `<VAULT>/.claude/skills/` | 对外技能包来源；`.trae/skills/`、`.workbuddy/skills/` 为完全同步副本 |
| **页面模板** | `<VAULT>/.workbuddy/viewer-template.html` | HTML + 内联 CSS + 内联 JS，`/*__DATA__*/` 是数据占位符 |
| **构建器** | `<VAULT>/.workbuddy/build-viewer.mjs` | 扫描 md → 注入数据 → 产出手册；内含 `DESCS` / `SCENARIOS` / `TOOLS` 三张配置表 |
| **打包脚本** | `<VAULT>/.workbuddy/gen-skills-zip.py` | 打 `dist/skills.zip`（构建器会自动调用） |
| **本地产物** | `<VAULT>/dist/index.html`、`dist/skills.zip`、`dist/tools/` | 唯一 HTML 产物 + 技能包 + 站内工具子应用 |
| **发布目录** | 单独一个目录（本机示例 `D:\zyt\publish\custom-form-handbook`） | `index.html` + `skills.zip` + `tools/` + `.wbapp_*.genie` |
| **工具站仓库** | `<TOOL_REPO>` | 只保留 `dist/` 打包产物与 Pages workflow，源码已迁出；GitHub Pages 直接部署 |
| **应用标识** | 发布目录下的 `.wbapp_*.genie` + `.workbuddy/applications.yaml` | **决定发布到哪个应用、链接是否不变** |

`VAULT` = 知识库根目录，`TOOL_REPO` = 工具站仓库根目录。二者都以各自根目录为基准，不要写死到脚本里。

> ★ **改页面只改 `viewer-template.html`，永远不要直接改 `dist/index.html`** —— 它是生成物，下次构建会被覆盖。

## 1. 构建（内容或模板改完都必须跑）

```bash
cd <VAULT>
node --check .workbuddy/build-viewer.mjs      # 先查语法，避免白跑
node .workbuddy/build-viewer.mjs
```

一次构建会同时：重扫全部 md → 重写唯一产物 `dist/index.html` → 重打 `dist/skills.zip`（并内嵌 base64）；`dist/tools/` 原样保留不动。
期望输出形如 `笔记 9 篇 / 分组 1 个 / 文件 470 KB`。笔记顺序由构建器 `STAGE` 数组固定（总览 → 数据表创建 → 表单设计 → 表单发布 → 流程设计 → 流程发布 → 测试验收 → 实战与常见问题处理 → 自定义表单开发实战），**侧栏、卡片、目录共用这个顺序**，别再按文件名 localeCompare 排。

配套（只改了技能、没改页面时）：`python .workbuddy/gen-skills-zip.py`。

## 2. 视觉规范（用户说「照 React 中文文档改」时）

**完整色板、字体栈、字号表、控件规则见 `references/视觉规范.md`**。要点：

- **浅色优先**：默认 `data-theme="light"`，纯白纸面 `#fff` + 深墨字 `#23272f`。
- **中文别用衬线体**：原模板 `blockquote` 用 `Georgia / 宋体`，小字号发虚，是「看不清」的头号原因；改成系统无衬线栈。
- 正文 `16px / 1.8`，h1 `34px`、h2 `24px`（下边框，不要左侧蓝竖条），表格 `14.5px`。
- 搜索框：**全站只有一个**，就在顶栏最上方；`.search { flex:1; max-width:none }` 占满 logo 与右侧按钮之间的整行，42px 高、焦点 3px 蓝色光环、保留 `Ctrl K`。首页不得再放第二个大搜索框（用户明确说「多余」）。
- 夜间切换：带文字的独立按钮（「夜间模式」/「日间模式」），不要只放一个 30px 图标。
- 强调色收敛成一个 `#087ea4`，去掉蓝图渐变和满屏 mono 小字。

**改法**：在 `</style>` 前**追加一段覆盖层 CSS**，不要重写原 CSS 块 —— 原模板有一百多条 class，重写必漏。
同理 JS 用精确字符串替换，不要整段重写。

## 3. 发布（最容易踩坑，先读 `references/发布与踩坑.md`）

流程：

1. 把 `dist/index.html` → 发布目录 `index.html`，`dist/skills.zip` → `skills.zip`，`dist/tools/` 整份 → 发布目录 `tools/`。**同一份三件套要同时放到两个发布目录**（WorkBuddy 应用目录 + GitHub Pages 仓库的 `dist/`），保证两处 `index.html` 逐字节一致。
2. 确认发布目录里有 `.wbapp_*.genie`（内容含 `appId` / `name` / `localDir` / `entryHtml`），缺了就从会话目录恢复；它决定**链接是否保持不变**。
3. 用「发布为应用 / sites」对**这个发布目录**执行 deploy，`directory` 必须是该目录的绝对路径，`language=static`、`entryHtml=index.html`。
4. 发布后用网页抓取或浏览器验证线上标题、正文关键词、`skills.zip` 可下载。

★ 铁律：

- **目标应用由 `directory` 决定，不由 `appId` 参数决定**。发错目录 = 发到别的应用。
- 同一知识库可能有多个在线站（例如旧站 `bestdt-handbook`、新站 `custom-form-handbook`），每个 `.genie` 里的 `localDir` 不同。要替换哪个链接，就把内容放到**那个链接对应的目录**再发。
- `SITES_ACCOUNT_MISMATCH` = 该目录绑的应用属于另一个账号，**重试无效、不要改发别处**；正确做法是让用户切回原账号，或明确授权后改用当前账号的目录/新建应用。
- 用户明确说「重新发布成你的应用」时，就是授权用当前账号新建/替换，此时可以发到当前账号名下已有的另一个发布目录。
- 发布同意不跨轮：改动内容后要重发，需用户在本轮明确说发布/上线。

## 4. 工具跳转与「子工具集」裁剪

- **功能已融合，不再有跳转**：`TOOLS` 只留「字段生成器」一项（书签生成 / 自定义表单代码示例 / 工具箱 / 第三方站点全部删除）。
  点击卡片调用 `openToolPane(href)` 打开**页内全屏面板**（`#toolPane` + 同源 iframe），不是 `window.location.href`。
  用户反复反馈「跳转打不开」，根因就是跳转会丢 sharecode 上下文；页内面板彻底绕开。
- iframe 加载后向 `contentDocument.head` 注入一段 CSS 隐藏工具站自带的 `aside.side` 导航（只留字段生成器本体），
  并同步写 `localStorage['handbook.theme']`（子应用读旧键），让深浅色跟着手册站走。
- `dist/tools/` 来自工具站 `dist-sub/`（vite `BASE_PATH=/tools/`）。★ 要把产物里的绝对路径**改成相对**：
  `index.html` 的 `/tools/assets/` → `./assets/`，编译 JS 里的 `"/tools/"` → `"./"`。
  否则同一份页面在 `/`（WorkBuddy）和 `/zdscq_zyt/`（GitHub Pages）下只有一个能加载资源。
- 构建器**不再**从外部仓库 `copyToolsApp()`；发布目录里必须带同一份 `tools/`。
- ★ 遇到 `/tools/index.html` 返回 **403**，先别改跳转：多半是分享码鉴权 cookie（`__wb_rsc`），
  先访问带 `?sharecode=...` 的首页拿 cookie 再测就是 200。裸 HTTP 客户端会误判。
- 本地验证面板必须起 HTTP 服务（`python -m http.server`），`file://` 下 iframe 资源会白屏；
  iframe 是异步挂载的，查渲染结果要等 2 秒左右，别 evaluate 完立刻断言为空。

## 5. 工具站文档快照同步

工具站 `handbook` 页内嵌了一份知识库笔记副本，源文件在 `<TOOL_REPO>/src/tools/handbook/notes/`，**构建期打进包**（`import.meta.glob('./notes/**/*.md', { query: '?raw', eager: true })`），不能运行时 fetch。

```bash
cd <TOOL_REPO>
node scripts/sync-handbook.mjs          # 会把 TARGET 整个删掉重建，并自动脱敏内网地址/token
npm run build:only                      # vite build，约 5s；比 build 少一层 vue-tsc
```

- 同步脚本会删旧目录重建 → **先备份** `notes/`（zip 即可）。
- 它按 `.md` 全量扫 `<VAULT>`，排除隐藏目录与 `CLAUDE.md`；`首页.md` 会同步（工具站首页默认落在它上面）。
- 改完要把 `<TOOL_REPO>/dist/` 同步到实际发布目录（本机示例 `<TOOL_REPO 的独立站>/_webroot/`），再重新发布独立工具站才在线生效。
- 校验新产物：在 `assets/index-*.js` 里搜新章节名应命中、旧项目专属词（如「智慧工地」「01-自定义开发」）应为 0。

## 6. 官方文档校订

bestdt 官方文档（`<https://www.bestdt.com/formdeep/docs/>`）会改版，定期对照一次：

1. 抓 `responsive/function/basic-control/`、`increment-control/`、`event/list/` 等页。
2. 从页面里提取 `ctx.*` / `params.*` 方法名，与 `<VAULT>/自定义表单配置方法/实战/自定义表单开发实战.md` 做集合差。
3. 缺失项补一节「官方文档校订补充（日期）」，**标注 📦 未逐条实测**，并写明口径差异。
4. 本库约定「实测 > 理论」：官方 camelCase 事件枚举 ≠ 控件 `props.events` 里实测的大写 key（`CLICK`/`CHANGE`…），两者不要混用，注册事件用实测大写。
5. 工具站的 `form-docs` 页若只嵌了一个子页，补一排快捷入口（文档首页 / 普通控件 / 自增控件 / 辅助函数 / 事件列表 / FAQ）+ 新窗口打开。

## 7. 自检清单（发布前逐条过）

- [ ] `node --check .workbuddy/build-viewer.mjs` 通过
- [ ] 构建输出篇数 / 分组数符合预期；只生成 `dist/index.html`（根目录不应再有 `开发手册.html`）
- [ ] **DESCS 的每个 key 都等于某篇笔记的首个 H1**（不等会**静默**取不到描述，不报错）
- [ ] SCENARIOS 的每个 `id` 都能在笔记 id 里找到（断链不报错，点了没反应）
- [ ] 生成 HTML 里 CSS 花括号平衡、内嵌 `<script>` 抽出来 `node --check` 通过
- [ ] 浏览器实际截图看过：首页首屏、文档阅读页、夜间模式三处（只用 grep 看不出布局问题）
- [ ] `skills.zip` 技能数与技能卡数量一致；内嵌 base64 能解出 zip
- [ ] 全库搜旧目录名 / 旧技能数字 / 项目专属词，正文层应为 0
- [ ] 发布目录带 `tools/` 且 `tools/index.html` 引用 `./assets/...`（相对路径）；两处部署的 `index.html` md5 相同
- [ ] 线上验证：标题、新章节关键词、技能包直链

## 8. 已知静默坑

| 坑 | 症状 | 处理 |
| :--- | :--- | :--- |
| `DESCS` key ≠ H1 | 首页卡片描述空白，无报错 | 改 md 标题必须同步改 `build-viewer.mjs` 的 DESCS（**不在** viewer-template.html） |
| `SCENARIOS` id 过期 | 速查按钮点了没反应 | 改文件名后同步改 id（相对路径、不带 `.md`） |
| 直接改生成物 | 改动下次构建消失 | 只改 `viewer-template.html` |
| 旧 `localStorage` 主题键 | 老用户仍看到深色 | 换 key（如 `handbook.theme.v2`），别沿用旧值 |
| 自动弹窗糊住首屏 | 一进来就是遮罩，显得乱 | 取消自动弹，入口保留在右上角按钮 |
| `file://` 截图保存被拒 | 截图工具报不在 workspace roots | 不传 `filePath`，让截图直接附在响应里 |
| managed node 版本 | `-3` 目录不存在 | 用 PATH 里的 `node`，别写死版本目录 |
| `tools/` 目录 403 | 工具卡片全打不开 | 改绝对外链，别内嵌 |

## 9. 三套 skills 与技能包

新增/改动 skill 后：以 `.claude/skills/` 为唯一主本 → 同步到 `.trae/skills/`、`.workbuddy/skills/`（逐字节 md5 校验零差异）
→ 更新 `gen-skills-zip.py` 的 `SKILLS` 列表 → 更新 viewer 弹窗里的技能卡与数量 → 更新 `首页.md` / `CLAUDE.md` / `.trae/rules/` 的技能表
→ 重跑构建（会自动重打包）。

## 关联

- `update-package`：现场更新包 / 表单打包导出 SQL / 技能包打包上传的归属说明
- `<VAULT>/.workbuddy/整理变更清单_2026-11-06.md`：一次完整整理的实例记录
- `references/视觉规范.md`、`references/发布与踩坑.md`
