---
name: wbipc-api-automation
description: 用 WorkBuddy daemon 的本机 IPC 代理（WBIPC 的 wb.request / http.fetch）调用任何需要登录态的 WorkBuddy 后端接口，脚本全程不接触 token。适用于把 WorkBuddy 自身功能（签到、成长任务、积分、猫猫旅行等）做成本机自动化脚本；也适用于「拿不到 token 但要以当前登录账号调接口」的场景。含从 Electron asar 里挖真实接口名/错误码/前端判定逻辑的取证方法。
version: 1.0.0
agent_created: true
---

# WorkBuddy 本机接口自动化（WBIPC 代理）

## 用途

要自动化 WorkBuddy 自身的功能时，最大的障碍是**登录态拿不到**：`~/.workbuddy/keyblob`
用 masterKey 包裹，字段级加密（`$wbEncrypted: 1` + envelope），`atRestSecretKey` 由原生绑定提供、
只存在于 `WorkBuddy.exe` 二进制内 —— **自行解密这条路不用走**。

正解：WorkBuddy daemon 本身就开了一条**带鉴权的 HTTP 代理通道**。客户端脚本把
「方法 + 路径 + body」交给 daemon，daemon 自己注入
`Authorization: Bearer <token>` / `x-user-id`（企业号另加 `x-enterprise-id`、`x-tenant-id`），
然后把响应原样回来。**token 从头到尾不出 daemon**，脚本里一个字节都碰不到。

## 触发条件

- 要把 WorkBuddy 自身功能做成本机定时脚本（签到 / 积分 / 成长任务 / 活动等）
- 用户说「token 别打印」「token 别落盘」「别硬编 token」
- 需要以当前登录账号调 WorkBuddy 后端，但拿不到明文凭据
- 要用后台接口而不是 UI 自动化来完成一件事

## 前置条件

1. **WorkBuddy Desktop 必须正在运行**（daemon 是 IPC 服务端）。否则 `connect()` 抛 `NotWorkBuddyEnv`。
2. 与 WorkBuddy 同一用户身份执行（管道按用户隔离）。
3. 官方 Python SDK（仅标准库）：随 WorkBuddy 内置插件分发，动态定位：

```
<WorkBuddy安装目录>/resources/app.asar.unpacked/resources/plugins/
    workbuddy-builtin/skills/library/workbuddy_ipc/__init__.py
```

Windows 典型安装目录 `D:\soft\WorkBuddy` 或 `%LOCALAPPDATA%\Programs\WorkBuddy`。
**把它整个 `workbuddy_ipc/` 目录复制到脚本同级**，即开箱可用，不要改写它。

## 核心原理（够用版）

- **发现**：`~/.workbuddy/wbipc/endpoint.json` → `{"endpoint": "\\\\.\\pipe\\wbipc-<id>", "ticket": "<base64url>"}`
  （macOS/Linux 是 Unix socket）。可用环境变量 `WORKBUDDY_CONFIG_DIR` 覆盖配置目录。
- **握手**：客户端发 `session_hello`（`protocol_min/max=1`、`client_nonce`、`ticket_id`）→
  服务端回 `session_challenge`（`server_nonce`、`server_proof`）→ 客户端验 proof 后回
  `session_prove` → 服务端回 `session_hello_ack`（`connection_epoch`、`max_inflight`、`pipes`）。
  proof 算法 `HMAC-SHA256(ticket, encodeTranscript(role, ...))`，role 为 `wbipc-c` / `wbipc-s`。
  SDK 已全封装，**不要自己实现握手**。
- **帧**：换行分隔 JSON，单帧上限 **1 MiB**。
- **管道**：`wb.request`，方法 `http.fetch`（`broker/ListPipes`、`broker/GetPipe` 也能用）。

### `http.fetch` 参数 / 返回

```jsonc
// 入参
{
  "method": "GET" | "POST" | "PUT" | "DELETE",
  "path": "/v2/xxx",              // 后端路径
  "query": {"page": "1"},         // ⚠️ 值必须是字符串，传 int 会报 query page must be a string
  "headers": {"content-type": "application/json"},  // ⚠️ 只允许自带 content-type / accept
  "body_b64": "<standard base64>" // body 必须是 base64，不是明文
}
// 出参
{"status": 200, "headers": {...}, "body_b64": "<base64>"}
```

- 响应体**内联上限 655360 字节**（超了拿不到）。
- 响应头只透传：`content-type, content-length, etag, last-modified, retry-after, location, x-request-id`。

## 最小可用模板

```python
import base64, json, os, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from workbuddy_ipc import connect, WbipcError, NotWorkBuddyEnv


class Api(object):
    def __init__(self, pipe):
        self._pipe = pipe

    def call(self, method, path, body=None, query=None):
        params = {"method": method, "path": path}
        if query:
            params["query"] = dict((k, str(v)) for k, v in query.items())
        if body is not None:
            payload = json.dumps(body, ensure_ascii=False).encode("utf-8")
            params["body_b64"] = base64.b64encode(payload).decode("ascii")
            params["headers"] = {"content-type": "application/json"}
        raw = self._pipe.invoke("http.fetch", params)
        text = base64.b64decode(raw.get("body_b64") or b"").decode("utf-8", "replace")
        try:
            parsed = json.loads(text)
        except Exception:
            parsed = None
        return {"status": raw.get("status"), "body_text": text, "json": parsed}

    @staticmethod
    def biz(resp):
        j = (resp or {}).get("json") or {}
        return j.get("code"), (j.get("data") or {})


with connect(client_id="my-skill", client_kind="skill", client_version="1.0") as wb:
    print("pipes:", wb.pipes)                       # 期望 ['wb.request']
    pipe = wb.get_pipe("wb.request")
    print("methods:", pipe.methods)                 # 期望 ['http.fetch']
    api = Api(pipe)
    print(api.call("GET", "/v2/activity/growth/buddy/info"))
```

### API 速查（`workbuddy_ipc`）

| 名称 | 说明 |
| :--- | :--- |
| `connect(client_id=None, client_kind=None, client_version=None, endpoint=None, ticket=None)` | 上下文管理器；返回 `WbipcClient` |
| `wb.pipes` / `wb.list_pipes()` | 可用管道名列表 |
| `wb.get_pipe(name)` | 取 `PipeClient` |
| `pipe.methods` | 该管道支持的方法 |
| `pipe.invoke(method, params=None, timeout=60.0)` | 调用 |
| `WbipcError` | 基类，带 `.code` / `.message` / `.data` |
| `NotWorkBuddyEnv` | 环境里没有 WorkBuddy 端点（daemon 没跑 / 配置目录不对） |
| `EndpointUntrusted` | 端点没能证明持有 ticket（可能是伪造的） |
| `ConsentRequired` | 需要用户授权 |
| `CONFIG_DIR_ENV = "WORKBUDDY_CONFIG_DIR"` | 覆盖配置目录 |

## 接口名怎么定：从 asar 取证，别信网上的旧名

WorkBuddy Desktop 是 Electron 应用，**全部前端源码都在 `app.asar` 里**。真实接口名、业务错误码、
前端的判定逻辑（先做什么后做什么）都能直接读出来 —— 这比探测猜可靠得多，也避免探测写坏数据。

### asar 结构

```
[8B: 4×uint32LE, 第 4 个是 headerSize][headerSize 字节 JSON 索引][数据区 ...]
数据区起点 data_start = 16 + headerSize
文件内容 = seek(data_start + int(index[key]["offset"])) 后读 int(size)
```

### 一键搜源码

```python
import re, struct
ASAR = r"D:/soft/WorkBuddy/resources/app.asar"
with open(ASAR, "rb") as f:
    raw = f.read(16)
    (_, _, _, header_size) = struct.unpack("<4I", raw)
    data_start = 16 + header_size
    f.seek(data_start)
    txt = f.read().decode("utf-8", "replace")   # 整包约 300MB 文本，一次读完再搜

for pos in [m.start() for m in re.finditer(re.escape("billing/meter"), txt)][:5]:
    print(txt[max(0, pos - 1200):pos + 1200])
```

> 提取单个文件（比如 `credential-protection.js`）时，**务必加上 `data_start` 偏移**，
> 只按索引里的 `offset` 去 seek 会读到完全无关的内容（索引里的 `offset` 是字符串，记得 `int()`）。

### 搜什么关键词

| 想找 | 搜什么 |
| :--- | :--- |
| 接口路径 | 路径片段，如 `billing/meter`、`travel/`、`/v2/` |
| 业务错误码 | 函数名，如 `mapCheckinStatus`、枚举名如 `CheckinClaimStatus` |
| 前端判定逻辑 | 状态字段名，如 `today_checked_in`、`daily_limit_reached` |
| 请求前缀差异 | `billingPrefix`、`BaseProvider`、`httpService.post` |
| 认证/加密 | `keyblob`、`$wbEncrypted`、`atRestSecretKey`、`buildHeadersWithTuringToken` |

## 已知坑（都实测踩过）

1. **`query` 的值必须是字符串** —— 传 `{"page": 1}` 会报 `E_BAD_REQUEST: query page must be a string`。
2. **body 必须 base64** —— `body_b64` 用标准 base64（非 urlsafe），不是明文。
3. **只允许自带 `content-type` / `accept` 两个头**，别的头传了也不生效；鉴权头由 daemon 注入。
4. **Desktop 端接口前缀常是 `/v2`** —— 源码注释原文：
   `/billing/meter/*（billing / checkin）— Web 端无前缀，Desktop 覆盖为 /v2`。
   `/v2/...` 与不带 `/v2` 的路径实测多数都能通，**但以后端真实路由为准**。
5. **写接口的响应体可能是「调用前」的过期快照** —— 比如派遣成功后返回里
   `daily_limit_reached` 还是 `false`、`duration_hours` 还是 `0`，
   **真实值要再查一次 GET 状态接口**。别把写操作的返回值当最终状态。
6. **前端映射表可能是旧码** —— 例如前端 `mapCheckinStatus()` 写的是 `1001`，
   而服务端实测返回的是 `10001`。判定要 **code + msg 关键词双保险**，别只认一套码。
7. **部分接口对客户端类型敏感** —— `/v2/msg-center/message/*` 走代理返回
   `400 {"code":17043,"msg":"client not supported"}`，这类接口代理通道走不通，需要换思路。
8. **进程退出即断开** —— 用 `with connect(...) as wb:` 保证清理；长脚本别跨多次 connect。
9. **不要读 Cookie 数据库** —— 被浏览器/应用占用（`WinError 32`），且实测没有可用会话 Cookie。

## 失败处理

| 现象 | 原因 / 对策 |
| :--- | :--- |
| `NotWorkBuddyEnv` | WorkBuddy Desktop 没跑；或用了不同的用户身份；或 `WORKBUDDY_CONFIG_DIR` 指错 |
| `EndpointUntrusted` | 端点没证明持有 ticket —— 检查是不是连到了伪造的管道 |
| `ConsentRequired` | 需要用户在 WorkBuddy 里授权，引导用户点一下 |
| `E_BAD_REQUEST: query xxx must be a string` | query 值转成 `str` |
| 业务 `code != 0` | 读 `msg`，对照源码里的错误码映射表分支处理 |
| HTTP 401 | 本机登录态过期，让用户在 WorkBuddy 里重新登录（**不要去解密 keyblob**） |
| 响应体拿不全 | 超过 655360 字节内联上限；改用分页/查询参数缩小 |

## 交付形态建议

按用户偏好给：
- **主脚本**：纯标准库、Python 3.8+ 通用、Windows/macOS/Linux 都能跑
- **启动器 `run.sh`**：用 `command -v python || command -v python3 || command -v py` 动态取解释器，
  **不写死版本号**
- **vendored `workbuddy_ipc/`**：与脚本同目录，开箱即用
- **定时**：优先 WorkBuddy 自带的定时任务；Windows 任务计划要管理员权限（实测普通权限下
  `schtasks /create` 和 `Register-ScheduledTask` 都返回「拒绝访问」）
- 手动跑通一次、把**原始返回**贴给用户看，再交付

## 参考实现

一个端到端真实案例（Buddy 加油站签到 + 派猫猫旅行，含接口契约表、踩坑记录、实测原始返回）：
`D:\zyt\知识库\07-本机自动化\WorkBuddy本机接口自动化skill.md`
