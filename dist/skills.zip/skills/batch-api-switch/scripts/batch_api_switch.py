#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""bestdt 资源接口批量上/下线工具。

用法（host/token 每次由使用者提供，不落库）：
  python batch_api_switch.py --host http://<ip>:<port> --token <access_token> \
      --group <分组id> --action cycle              # ★ 生效周期：先全部下线，再全部上线（推荐）
  python batch_api_switch.py ... --action online    # 只把下线的上线（不满足生效机制，慎用）
  python batch_api_switch.py ... --action offline   # 只把在线的下线
  python batch_api_switch.py ... --action cycle --exclude "名称1,名称2"   # 排除指定接口
  （单边模式加 --all 可强制全调）

接口契约（Reqable 抓包实证，2026-10-21）：
  POST {host}/apis/resource/group/listApi   body {"currentPage":1,"pageSize":100,"groupId":"..."}
  GET  {host}/apis/resource/api/online/{id}    上线（200 发布成功!）
  GET  {host}/apis/resource/api/offline/{id}   下线（200 下线成功!）
  记录的 isRelease 字段 = 上线状态。生效机制：先全部下线 → 再全部上线，缺一不可。
"""
import argparse, json, ssl, sys, time, urllib.request

CTX = ssl.create_default_context()
CTX.check_hostname = False
CTX.verify_mode = ssl.CERT_NONE  # 现场自签 https 兜底

def req(host, token, method, path, body=None):
    data = json.dumps(body).encode() if body is not None else None
    r = urllib.request.Request(host.rstrip('/') + path, data=data, method=method, headers={
        'Authorization': 'Bearer ' + token,
        'Content-Type': 'application/json',
        'User-Agent': 'batch-api-switch/1.1',
    })
    with urllib.request.urlopen(r, context=CTX, timeout=60) as resp:
        return json.loads(resp.read().decode('utf-8'))

def list_apis(host, token, group):
    """拉分组全量接口（自动翻页）。"""
    records, page = [], 1
    while True:
        d = req(host, token, 'POST', '/apis/resource/group/listApi',
                {'currentPage': page, 'pageSize': 100, 'groupId': group})
        data = d.get('data') or {}
        records += data.get('records') or []
        total = data.get('total') or len(records)
        if len(records) >= total or page > 50:
            return records
        page += 1

def batch(host, token, records, action, excludes, force):
    """对 records 执行 action，返回 (成功数, 失败明细)。excludes 按名称排除。"""
    action_path = '/apis/resource/api/' + action + '/'
    ok, fail = [], []
    for r in records:
        name = r.get('name') or r['id']
        if name in excludes:
            print('  [排除] %-20s' % name)
            continue
        if not force:
            want = (action == 'online')          # online 的目标是 isRelease=False 的
            if bool(r.get('isRelease')) == want:
                print('  [跳过] %-20s（状态已一致）' % name)
                continue
        try:
            res = req(host, token, 'GET', action_path + r['id'])
            code = res.get('code')
            good = (code == 200)
            (ok if good else fail).append((name, code))
            print('  %-20s -> %s %s' % (name, code, str(res.get('msg', ''))[:40]))
        except Exception as e:
            fail.append((name, str(e)[:60]))
            print('  %-20s -> EXC %s' % (name, e))
    return ok, fail

def main():
    ap = argparse.ArgumentParser(description='bestdt 资源接口批量上/下线')
    ap.add_argument('--host', required=True)
    ap.add_argument('--token', required=True, help='Bearer token（localStorage.access_token）')
    ap.add_argument('--group', required=True, help='接口分组 id（listApi 的 groupId）')
    ap.add_argument('--action', choices=['online', 'offline', 'cycle'], default='cycle',
                    help='cycle=先全部下线再全部上线（系统生效机制，推荐）')
    ap.add_argument('--exclude', default='', help='排除的接口名称，多个用英文逗号分隔')
    ap.add_argument('--all', action='store_true', help='单边模式下强制全部调用（cycle 恒为全调）')
    a = ap.parse_args()

    excludes = set(x.strip() for x in a.exclude.split(',') if x.strip())
    records = list_apis(a.host, a.token, a.group)
    print('分组共 %d 个接口' % len(records))

    steps = [('offline', '全部下线'), ('online', '全部上线')] if a.action == 'cycle' \
        else [(a.action, '上线' if a.action == 'online' else '下线')]
    if a.action == 'cycle':
        print('生效周期模式：先全部下线 → 再全部上线（间隔 1 秒）')

    total_ok, total_fail = 0, []
    for action, label in steps:
        print('\n---- %s ----' % label)
        ok, fail = batch(a.host, a.token, records, action, excludes, force=(a.action == 'cycle' or a.all))
        total_ok += len(ok)
        total_fail += fail
        if a.action == 'cycle' and action == 'offline':
            time.sleep(1)   # 全下线后停一拍再上线

    # 复核
    records2 = list_apis(a.host, a.token, a.group)
    target = (a.action != 'offline')   # cycle/online 的终态都是在线
    still = [r.get('name') for r in records2 if bool(r.get('isRelease')) != target
             and (r.get('name') or '') not in excludes]
    print('\n==== 结果：成功 %d / 失败 %d / 复核状态不符 %d ====' % (total_ok, len(total_fail), len(still)))
    for f in total_fail: print('FAIL:', f)
    if still: print('仍不符:', still)
    sys.exit(0 if not total_fail and not still else 1)

if __name__ == '__main__':
    main()
