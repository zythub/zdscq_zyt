---
name: batch-api-switch
description: |
  bestdt 资源接口批量上/下线。对某个接口分组（groupId）里的全部自定义接口执行
  上线 / 下线 / 生效周期（先全部下线再全部上线 —— 系统只有这样才能生效）。
  核心接口（Reqable 抓包实证）：POST /apis/resource/group/listApi（分页列表，isRelease=上线状态）、
  GET /apis/resource/api/online/{id}（上线，返回"发布成功!"）、GET /apis/resource/api/offline/{id}（下线，返回"下线成功!"）。
  用于：改完接口配置后让整组接口生效、批量发布、批量撤线。
  关键词：批量上线、批量下线、接口上下线、online、offline、listApi、groupId、isRelease、
  生效、发布成功、资源接口、重新发布。
user-invocable: true
---

# batch-api-switch —— 资源接口批量上/下线

## 触发

用户说"批量上线/下线接口"、"把分组里的接口都重新发布"、"接口改完不生效，上下线一遍"等。

## 前置信息（缺了要问用户，**不落库**）

| 参数 | 说明 |
| :--- | :--- |
| host | 环境地址（每次由使用者提供） |
| token | 登录后 `localStorage.access_token` |
| group | 接口分组 id（资源管理 → 分组列表；或从 listApi 请求体里看 `groupId`） |
| exclude（可选） | 不参与操作的接口名称清单 |

## 生效机制（★ 关键，2026-10-21 实证）

系统需要**先全部下线 → 再全部上线**才生效；只对下线的接口调上线**不管用**。
所以常规操作就是 `--action cycle`，不要只跑单边。

## 接口契约

```
POST {host}/apis/resource/group/listApi
  body: {"currentPage":1, "pageSize":100, "groupId":"<分组id>"}
  → data.records[]，每条含 { id, name, isRelease }（isRelease=true=在线）；total 超过 100 要翻页

GET {host}/apis/resource/api/online/{id}    上线，成功返回 200 "发布成功!"
GET {host}/apis/resource/api/offline/{id}   下线，成功返回 200 "下线成功!"
```

## 用法

```bash
# ★ 常规：生效周期（全下线 → 全上线）
python <skill目录>/scripts/batch_api_switch.py \
  --host <host> --token <token> --group <分组id> --action cycle

# 只上线 / 只下线（注意：单边调用不满足生效机制，见上）
python ... --action online     # 只把下线的上线
python ... --action offline    # 只把在线的下线

# 排除不想动的接口（按名称，多个逗号分隔）
python ... --action cycle --exclude "同步附件,天气数据"
```

- 默认每条都调（cycle 模式）；`--action online/offline` 单边模式只处理状态相反的，加 `--all` 强制全调。
- 执行完自动重新拉列表复核，输出 成功/失败/仍不符 三行结论。

## 硬性约定

- host 与 token 只走命令行参数，**不写进任何文档**。
- cycle 前提醒用户：期间整组接口短暂全下线，确认没有正在调用的业务再执行。
- 发现接口契约变化（如新增字段/换路径）记得回填本文件。
