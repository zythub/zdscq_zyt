---
name: env-debug
description: |
  bestdt 环境接入与排查速查：页面路由（表单设计/发布/自定义表单页/流程办理）、token 取法、
  数据库只读规则（dbx MCP 查库核对，禁止改库）、浏览器调试工具选择（chrome-devtools MCP / BrowserSkill）、
  高频排查（改了不生效三查、业务数据异常、自定义接口报错、控件 id 不一致）。
  环境 URL + token 每次由使用者单独提供，不落库。
  关键词：环境、路由、token、access_token、数据库只读、dbx、MCP、排查、不生效、405、401、
  表单设计、表单发布、customform、流程办理。
user-invocable: true
---

# bestdt 环境接入与排查速查

> ⚠️ **不记录真实环境地址与 token**：环境 URL + token **每次由使用者单独提供**。
> 拿到地址后按 §1 的路由拼接即可。

## 1. 路由速查（拼在提供的 host 后面）

| 页面 | 路由 |
| :--- | :--- |
| 表单设计 | `/web/#/custom/form-definition/design` |
| 表单发布 | `/web/#/custom/form-definition/publish` |
| 自定义表单页（发布后填单） | `/web/#/customform/{菜单code}` |
| 流程办理 | `/web/#/add/process?...`（从待办进入，带 procInsId/taskId） |
| 数据定义 | `/web/#/custom/data/define` |
| API 前缀 | `/apis/`（脚本里写 `/dynamic/...`、`/mis/...` 不带前缀，网关自动补） |

**token**：登录后 F12 → Application → Local Storage → `access_token`；请求头 `Authorization: Bearer <token>`。
**不要把 token 写进任何文档**（会过期，还会泄露）。

## 2. 数据库（只读！）—— 走 dbx MCP，由 agent 操作

1. 查库一律让 AI 走 **dbx MCP**；需要新连接时提供 类型/Host/Port/库名/schema/账号。
2. **数据库只读**：只允许 `SELECT` 查看、核对数据；**禁止在数据库里改数据**（改数据走平台界面/自定义接口）。
3. **表单绑定哪张表怎么找**：表单设计器里看控件的数据绑定；或
   `GET /apis/dynamic/form/attribute/{formId}` → **`mainTable` / `enableTable`**。
4. **前端联调必须查库核对**：保存 / 流程走完后直接 `SELECT` 核对落库值，别只看页面。

## 3. 浏览器（chrome-devtools MCP / BrowserSkill）

- 调试/抓包/性能走 **chrome-devtools MCP**；登录态复用、复杂流程可走 BrowserSkill（`bsk`）。
- `bsk` 三步：`session start` → `navigate / snapshot / click / fill` → `session stop`。
- 抓表单定义：`fetch('/apis/dynamic/form/attribute/{formId}', {headers:{Authorization:'Bearer '+localStorage.access_token}})`。

## 4. 排查方法

### 4.1 改了表单不生效
1. 强刷 `Ctrl+Shift+R`；清 `localStorage.clear()`。
2. 检查表单是否「已发布」。
3. 保存接口路径应为 `PUT /apis/dynamic/form`（集合路径，405 = 路径错）；401 = token 过期。

### 4.2 业务数据异常
1. 先查业务主表状态字段（流程状态），再查明细表数据。
2. 对账口径遇具体业务再让 AI 按表名/字段查库核对，口径结论不进知识库。

### 4.3 自定义接口报错
1. 复制 SQL 手跑；检查 `#{参数}` 传值；慢 SQL 看 `sys_application_log` / `sys_business_log`。

### 4.4 表单控件 id 不一致
1. 不要硬编码 id（换环境会变）；用 `getControlIdByField` 按 dataField 反查（见知识库《自定义表单开发实战》§3.5）。
2. 批量改脚本时用 `formAttributeJson` 实时解析，不跨环境复用 id。

## 5. 何时该连 MCP

- 不知道表结构 / 要核对落库数据 → **数据库 MCP（dbx）**。
- 不知道控件 id / 事件代码 → **浏览器 MCP**。
- 代码跑不通 → 让 AI 拿真实数据再改，**不要硬编**。
