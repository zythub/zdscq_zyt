"""目录树截断诊断。

在写/改"按分类过滤取树"的数据源之前先跑这个，确认过滤锚点选对表。

用法：
    export BSTD_TOKEN=...; export DF_BASE=http://host:port
    python diagnose_tree.py \
        --dir-table  tqy_quality_acceptance_dir \
        --main-table tqy_quality_acceptance_dir_main \
        --field      specialty \
        --fk         tqy_quality_acceptance_dir_main_id \
        --id-field   id --parent-field parent_id
"""
import os
import sys
import json
import argparse
from collections import Counter, defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from df_api import DynForm


def tree_stats(nodes, id_field="id", parent_field="parent_id"):
    mp = {}
    for it in nodes:
        if it.get(id_field) and it.get(parent_field):
            mp[it[id_field]] = {
                **it, "children": [],
                "parentId": None if str(it[parent_field]) == "0" else it[parent_field],
            }
    for it in nodes:
        if (it.get(id_field) and it.get(parent_field)
                and mp.get(it[id_field]) and mp.get(it[parent_field])):
            pid = mp[it[id_field]]["parentId"]
            if pid is not None:
                mp[pid]["children"].append(mp[it[id_field]])
    roots = [n for n in mp.values() if n["parentId"] is None]

    def depth(n):
        return 1 if not n["children"] else 1 + max(depth(c) for c in n["children"])

    lvl = Counter()

    def walk(n, d=1):
        lvl[d] += 1
        for c in n["children"]:
            walk(c, d + 1)

    for r in roots:
        walk(r)
    return len(mp), (max(depth(r) for r in roots) if roots else 0), dict(sorted(lvl.items()))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir-table", required=True, help="节点/明细表")
    ap.add_argument("--main-table", required=True, help="目录/主表")
    ap.add_argument("--field", required=True, help="分类字段名")
    ap.add_argument("--fk", required=True, help="节点表里指向主表的外键字段")
    ap.add_argument("--id-field", default="id")
    ap.add_argument("--parent-field", default="parent_id")
    ap.add_argument("--published", default="2", help="主表已发布标记值，默认 '2'")
    ap.add_argument("--flag-field", default="flow_startflag", help="主表状态字段名")
    args = ap.parse_args()

    api = DynForm.from_env()

    rows = api.query_table(
        args.dir_table,
        [args.id_field, "ay_name", args.parent_field, args.field, args.fk, "resp_company_id"],
        {"sys_deleteflag": False}, {"proj_code": True},
    )
    mains = api.query_table(
        args.main_table, ["id", args.flag_field, args.field], {"sys_deleteflag": False}
    )
    print("节点表 %s: %d 行" % (args.dir_table, len(rows)))
    print("主表   %s: %d 行" % (args.main_table, len(mains)))

    # ---- 步骤 1: 填充率 ----
    print("\n=== 1. 节点级 %s 填充率 ===" % args.field)
    c = Counter(r.get(args.field) for r in rows)
    total = len(rows) or 1
    for k, v in c.most_common():
        print("   %-45r %5d 行  (%.1f%%)" % (k, v, 100.0 * v / total))
    null_n = c.get(None, 0)
    if null_n:
        print("   >> 警告: %d 行(%.1f%%) 为 NULL —— 此列不宜作逐行过滤锚点"
              % (null_n, 100.0 * null_n / total))
    else:
        print("   >> 无 NULL，逐行过滤安全")

    # ---- 步骤 2: 主表分类 ----
    print("\n=== 2. 主表分类（权威锚点）===")
    for m in sorted(mains, key=lambda x: str(x.get(args.field))):
        print("   main=%s %s=%r %s=%r"
              % (str(m.get("id"))[:8], args.flag_field, m.get(args.flag_field),
                 args.field, m.get(args.field)))

    # ---- 步骤 3: 按 root 聚合 ----
    by_id = {r[args.id_field]: r for r in rows}

    def root_of(rid, g=0):
        cur = rid
        while g < 50:
            p = by_id.get(cur, {}).get(args.parent_field)
            if not p or str(p) == "0" or p not in by_id:
                return cur
            cur = p
            g += 1
        return cur

    print("\n=== 3. 按根树聚合（一个 root 应是单一分类且 100%% 打标）===")
    trees = defaultdict(list)
    for r in rows:
        trees[root_of(r[args.id_field])].append(r)
    for rid, nodes in sorted(trees.items(), key=lambda x: -len(x[1])):
        rn = by_id[rid]
        mid = rn.get(args.fk)
        dist = Counter(n.get(args.field) for n in nodes)
        known = next((m for m in mains if m.get("id") == mid), None)
        flag = known.get(args.flag_field) if known else "<主表无此记录>"
        n, d, _ = tree_stats(nodes, args.id_field, args.parent_field)
        flag_txt = "" if flag == args.published else "  <<< 未发布，会被状态过滤丢弃"
        print("\n   ROOT %s  id=%s" % (rn.get("ay_name"), str(rid)[:8]))
        print("      main=%s %s=%r%s" % (str(mid)[:8], args.flag_field, flag, flag_txt))
        print("      节点=%d 深度=%d 分类分布=%s" % (len(nodes), d, dict(dist)))

    # ---- 步骤 4: 两套过滤对比 ----
    print("\n=== 4. 逐行过滤 vs 目录级过滤 ===")
    ok_mains = {m["id"] for m in mains if str(m.get(args.flag_field)) == args.published}
    for spec in sorted({m.get(args.field) for m in mains} | {r.get(args.field) for r in rows}):
        if spec is None:
            continue
        cur = [r for r in rows
               if r.get(args.field) == spec and r.get(args.fk) in ok_mains]
        sel = {m["id"] for m in mains
               if str(m.get(args.flag_field)) == args.published and m.get(args.field) == spec}
        fix = [r for r in rows if r.get(args.fk) in sel]
        n1, d1, _ = tree_stats(cur, args.id_field, args.parent_field)
        n2, d2, _ = tree_stats(fix, args.id_field, args.parent_field)
        mark = "  <<< 被截断" if n2 > n1 else ("  (一致)" if n1 == n2 else "")
        print("   %-40r 逐行:%4d节点/%d层   目录级:%4d节点/%d层%s"
              % (spec, n1, d1, n2, d2, mark))

    # ---- 孤儿树 ----
    main_ids = {m.get("id") for m in mains}
    refs = {r.get(args.fk) for r in rows}
    orphans = refs - main_ids
    if orphans:
        oc = Counter(r.get(args.fk) for r in rows if r.get(args.fk) in orphans)
        print("\n=== 5. 孤儿引用（节点表引用了主表里不存在的外键）===")
        for k, v in oc.items():
            print("   %s -> %d 行  <<< 旧版残留，勿纳入" % (str(k)[:8], v))


if __name__ == "__main__":
    main()
