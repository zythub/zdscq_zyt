"""按表单名批量匹配系统表单 ID（名称归一化 + 模糊打分）。

用法：
    python match_forms.py --names names.txt --out matched.json
    python match_forms.py --names names.txt --out matched.json --fallback-drop 分部

names.txt 每行一个表单名（可带"表3.0.12-1 "这类编号前缀）。
输出 matched.json:
    {"matched": [{"input":..., "id":..., "name":..., "score":...}],
     "missing": [{"input":...}],
     "dup_ids": {"<id>": ["<编号1>", "<编号2>"]}}
"""
import os
import sys
import re
import json
import argparse
from collections import defaultdict
from difflib import SequenceMatcher

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from df_api import DynForm

# 形似字 / 异体写法
HOMOGLYPHS = [("分布", "分部"), ("检査", "检查"), ("部份", "部分")]


def norm(s, drop=()):
    s = (s or "").strip()                       # 系统名可能带尾部制表符
    s = re.sub(r"^表\s*", "", s)                # 剥"表"
    s = re.sub(r"\([^)]*\)", "", s)             # 去括号: 分部(子分部) → 分部
    s = re.sub(r"^[\d.]+\s*[-–]?\s*", "", s)    # 去编号前缀: 3.0.13-1 / 14建筑…
    s = re.sub(r"\d+标段", "", s)
    for a, b in HOMOGLYPHS:
        s = s.replace(a, b)
    for w in drop:
        s = s.replace(w, "")
    return re.sub(r"\s+", "", s)


def num_of(s):
    m = re.match(r"^表?\s*([\d.]+(?:-\d+)?)", (s or "").strip())
    return m.group(1) if m else ""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--names", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--fallback-drop", nargs="*", default=["分部", "子分部"])
    ap.add_argument("--min-score", type=float, default=0.82)
    args = ap.parse_args()

    names = [l.strip() for l in open(args.names, encoding="utf-8") if l.strip()]
    api = DynForm.from_env()
    forms = api.list_forms()

    pool = [{"id": f.get("code"), "name": (f.get("value") or "").strip(),
             "n1": norm(f.get("value")), "n2": norm(f.get("value"), args.fallback_drop)}
            for f in forms]

    matched, missing = [], []
    for raw in names:
        a1, a2 = norm(raw), norm(raw, args.fallback_drop)
        best = None
        for p in pool:
            s = max(SequenceMatcher(None, a1, p["n1"]).ratio(),
                    SequenceMatcher(None, a2, p["n2"]).ratio())
            if a1 and a1 == p["n1"]:
                s = 1.0
            if best is None or s > best[0]:
                best = (s, p)
        if best and best[0] >= args.min_score:
            matched.append({"input": raw, "id": best[1]["id"],
                            "name": best[1]["name"], "score": round(best[0], 3)})
        else:
            missing.append({"input": raw, "best": best[1]["name"] if best else None,
                            "score": round(best[0], 3) if best else 0.0})

    # 同一系统表单被多个编号引用 → 去重提示
    by_id = defaultdict(list)
    for m in matched:
        by_id[m["id"]].append(num_of(m["input"]) or m["input"])
    dup_ids = {i: v for i, v in by_id.items() if len(v) > 1}

    out = {"matched": matched, "missing": missing, "dup_ids": dup_ids,
           "unique_ids": len(by_id), "input_count": len(names)}
    json.dump(out, open(args.out, "w", encoding="utf-8"), ensure_ascii=False, indent=2)

    print("输入 %d 条 → 匹配 %d 条，未匹配 %d 条" % (len(names), len(matched), len(missing)))
    print("唯一系统表单 ID: %d" % len(by_id))
    for m in missing:
        print("   MISSING %-45s (最接近: %s %.2f)" % (m["input"], m["best"], m["score"]))
    if dup_ids:
        print("\n以下系统表单被多个编号引用（写入时会去重）：")
        for i, v in dup_ids.items():
            print("   %s  别名: %s" % (i, v))
    print("\n->", args.out)


if __name__ == "__main__":
    main()
