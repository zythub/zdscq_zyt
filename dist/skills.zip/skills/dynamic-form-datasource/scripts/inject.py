"""批量注入 / 替换表单数据源。

安全流程：回路验证 → 逐表单(GET → 备份 → 改 code → 确保预暖 → PUT(须200) → 二次 GET 校验)

用法：
    export BSTD_TOKEN=...; export DF_BASE=http://host:port
    python inject.py --plan plan.json --template assets/datasource_dir_tree.js \
                     --ds-title vqy_quality_acceptance_dir --var SPECIALTIES \
                     --map specialties.json

    --plan       {"<formId>": "<分类名>", ...}
    --map        {"<分类名>": ["<枚举1>", "<枚举2>"], ...}
    --template   含 `const <VAR> = [...];` 这一行的 JS，本脚本按分类替换该行
    --no-prewarm 跳过 created 预暖注入
"""
import os
import sys
import json
import time
import uuid
import argparse
import datetime
from collections import Counter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from df_api import DynForm

EVENT_SIG = "module.exports = function (params, ctx, block) {"


def prewarm_block(ds_title):
    return (
        "\n  /* === 预暖-start === */\n"
        "  // 表单创建即预热数据源，使控件首点即命中缓存、秒出\n"
        "  try {\n"
        "    if (ctx && ctx.datasource && typeof ctx.datasource['%s'] === 'function') {\n"
        "      ctx.datasource['%s']();\n"
        "    }\n"
        "  } catch (e) {}\n"
        "  /* === 预暖-end === */\n" % (ds_title, ds_title)
    )


def build_code(tpl, var, values):
    """把模板里的 `const VAR = [...];` 替换成目标取值。"""
    import re
    arr = "[" + ", ".join('"%s"' % v for v in values) + "]"
    new_line = "const %s = %s;" % (var, arr)
    pat = re.compile(r"^const\s+%s\s*=\s*\[[^\]]*\]\s*;\s*$" % re.escape(var), re.M)
    if not pat.search(tpl):
        raise SystemExit("模板里找不到 `const %s = [...];` 声明行" % var)
    return pat.sub(lambda m: new_line, tpl, count=1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--plan", required=True)
    ap.add_argument("--map", required=True)
    ap.add_argument("--template", required=True)
    ap.add_argument("--ds-title", required=True)
    ap.add_argument("--var", default="SPECIALTIES")
    ap.add_argument("--no-prewarm", action="store_true")
    ap.add_argument("--backup-root", default=".")
    args = ap.parse_args()

    plan = json.load(open(args.plan, encoding="utf-8"))
    smap = json.load(open(args.map, encoding="utf-8"))
    tpl = open(args.template, encoding="utf-8").read()
    unknown = set(plan.values()) - set(smap)
    if unknown:
        raise SystemExit("plan 里有 map 未定义的分类: %s" % unknown)

    CODE = {sp: build_code(tpl, args.var, vals) for sp, vals in smap.items()}
    api = DynForm.from_env()

    # ---- 回路验证 ----
    first = next(iter(plan))
    print("[回路验证] %s" % first)
    d1 = api.get_form(first)
    st, _ = api.put_form(d1)
    d2 = api.get_form(first)
    eq = api.faj(d1) == api.faj(d2)
    print("  PUT=%s deep-equal=%s" % (st, eq))
    if not eq or st not in (200, 201):
        print("  !! 回路不安全，中止")
        sys.exit(1)

    # ---- 取 ADD 用的条目字段模板 ----
    sample_id = first
    pool = api.faj(api.get_form(sample_id)).get("props", {}).get("datasourcePool", [])
    sentry = next((d for d in pool if d.get("title") == args.ds_title), None)
    add_schema = ({k: sentry.get(k) for k in ("desc", "supportDesignerMode")}
                  if sentry else {"desc": "", "supportDesignerMode": True})

    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_dir = os.path.join(args.backup_root, "backup_inject_" + ts)
    os.makedirs(backup_dir, exist_ok=True)
    print("[备份目录] %s" % backup_dir)
    print("[计划] %d 张表单，分布 %s" % (len(plan), dict(Counter(plan.values()))))

    results = []
    for i, (fid, sp) in enumerate(plan.items(), 1):
        try:
            data = api.get_form(fid)
            json.dump(data, open(os.path.join(backup_dir, fid + ".json"), "w", encoding="utf-8"),
                      ensure_ascii=False)

            faj = json.loads(data["formAttributeJson"])
            props = faj.setdefault("props", {})
            pool = props.setdefault("datasourcePool", [])
            entry = next((d for d in pool if d.get("title") == args.ds_title), None)
            new_code = CODE[sp]

            if entry is None:
                entry = {"id": uuid.uuid4().hex, "title": args.ds_title,
                         "desc": add_schema.get("desc", ""),
                         "supportDesignerMode": add_schema.get("supportDesignerMode", True),
                         "code": new_code}
                pool.append(entry)
                action = "ADDED_ENTRY"
            elif (entry.get("code") or "").strip() == new_code.strip():
                action = "CODE_SAME"
            else:
                entry["code"] = new_code
                action = "CODE_REPLACED"

            if args.no_prewarm:
                prewarm_action = "SKIPPED"
            else:
                events = props.setdefault("events", [])
                created = next((e for e in events if e.get("event") == "created"), None)
                pb = prewarm_block(args.ds_title)
                if created is not None:
                    ci = created.setdefault("codeItem", {})
                    old = ci.get("code", "") or ""
                    if "预暖-start" in old:
                        prewarm_action = "PREWARM_EXISTS"
                    else:
                        idx = old.find(EVENT_SIG)
                        if idx != -1:   # 插入，保留原有逻辑
                            ci["code"] = old[:idx + len(EVENT_SIG)] + pb + old[idx + len(EVENT_SIG):]
                        else:
                            ci["code"] = old.rstrip() + pb + "\n}"
                        prewarm_action = "PREWARM_INSERTED"
                else:
                    events.append({"event": "created",
                                   "codeItem": {"code": EVENT_SIG + pb + "}\n"}})
                    prewarm_action = "PREWARM_CREATED"

            data["formAttributeJson"] = json.dumps(faj, ensure_ascii=False)
            st, raw = api.put_form(data)
            if st not in (200, 201):
                results.append({"id": fid, "specialty": sp, "status": "PUT_FAIL_%s" % st,
                                "info": {"action": action, "prewarm": prewarm_action,
                                         "raw": str(raw)[:300]}})
                print("[%d/%d] PUT_FAIL_%s %s %s" % (i, len(plan), st, sp, fid))
                continue

            # 二次校验
            vfaj = api.faj(api.get_form(fid))
            ventry = next((d for d in vfaj.get("props", {}).get("datasourcePool", [])
                           if d.get("title") == args.ds_title), None)
            if ventry is None or (ventry.get("code") or "").strip() != new_code.strip():
                status = "VERIFY_FAIL"
            elif not args.no_prewarm and not any(
                    e.get("event") == "created" and "预暖-start" in ((e.get("codeItem") or {}).get("code") or "")
                    for e in vfaj.get("props", {}).get("events", [])):
                status = "VERIFY_NOPREWARM"
            else:
                status = "OK"
            results.append({"id": fid, "specialty": sp, "status": status,
                            "info": {"action": action, "prewarm": prewarm_action}})
            print("[%d/%d] %-16s %-6s %s" % (i, len(plan), status, sp, fid))
        except Exception as ex:
            results.append({"id": fid, "specialty": sp, "status": "EXCEPTION", "info": repr(ex)})
            print("[%d/%d] EXCEPTION %s %s %s" % (i, len(plan), sp, fid, ex))

    print("\nSUMMARY:", dict(Counter(r["status"] for r in results)))
    out = os.path.join(backup_dir, "results.json")
    json.dump({"ts": ts, "results": results}, open(out, "w", encoding="utf-8"),
              ensure_ascii=False, indent=2)
    print("results ->", out)


if __name__ == "__main__":
    main()
