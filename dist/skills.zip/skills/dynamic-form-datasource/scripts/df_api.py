"""动态表单平台 API 客户端（共用）。

用法：
    from df_api import DynForm
    api = DynForm.from_env()          # 读 BSTD_TOKEN / DF_BASE
    forms = api.list_forms()          # [{code(id), value(name)}]
    data  = api.get_form(fid)
    api.put_form(data)
    rows  = api.query_table("tb_name", ["id","name"], {"sys_deleteflag": False})
"""
import os
import json
import time
import ssl
import urllib.request
import urllib.error


class DynForm:
    def __init__(self, base, token, timeout=90):
        self.base = base.rstrip("/")
        self.token = token
        self.timeout = timeout
        self._ctx = ssl.create_default_context()
        self._ctx.check_hostname = False
        self._ctx.verify_mode = ssl.CERT_NONE

    @classmethod
    def from_env(cls):
        token = os.environ.get("BSTD_TOKEN") or os.environ.get("DF_TOKEN")
        base = os.environ.get("DF_BASE")
        if not token or not base:
            raise SystemExit("需要环境变量 BSTD_TOKEN 与 DF_BASE（DF_BASE 不含 /apis）")
        return cls(base, token)

    def _req(self, method, path, body=None):
        url = self.base + "/apis" + path
        data = json.dumps(body, ensure_ascii=False).encode("utf-8") if body is not None else None
        req = urllib.request.Request(url, data=data, method=method)
        req.add_header("Authorization", "Bearer " + self.token)
        req.add_header("Content-Type", "application/json")
        try:
            with urllib.request.urlopen(req, timeout=self.timeout, context=self._ctx) as r:
                return r.status, json.loads(r.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            return e.code, e.read().decode("utf-8", "replace")

    def req(self, method, path, body=None, tries=4):
        last = None
        for i in range(tries):
            st, raw = self._req(method, path, body)
            if st in (200, 201):
                return st, raw
            last = (st, raw)
            time.sleep(1.5 * (i + 1))
        return last or ("NONE", "")

    # ---- 表单 ----
    def list_forms(self):
        st, resp = self.req("GET", "/dynamic/form")
        if st != 200 or not isinstance(resp, dict) or resp.get("code") != 200:
            raise RuntimeError("list_forms 失败: %s %s" % (st, str(resp)[:200]))
        return resp["data"]

    def get_form(self, fid):
        st, resp = self.req("GET", "/dynamic/form/%s" % fid)
        if st != 200 or not isinstance(resp, dict) or resp.get("code") != 200:
            raise RuntimeError("get_form(%s) 失败: %s %s" % (fid, st, str(resp)[:200]))
        return resp["data"]

    def put_form(self, data):
        """更新表单。id 在 body 里。必须返回 200 才算成功。"""
        return self.req("PUT", "/dynamic/form", data)

    def faj(self, form_data):
        """取已解析的 formAttributeJson dict。"""
        raw = form_data.get("formAttributeJson")
        return json.loads(raw) if isinstance(raw, str) else (raw or {})

    # ---- 业务表 ----
    def query_table(self, tb, fields, query_map=None, order_by=None):
        body = {"tbName": tb, "fields": fields, "queryMap": query_map or {}}
        if order_by:
            body["orderBy"] = order_by
        st, resp = self.req("POST", "/dynamic/function/api/table", body)
        if st != 200:
            return []
        d = resp.get("data")
        if isinstance(d, list):
            return d
        d = d or {}
        return d.get("list") or d.get("records") or []
