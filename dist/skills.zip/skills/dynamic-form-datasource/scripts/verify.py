"""独立复核：线上逐表单确认数据源代码已生效（与 inject.py 分开，避免同源误判）。

用法：
    python verify.py --plan plan.json --map specialties.json \
                     --ds-title vqy_quality_acceptance_dir --var SPECIALTIES \
                     [--require-prewarm] [--require-cache __CACHE__]
"""
import os
import sys
import json
import argparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from df_api import DynForm


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--plan", required=True)
    ap.add_argument("--map", required=True)
    ap.add_argument("--ds-title", required=True)
    ap.add_argument("--var", default="SPECIALTIES")
    ap.add_argument("--require-prewarm", action="store_true")
    ap.add_argument("--require-cache", default="__CACHE__")
    args = ap.parse_args()

    plan = json.load(open(args.plan, encoding="utf-8"))
    smap = json.load(open(args.map, encoding="utf-8"))
    api = DynForm.from_env()

    bad = []
    for fid, sp in plan.items():
        vals = smap.get(sp)
        if vals is None:
            bad.append((fid, sp, "map 缺少分类定义"))
            continue
        faj = api.faj(api.get_form(fid))
        props = faj.get("props") or {}
        entry = next((d for d in (props.get("datasourcePool") or [])
                      if d.get("title") == args.ds_title), None)
        if entry is None:
            bad.append((fid, sp, "无数据源条目"))
            continue
        code = entry.get("code", "") or ""
        want = "const %s = [%s];" % (args.var, ", ".join('"%s"' % v for v in vals))
        problems = []
        if want not in code:
            problems.append("VAR声明不符")
        if args.require_cache and args.require_cache not in code:
            problems.append("无缓存")
        if args.require_prewarm and not any(
                e.get("event") == "created"
                and "预暖-start" in ((e.get("codeItem") or {}).get("code") or "")
                for e in (props.get("events") or [])):
            problems.append("无预暖")
        if problems:
            bad.append((fid, sp, "/".join(problems)))

    total = len(plan)
    print("校验通过: %d / %d" % (total - len(bad), total))
    for b in bad:
        print("   FAIL %s [%s] %s" % (b[1], b[2], b[0]))
    print("\nALL:", "PASS" if not bad else "FAIL")
    sys.exit(0 if not bad else 1)


if __name__ == "__main__":
    main()
