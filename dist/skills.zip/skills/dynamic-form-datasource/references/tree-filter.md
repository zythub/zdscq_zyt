# 目录树被截断：诊断与正确写法

> 症状：「这个树只有三层了，实际下面还有很多的」
> 本质：**过滤锚点选错了表**。列存在 ≠ 列有值。

## 一句话结论

**分类过滤要用母表（目录/主表）那一行，不要用子表（节点/明细）逐行过滤。**

母表一行 = 一个分类的完整目录，分类标识在母表上一定填了。
子表同名字段常常大面积为 NULL，逐行过滤会把子节点连同父节点一起砍掉，
只剩几个恰好首尾相连的节点——看起来像"树变浅了"。

## 真实事故复盘

质量验收目录，两套表：

- `tqy_quality_acceptance_dir_main` —— **目录主表**，一行 = 一个专业的完整目录，
  有 `specialty` 字段 + `flow_startflag`（"2" = 已发布）
- `tqy_quality_acceptance_dir` —— 节点表，也有一个 `specialty` 字段

原代码按**节点表**逐行过滤 `item.specialty === 土建枚举`：

| 专业 | 已发布目录节点数 | 节点级 specialty 填了值的 | 结果 |
|---|---|---|---|
| 土建 | 349 | **3** | 只剩 3 个节点 → 3 层 |
| 锅炉 | 342 | **2** | 只剩 2 个节点 → 2 层 |
| 汽机 | 342 | 342（100%） | 正常 |
| 热控 | 342 | 342（100%） | 正常 |
| 焊接 | 342 | 342（100%） | 正常 |

全表 2405 行里 **1272 行 specialty 是 NULL**。汽机/热控/焊接"看起来正常"纯粹是运气——
它们的数据是全量打标的，土建/锅炉没有。

修复后：土建 3/3层 → **349/8层**，锅炉 2/2层 → **342/5层**，其余三个**零回归**。

### 叠加的第二个坑

土建已发布目录在**主表**里的值是 `qy_acceptance_specialty2-tj`，
而代码里写的是 `qy_acceptance_specialty_tj-tj`——**两个不同的枚举**。
所以即使改成按主表过滤，也要先确认主表里的实际取值，不能沿用旧常量。

稳妥做法：**兼容多个枚举值**。

```js
const SPECIALTIES = ["qy_acceptance_specialty_tj-tj", "qy_acceptance_specialty2-tj"];
```

## 诊断四步

### 1. 查填充率

```python
Counter(r.get("<filter_field>") for r in rows)
```

如果 NULL 占比很高（>20%），**立刻停手**，这个列不能当逐行过滤锚点。

### 2. 按 root 聚合，看每棵树的分类分布

沿 `parent_id` 上溯到根，把节点按 root 分组，统计每组里分类字段的分布。
健康的树：一个 root 下**单一分类、且 100% 打标**。
有问题的树：一个 root 下混杂多个分类 + 大量 NULL。

### 3. 对比过滤前后的节点数与深度

```python
def tree_stats(nodes):
    mp = {}
    for it in nodes:
        if it.get("id") and it.get("parent_id"):
            mp[it["id"]] = {**it, "children": [],
                            "parentId": None if str(it["parent_id"]) == "0" else it["parent_id"]}
    for it in nodes:
        if it.get("id") and it.get("parent_id") and mp.get(it["id"]) and mp.get(it["parent_id"]):
            pid = mp[it["id"]]["parentId"]
            if pid is not None:
                mp[pid]["children"].append(mp[it["id"]])
    roots = [n for n in mp.values() if n["parentId"] is None]
    # 深度 + 每层节点数
```

**深度突然变浅 + 节点数断崖** = 过滤把中间层砍了。

### 4. 检查孤儿节点与"已发布"过滤

- 父节点不在结果集里 → 整条子树消失（不是"少一层"，是"少一片"）
- 若还有 `flow_startflag === "2"` 之类的状态过滤，确认它会不会把整棵目录一起丢掉。
  本次事故里，含 75 个土建节点的旧目录就是被这个过滤整体丢弃的。

`scripts/diagnose_tree.py` 把这四步一次跑完。

## 正确写法

```js
module.exports = async function (ctx, payload) {
  const SPECIALTIES = ["<枚举1>", "<枚举2>"];
  const cacheKey = companyId + "::" + SPECIALTIES.join(",");
  if (__CACHE__[cacheKey]) return __CACHE__[cacheKey];

  // ① 母表：一行 = 一个分类的完整目录
  const mainRes = await ctx.http.request("POST", "/dynamic/function/api/table")({
    tbName: "<主表>", fields: ["id", "flow_startflag", "<分类字段>"],
    queryMap: { sys_deleteflag: false },
  });
  const mainIds = (mainRes || [])
    .filter(m => m.flow_startflag === "2" && SPECIALTIES.indexOf(m["<分类字段>"]) !== -1)
    .map(m => m.id);
  if (!mainIds.length) return [];

  // ② 子表：按外键整棵纳入，不再逐行过滤分类
  const res = await ctx.http.request("POST", "/dynamic/function/api/table")({
    tbName: "<节点表>",
    fields: ["id", "ay_name", "parent_id", "<外键>", "<其他>"],
    orderBy: { proj_code: true },
    queryMap,
  });
  const rows = (res || []).filter(r => mainIds.indexOf(r["<外键>"]) !== -1);

  // ③ 建树（同原逻辑）
  __CACHE__[cacheKey] = result;
  return result;
};
```

## 通用检查清单

写任何"按分类过滤取树"的数据源前，逐条确认：

- [ ] 分类标识到底在**哪张表**是权威的？（母表优先）
- [ ] 主表里该字段的**实际取值**是什么？（查 distinct，别沿用旧常量）
- [ ] 子表同名字段的 **NULL 占比**是多少？
- [ ] 状态过滤（`flow_startflag` 之类）会不会把整棵目录丢掉？
- [ ] 是否混入了**孤儿树**（节点表引用了主表里已不存在的外键）？
- [ ] 公司/租户过滤字段在目标树上填充率如何？（本次 `resp_company_id` 100%，安全）
- [ ] 缓存 key 是否包含**全部分类维度**？
