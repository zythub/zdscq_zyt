# 动态表单「表单设计」PUT 更新指南

> 适用范围：自研动态表单平台（API 网关前缀 `/apis`，Bearer 鉴权）。
> 本文档以 **1103 环境质量验收表单** 为实测对象整理，操作步骤与数据结构可直接复用到
> 同平台的其它环境（测试 / 生产 / 新项目）。
> 文档配套脚本：本仓库 `examples/1103_codes/inject_60.py`、`inject_fix.py`、`modify_datasource.py`；
> 通用版脚本见 skill `dynamic-form-datasource/scripts/`。

---

## 1. 一句话结论

**修改一张表单的"表单设计"，就是：`GET /dynamic/form/{id}` 取整条记录 → 改里面的
`formAttributeJson`（一个 JSON 字符串，内含控件树/数据源/事件）→ 把**整条记录原样**
`PUT /dynamic/form`（id 在 body）→ 再 GET 校验。** 全程是"全量替换"，没有局部 PATCH。

---

## 2. 三个最容易踩的坑（先记住）

| # | 坑 | 真相 |
|---|---|---|
| 1 | PUT 打到 `PUT /dynamic/form/{id}` | **405**。更新端点是**集合路径** `PUT /dynamic/form`，id 放 body。`/{id}` 只允许 GET/DELETE/OPTIONS |
| 2 | PUT 后"GET 出来和之前一样"，以为成功了 | **误报**。PUT 静默失败时 GET 当然还是原样。**必须校验 HTTP 200** |
| 3 | 表单的事件在 `instance.events` 里找 | 读错地方会误判"事件没写进去"。**根实例事件在 `props.events`** |

---

## 3. 数据模型

### 3.1 表单记录（GET 返回的 `data`）

| 字段 | 类型 | 说明 |
|---|---|---|
| `id` | str | **API 主键（32 位 hex）**，PUT 时必须有 |
| `name` | str | 表单名 |
| `type` | str | 如 `form_category-form_flow` |
| `dyFormCategoryId` | str | 所属分类 |
| `enableTable` | bool | 是否启用数据表 |
| `formOwner` | str | 创建人 |
| `formCode` / `listCode` | null | 常为 null；前端路由里的业务码（如 `QY_P301321`）**无法**经此 API 反查 |
| `descDetails` / `mainTable` / `dyFormFieldVos` / `code` | null | 保留原值即可 |
| **`formAttributeJson`** | **str** | **表单设计本体，JSON 字符串**，需 `json.loads` 再改 |

### 3.2 `formAttributeJson` 内部结构（设计 JSON）

```jsonc
{
  "id": "<设计根节点id>",
  "type": "form",
  "props": {                    // ← 关键都在这里
    "visible": true,
    "events": [...],            // 根实例事件（created 等）
    "datasourcePool": [...],    // 数据源池
    "utilsJs": [...],           // 公共工具函数
    "stylesheets": [...],
    "relations": [...],
    "labelPosition": "left",
    "width": "100%",
    "size": "middle",
    "useDefaultGrid": true,
    "defaultGridSize": 2,
    "labelWidth": "100px",
    "colon": false
  },
  "children": [ ... ]           // 控件树（栅格/表单控件/子表单…）
}
```

### 3.3 `datasourcePool` 条目（数据源）

```jsonc
{
  "id": "",                          // 新增条目时给 uuid4().hex；改已有条目保留原 id
  "title": "vqy_quality_acceptance_dir",   // 控件引用的数据源名，不能改
  "desc": "质量验收表单",
  "supportDesignerMode": false,
  "code": "module.exports = async function (ctx, payload) { ... }"
}
```

- `code` 是**内嵌 JS 字符串**，运行时由 Proxy 执行；改代码 = 替换整个 `code` 字段。
- 数据源内发请求的标准姿势：`ctx.http.request("POST","/dynamic/function/api/table")({tbName,fields,queryMap,orderBy})`。
- 新增条目时，`desc` / `supportDesignerMode` 照抄同表单里已有条目的值。

### 3.4 `events` 条目（根实例事件）

```jsonc
{ "event": "created",
  "codeItem": { "code": "module.exports = function (params, ctx, block) { ... }",
                "utils": [] } }
```

- 事件签名固定 `module.exports = function (params, ctx, block) {`。
- `ctx` 由 `getContextApi()` 提供，带 `.datasource`，可用来预暖数据源。

---

## 4. 完整操作流程（Python）

依赖：python3，`requests` 或用标准库。token 走**环境变量**，不要落盘、不要写进代码。

```bash
export DF_TOKEN="<bearer token>"
export DF_BASE="http://<host>:<port>"      # 不含 /apis
```

```python
import os, json, urllib.request, urllib.error

BASE = os.environ["DF_BASE"] + "/apis"
TOKEN = os.environ["DF_TOKEN"]

def req(method, path, body=None):
    data = json.dumps(body, ensure_ascii=False).encode() if body is not None else None
    r = urllib.request.Request(BASE + path, data=data, method=method)
    r.add_header("Authorization", "Bearer " + TOKEN)
    r.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(r, timeout=90) as resp:
            return resp.status, json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read().decode() or "{}")

def get_form(fid):
    st, resp = req("GET", f"/dynamic/form/{fid}")
    assert st == 200 and resp.get("code") == 200, (st, resp)
    return resp["data"]                     # 整条表单记录

def put_form(data):
    st, resp = req("PUT", "/dynamic/form", data)   # ★ 集合路径，id 在 body
    assert st in (200, 201), f"PUT 失败 HTTP {st}: {resp}"
    return resp
```

### 4.1 改一张表单（三步）

```python
data = get_form(fid)                        # ① 取整条
faj  = json.loads(data["formAttributeJson"]) # ② 解析设计 JSON
# ...改 props.datasourcePool / props.events / children...
data["formAttributeJson"] = json.dumps(faj, ensure_ascii=False)  # ★ 转回字符串
put_form(data)                              # ③ PUT 整条
```

### 4.2 安全前置：回路验证（首次连一个环境必做）

先验证"GET 原样 PUT 回去不会坏"——能提前暴露平台丢字段/改结构的问题：

```python
d1 = get_form(sample_id)
st, _ = put_form(d1)                          # 原样写回
d2 = get_form(sample_id)
assert json.loads(d1["formAttributeJson"]) == json.loads(d2["formAttributeJson"]), "回路不安全"
```

### 4.3 写回后校验（每个表单都要做）

```python
v = get_form(fid)
vfaj = json.loads(v["formAttributeJson"])
# 校验点：code 已替换 / created 预暖已在 events 里，等等
```

### 4.4 备份与回滚

逐表单 PUT 前把 `data`（整条 GET 结果）落盘到 `backup/<时间戳>/<fid>.json`。
回滚 = 用备份文件原样 PUT 回去。批次结果记录到同目录 `results.json`。

---

## 5. 典型改动示例（真实做过）

### 5.1 替换某数据源的 code

```python
faj = json.loads(data["formAttributeJson"])
pool = faj.setdefault("props", {}).setdefault("datasourcePool", [])
entry = next((d for d in pool if d.get("title") == "vqy_quality_acceptance_dir"), None)
if entry is None:                     # 没有 → 新增一条
    pool.append({"id": uuid.uuid4().hex, "title": "vqy_quality_acceptance_dir",
                 "desc": "质量验收表单", "supportDesignerMode": False,
                 "code": new_code})
else:                                 # 有 → 替换 code（保留原 id）
    entry["code"] = new_code
```

### 5.2 给根表单加 `created` 预暖事件（**插入，不覆盖**）

事件里常有业务逻辑，整体替换会毁掉。正确做法：定位 `codeItem.code` 的签名行，把预暖块
**插在签名行之后**：

```python
SIG = "module.exports = function (params, ctx, block) {"
WARM = """
  /* === 预暖-start === */
  try {
    if (ctx && ctx.datasource && typeof ctx.datasource['<数据源title>'] === 'function') {
      ctx.datasource['<数据源title>']();   // 表单创建即预热，控件首点命中缓存
    }
  } catch (e) {}
  /* === 预暖-end === */
"""
events = faj.setdefault("props", {}).setdefault("events", [])
created = next((e for e in events if e.get("event") == "created"), None)
if created is None:
    events.append({"event": "created",
                   "codeItem": {"code": SIG + WARM + "}\n"}})
elif "预暖-start" not in (created.get("codeItem") or {}).get("code", ""):
    old = created["codeItem"]["code"]
    i = old.find(SIG)
    created["codeItem"]["code"] = old[:i+len(SIG)] + WARM + old[i+len(SIG):] if i != -1 \
                                  else old.rstrip() + WARM + "\n}"
```

配套的"首点秒出"缓存写法（放进数据源 code 里，key 必须带全部分类维度）：

```js
const __CACHE__ = (globalThis.__df_cache__ = globalThis.__df_cache__ || {});
const cacheKey = companyId + "::" + SPECIALTIES.join(",");
if (__CACHE__[cacheKey]) return __CACHE__[cacheKey];
// ...取数 + 过滤 + 建树...
__CACHE__[cacheKey] = result;
return result;
```

### 5.3 整包替换 children（大改版式/回灌设计 JSON）

```python
faj["children"] = new_children        # 新控件树
data["formAttributeJson"] = json.dumps(faj, ensure_ascii=False)
put_form(data)
```

> 风险最大，先在一张表单验证整树渲染无误，再批量。

---

## 6. 常见错误速查

| 现象 | 原因 | 处理 |
|---|---|---|
| PUT 返回 405 | 用了 `PUT /form/{id}` | 改用 `PUT /form`，id 在 body |
| PUT 200 但页面没变 | 改完没把 `formAttributeJson` **转回字符串** | `json.dumps(faj, ensure_ascii=False)` |
| 中文/特殊字符乱码 | `ensure_ascii=True`（默认） | 必须 `ensure_ascii=False` |
| GET 显示 code=900 "表单不存在" | id 是短 id / 业务码 | 用 32 位完整 id；业务码无法反查 |
| 找"表单找不到"误报 | 名称尾部带制表符/括号差异 | 名称比较前 `.strip()`；去 `()` 后 `difflib` 打分 |
| 事件总说没写进去 | 读了 `instance.events` | 根实例事件在 `props.events` |
| 数据源返回空树 | 过滤锚点用了填充不全的列 | 见 1103 案例：改为按**目录主表**过滤 |
| 换公司/专业后数据串了 | 缓存 key 只含部分维度 | key 加全部分类维度 |

---

## 7. 实测案例：1103 质量验收表单（三轮，全部 60/60 OK）

| 轮次 | 做了什么 | 备份目录（`examples/1103_backup/`） |
|---|---|---|
| 1 | 66 张表单注入专业数据源（原始模板） | `20260828_093*` / `single_20260828_094926` |
| 2 | 60 张表单：数据源改精简版（globalThis 缓存，key 带专业）+ `created` 预暖 | `inject60_20260828_140110` |
| 3 | 树过滤改为目录级（修复"树只剩三层"：土建 3 节点→349 节点） | `fix_dirlevel_20260828_145817` |

单表单 code 变更实况（土建观感表 `d36ab43b…`）：
- 注入前：`code` 2266 字符，逐节点 `specialty` 过滤、无缓存。
- 注入后：`code` 2716 字符，带 `__CACHE__`、created 预暖（事件 8181→8472 字符，**原逻辑保留**）。

执行脚本：`examples/1103_codes/inject_60.py`、`inject_fix.py`（含回路验证 + PUT 200 校验 +
二次 GET 校验 + 逐条 results.json）。通用版（按 plan 参数化）：skill `dynamic-form-datasource`。

---

## 8. 通用脚本（skill）快速上手

skill 已安装于 `~/.workbuddy/skills/dynamic-form-datasource/`，含：

```
SKILL.md                      # 入口：铁律 / 流程 / 速查
references/api.md             # API 与数据结构
references/tree-filter.md     # 目录树截断诊断（本案复盘）
references/form-design-put-guide.md   # 本文档副本
scripts/df_api.py             # 平台 API 客户端（共用）
scripts/inject.py             # 批量注入（回路验证+备份+PUT+校验）
scripts/verify.py             # 独立复核
scripts/diagnose_tree.py      # 目录树过滤锚点诊断
scripts/match_forms.py        # 表单名→ID 模糊匹配
assets/datasource_dir_tree.js # 目录树数据源模板
```

```bash
export BSTD_TOKEN=...; export DF_BASE=http://<host>:<port>
python scripts/match_forms.py --names names.txt --out plan.json   # 名称→ID
python scripts/inject.py      --plan plan.json --map specialties.json \
                              --template assets/datasource_dir_tree.js \
                              --ds-title vqy_quality_acceptance_dir --var SPECIALTIES
python scripts/verify.py      --plan plan.json --map specialties.json \
                              --ds-title vqy_quality_acceptance_dir --var SPECIALTIES --require-prewarm
```
