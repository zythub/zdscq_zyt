# API 与数据结构参考

所有请求带 `Authorization: Bearer <token>`、`Content-Type: application/json`。
网关前缀统一是 `/apis`。token 只从环境变量读（`BSTD_TOKEN`），不落盘。

## 端点

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/apis/dynamic/form` | 全量表单列表 |
| GET | `/apis/dynamic/form/{id}` | 表单详情 |
| **PUT** | **`/apis/dynamic/form`** | **更新表单（id 在 body）** |
| GET/DELETE | `/apis/dynamic/form/{id}` | 读 / 删。PUT 到这里会 **405** |
| POST | `/apis/dynamic/function/api/table` | 查业务表 |

### GET /apis/dynamic/form

```json
{ "code": 200, "data": [ { "code": "<32位id>", "value": "<表单名称>" } ] }
```

注意 `code` 是**表单 id**，不是业务编码；`value` 是名称。名称可能带尾部制表符，比较前 `.strip()`。

### GET /apis/dynamic/form/{id}

`data` 的字段：

```
code, dyFormCategoryId, name, type, enableTable, formOwner,
formCode, listCode, descDetails, formAttributeJson, id, mainTable, dyFormFieldVos
```

- `formAttributeJson`：**字符串**，需 `json.loads`
- `formCode` / `listCode` 常常是 `null` —— 前端路由里的业务码（如 `QY_P301321`）
  往往**无法**通过此 API 反查，只能从名称侧匹配

### PUT /apis/dynamic/form

把 GET 回来的整个 `data` 对象作为 body（含 id），改完 `formAttributeJson` 再 PUT。
成功返回 200。

> 危险：只比对 PUT 前后 GET 的结果一致会**误报成功**。必须校验 HTTP 状态码。

### POST /apis/dynamic/function/api/table

```json
{
  "tbName": "tqy_quality_acceptance_dir",
  "fields": ["id", "ay_name", "parent_id", "specialty"],
  "queryMap": { "sys_deleteflag": false, "resp_company_id": "..." },
  "orderBy": { "proj_code": true }
}
```

返回包了好几层，且**形状不固定**，必须兼容处理：

```python
d = resp.get("data")
rows = d if isinstance(d, list) else ((d or {}).get("list") or (d or {}).get("records") or [])
```

## formAttributeJson 结构

```jsonc
{
  "type": "...",
  "props": {
    "datasourcePool": [
      { "id": "<uuid hex>", "title": "vqy_quality_acceptance_dir",
        "desc": "质量验收表单", "supportDesignerMode": false,
        "code": "module.exports = async function (ctx, payload) { ... }" }
    ],
    "events": [
      { "event": "created",
        "codeItem": { "code": "module.exports = function (params, ctx, block) { ... }" } }
    ]
  },
  "instance": { ... }
}
```

要点：

- **数据源池在 `props.datasourcePool`，根实例事件在 `props.events`**。
  不是 `instance.events`（容易读错，导致误判"事件没写进去"）。
- 新增数据源条目时，字段照抄同表单里已有条目的 `desc` / `supportDesignerMode`，
  `id` 用 `uuid4().hex`。
- 数据源 `title` 就是控件引用的名字，不能改。

## 代码签名

```js
// 数据源
module.exports = async function (ctx, payload) {
  const rows = await ctx.http.request("POST", "/dynamic/function/api/table")({ ... });
  return tree;
};

// 事件
module.exports = function (params, ctx, block) { ... };
```

事件里 `ctx` 由 `getContextApi()` 提供，带 `.datasource`，可用它预暖数据源。

> 要看"怎么把表单设计 PUT 上去"的完整图文版（含真实 payload 结构、替换数据源、
> 插入 created 预暖、整包换 children、通用脚本用法）→ **`references/form-design-put-guide.md`**。

## 安全流程（照抄）

```
1. token 校验：随便 GET 一个表单，确认 200
2. 回路验证：GET → 原值 PUT → GET，deep-equal 才继续，否则中止
3. 逐表单：GET → 备份 formAttributeJson 到文件 → 改 → PUT(必须200) → 二次 GET 校验
4. 备份目录按时间戳命名，内含 results.json 逐条日志
```
