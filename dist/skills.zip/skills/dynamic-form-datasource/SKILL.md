---
name: dynamic-form-datasource
description: |
  自研动态表单平台（/apis/dynamic/form）的数据源批量注入、改写与排障。
  用于：批量给几十上百张表单注入/替换数据源代码、按表单名模糊匹配系统ID、
  排查「下拉树/级联选项只显示一部分、层级缺失、点一下才加载」等问题；
  以及子表字段从主表带值（手动新增/导入Excel回填/同步按钮）、表单编号规则溯源（dy_number_rule）。
  关键词：动态表单、数据源、datasourcePool、formAttributeJson、目录树截断、
  批量注入、created 预暖、树形控件、子表回填、物资编码、编号规则、getArrayValue、append。
agent_created: true
---

# 动态表单数据源批量注入与排障

适用平台：自研低代码/动态表单系统。表单定义以 **JSON 字符串**存在 `formAttributeJson` 里，
数据源(`datasource`)是内嵌在表单 JSON 中的 JS 代码，运行时由 Proxy 执行。

## 何时用

- 批量给 N 张表单注入 / 替换数据源代码
- 用户给一串表单名，要核对系统里是否存在、拿 ID
- 下拉树 / 级联选项**只显示一部分、层级变少、下面没了**
- 控件"点一下才加载"，加载慢

## 铁律（先读，能省掉 90% 返工）

1. **更新端点是 `PUT /apis/dynamic/form`，id 放 body。**
   不是 `PUT /apis/dynamic/form/{id}` —— 后者只允许 GET/DELETE，会返回 **405**。
2. **先备份 → 回路验证 → 再批量。**
   回路验证 = GET → 把原值原样 PUT 回去 → 再 GET，两边 deep-equal 才准继续。
   这能提前暴露"PUT 会丢字段/改结构"的平台问题。
3. **PUT 必须返回 200 才算成功。**
   只比对 GET 前后一致会**误报成功**——PUT 静默失败时 GET 当然还是原样。
4. **事件代码要"插入"，不要"覆盖"。**
   `created` 等事件里通常已有业务逻辑，整体替换会毁掉。
5. **写过滤条件前先验证那一列的填充率。**
   列存在 ≠ 列有值。这是"树被截断"类问题的头号原因。见 `references/tree-filter.md`。
6. **缓存 key 必须带上所有过滤维度。**
   只按 `companyId` 缓存，多分类场景会串数据（A 分类的预热污染 B 分类）。

## 快速开始

```bash
export BSTD_TOKEN="<bearer token>"        # token 只走环境变量，不落盘
export DF_BASE="http://<host>:<port>"     # 不含 /apis

# 1. 排障：目录树是不是被过滤截断了
python scripts/diagnose_tree.py --dir-table tqy_quality_acceptance_dir \
                                --main-table tqy_quality_acceptance_dir_main \
                                --field specialty

# 2. 注入：按 plan.json 逐表单替换数据源
python scripts/inject.py --plan plan.json --template assets/datasource_dir_tree.js \
                         --ds-title vqy_quality_acceptance_dir --var SPECIALTIES

# 3. 校验：线上逐表单确认代码已生效
python scripts/verify.py --plan plan.json --ds-title vqy_quality_acceptance_dir --var SPECIALTIES
```

`plan.json` 格式（`{"<formId>": "<分类名>", ...}`），分类名 → 过滤值的映射写在
`assets/plan_specialties.json` 或由 `--map` 传入。

## 标准流程

### A. 批量注入 / 替换数据源

1. 建 plan：`{formId: 分类}`。
2. 跑 `diagnose_tree.py` 确认过滤锚点选对（**不要跳过**）。
3. 跑 `inject.py`：逐表单 `GET → 备份 → 改 code → 确保预暖 → PUT → 二次 GET 校验`。
4. 跑 `verify.py` 独立复核。
5. 报告：成功数、备份目录、需人工确认的冲突项。

每轮在开始前自动做一次回路验证，不通过直接中止。

### B. 表单名 → 系统 ID 匹配

系统里表单命名极不规范，直接全等匹配会大量误报"不存在"。归一化函数：

```python
def norm(s):
    s = s.strip()                       # 系统名可能带尾部制表符
    s = re.sub(r'^表\s*', '', s)        # 剥"表"
    s = re.sub(r'\([^)]*\)', '', s)     # 去括号内容：分部(子分部) → 分部
    s = re.sub(r'^[\d.]+\s*', '', s)    # 去编号前缀：3.0.13-1 / 14建筑…
    s = re.sub(r'\d+标段', '', s)
    s = s.replace('分布', '分部').replace('检査', '检查')   # 形似字
    return re.sub(r'\s+', '', s)
```

去括号后仍匹配不上，再试**去掉"分部"**（同系列有的保留有的省略）。
匹配到多个时用 `difflib.SequenceMatcher` 打分取最高，不要盲目取第一个。

**注意去重**：同一张系统表单常被多个业务编号引用（别名）。
按 `编号` 计数会虚高，**按系统 ID 去重**才是真实写入量。

### C. 加载慢 / "点一下才加载"

根因链条：

- `datasource` 是 Proxy，**每次调用重跑代码且无结果缓存**（`utils` 才有缓存）。
- 取数在控件 `useEffect(mount)` 触发，而控件在 Tab/折叠/分步里是**懒挂载**的。

解法，两件事一起做：

1. **函数内 globalThis 缓存**：开头读、结尾写，key 带全部过滤维度。
2. **`created` 事件预暖**：表单创建时调一次数据源填满缓存，控件首点即命中。

```js
// 数据源函数内
const __CACHE__ = (globalThis.__my_cache__ = globalThis.__my_cache__ || {});
const cacheKey = companyId + "::" + SPECIALTIES.join(",");   // 维度要全
if (__CACHE__[cacheKey]) return __CACHE__[cacheKey];
// ...取数、过滤、建树...
__CACHE__[cacheKey] = result;
return result;
```

预暖事件（插到 `created` 已有代码的签名行之后，不覆盖）：

```js
try {
  if (ctx && ctx.datasource && typeof ctx.datasource['<数据源title>'] === 'function') {
    ctx.datasource['<数据源title>']();
  }
} catch (e) {}
```

## 关键结构速查

| 位置 | 说明 |
|---|---|
| `GET /apis/dynamic/form` | 全量表单，项 `{code, value}`（**code = id**，value = 名称） |
| `GET /apis/dynamic/form/{id}` | 详情，`formAttributeJson` 是**字符串**，需 `json.loads` |
| `PUT /apis/dynamic/form` | **更新端点**，id 在 body |
| `POST /apis/dynamic/function/api/table` | 查业务表 `{tbName, fields, queryMap, orderBy}`；`data` 可能是 list 也可能是 `{list\|records}`，要兼容 |
| `props.datasourcePool[]` | 数据源池，条目 `{id, title, desc, supportDesignerMode, code}` |
| `props.events[]` | **根实例**事件（`{event, codeItem:{code}}`）。注意不是 `instance.events` |
| 数据源签名 | `module.exports = async function (ctx, payload) {...}` |
| 事件签名 | `module.exports = function (params, ctx, block) {...}` |
| 数据源内发请求 | `ctx.http.request("POST", "/dynamic/function/api/table")({...})` |

## 常见坑

| 现象 | 原因 | 处理 |
|---|---|---|
| PUT 全 405 | 用了 `PUT /form/{id}` | 改集合路径，id 放 body |
| 注入后表单空白 | 枚举值猜错（下划线 vs 连字符） | 从生产库查 distinct 值，别猜 |
| 树只有两三层 | 过滤锚点用了填充不全的子表列 | 见 `references/tree-filter.md` |
| 换分类后数据不对 | 缓存 key 缺过滤维度 | key 加分类 |
| "找不到表单" | 名称没归一化 | 见 B 节归一化 |
| 注入慢 | 逐表单串行 3 请求 | 正常，60 张约 10 秒；别并行写，先做回路验证 |

## 平台自定义 React 组件的运行机制陷阱

> 用平台"自定义组件"（React JSX）做**带编辑态的仪表盘/数据页**时必读。
> 实锤案例：项目进度总览组件，改日期后全部字段被重置，排查了两轮。

**机制（有 console 证据）：平台在每次交互时把自定义组件代码整个重新执行、
重建 React 根**。表现为控制台 `VM3682 → VM3683`（脚本上下文每次变化）、
`mount` 日志随每次交互反复打印。后果：

1. React state / `useRef` / `globalThis` **全部活不过一次交互**；
2. 挂载 effect 里的 `fetchData` 会重新用服务端数据**覆盖本地未保存修改**；
3. 若服务端无保存记录，页面直接回退默认值 = "全字段被重置"。

**正确写法（不要再把业务数据放 React state 当真相源）：**

1. **localStorage 是唯一真相源**，key 按 org/业务维度分桶（如 `__xmjdbfb_page_{org}__`）；
2. React 只当"空壳挂载点"：`useEffect` 里对空 `<div ref>` 一次性
   `innerHTML = "<style>…</style>" + 静态页面`，然后调用原生逻辑 `mountXmjd(box)`
   （事件监听、渲染全用 `box.querySelector('#id')` 作用域化）；
3. 每次写入 = **读整份缓存 → 全字段展开 → 只改目标字段 → 写回整份**，
   绝不用内存镜像做基准（否则新实例上首笔编辑会把缓存冲成残缺对象）；
4. 本地改过的字段记 `dirty[]`，后台/挂载时的服务端刷新**不允许覆盖 dirty 字段**；
5. 服务端空返回时保留现状不清页面（首次无缓存才显示空结构）；
6. 组件文件保持纯 JSX 可编译：页面用模板字符串注入，**不要粘贴整份 HTML**（JSX 编译不过）；
7. **要在注入页面里用平台 antd 控件（DatePicker 等）**：别塞回 HTML 模板，用 React 壳的
   `createPortal` 渲染——LAYOUT 里留空容器 `<div data-datepicker="sjkgsj">`，App 里
   `createPortal(<DatePicker value=… onChange=…/>, box.querySelector('[data-datepicker=…]'))`；
   业务层 `render()` 不再写 `input.value`，改为 `hooks.onDates(f)` 把日期字段推给 React
   （内部做值比较，无变化不 setState），React 端 onChange 结果经业务层返回的
   `commitDate(field, 'YYYY-MM-DD')` 汇入 localStorage + dirty 链路；业务层由
   `return function cleanup(){…}` 改为 `return { commitDate, cleanup, … }` 暴露 API。
8. **⚠️ 别静态 `import { createPortal } from "react-dom"`**：平台模块加载器对没注册过的
   裸模块会**静默返回 undefined**，编译后 `_reactDom.createPortal` 直接抛
   `Cannot read properties of undefined (reading 'createPortal')` 整组件崩掉。正确做法：
   运行时解析 `resolvePortalFn(win, props)`——依次试 `props.ctx.ReactDOM` / `props.ReactDOM`
   / `window.ReactDOM` / `window.__REACT_DOM__` 的 `.createPortal`；全都没有则把布局里
   的空容器替换成原生 `<input type="date">`（`nativeLayout()` 字符串替换 + `.date-native`
   样式 + 业务层在 `opts.portal=false` 时改绑 change 事件、render 写 `input.value`），
   保证页面与日期功能永不因缺 react-dom 而不可用。选型日志打一行
   `portal: window.ReactDOM / props注入 / 无（原生兜底）` 供排障。

参考实现：`项目进度总览-组件版.jsx`（React 壳 + innerHTML 注入 + localStorage 真相源 + 脏字段保护，含可见诊断横幅与 401/404/非 JSON 报错展示）。

**样式"全灭"的坑（顺着上面的模板写必踩）：**
注入的页面里所有 CSS 选择器都带 `.xmj-shell` 前缀，但注入 HTML 的根节点
**没有挂这个 class**（纯 HTML 版根节点是 `<div class="xmj-shell">`，搬进组件版
LAYOUT 时容易丢掉这层壳）→ 选择器全部匹配不上 → 数据正常渲染但完全裸排版。
两种修法（都做最稳）：
1. React 壳直接 `return <div ref={boxRef} className="xmj-shell" />;`
   （且 `useEffect` 里再 `box.className = "xmj-shell"` 双保险）；
2. 样式改用 `document.createElement("style")` 注入 `<head>` 而非拼进 innerHTML，
   防止部分宿主把 innerHTML 里的 `<style>` 标签剥掉。

## 子表字段从主表带值（新增 / 导入 / 同步 三件套）

场景：子表从「选其他表单」改成「手动添加 + 导入」后，字段全空（`defaultValue` 空、`events` 空）。
先查三处，否则会误判成"事件没生效"：`subtable.props.canAdd`、`subtable.props.actions[].visible`、
`subtable.props.formId/functionId/bindCode`（后三者空串 = 绑定已解掉）。

| 入口 | 做法 | 关键点 |
|---|---|---|
| 手动新增 | **自定义动作按钮接管** `ctx.getArrayFormApi(SUB).append({字段id: 值})`，`canAdd` 保持 `false` | 想"条件不满足就不新增"必须自己接管动作 —— 平台级只有 `BEFORE_SUBMIT`/`BEFORE_UPLOAD` 能阻断；在 `ADD_ROWS` 里 `return false` 无效 |
| 导入 Excel | 导入走 `ctx.outInfo.reload()`，**不经过 `append`**，所以不触发新增逻辑 → 在 `.then` 里 `reload()` 之后**轮询自动补值** | 一轮一轮只补空字段，天然幂等；**不要做"手动同步"按钮**（用户明确否决：没人会去点，很怪） |

三条硬经验：

1. **子表动作按钮的代码在 `actions[i].event`**，不是 `props.events[]`（排查"代码不执行"的钥匙）。
2. **流水号取"已有值里的最大号 +1"，不要用行号 `i+1`** —— 表里已有数据时会撞号。
3. 子表行的 `foreign_id`（外键）由平台自动写主表 id，**不用在脚本里赋**（真实数据已验证）。
4. **轮询停止条件不能只看"没东西可补"** —— 踩过的坑：导入前的老行本来就有值，只判断"补不动了"
   会在 1.5 秒后误停、此时 `reload()` 的新行还没到 → 等于没补。正确条件：
   **「行数相对导入前发生变化」+「连续 2 次无需再补」**，再加一个总超时（如 30 秒）兜底。

```js
// 导入后自动补值（放在 import 的 .then 里，reload() 之后）
const before = (ctx.getArrayValue(SUB) || []).length;   // 点击那一刻的行数
let tries = 0, arrived = false, quiet = 0;
const timer = setInterval(() => {
  tries++;
  const r = ctx.utils.dfBackfill(false);               // 只补空字段
  if (r.rows !== before) arrived = true;               // 新行刷出来了
  if (arrived && r.filled === 0 && r.coded === 0) quiet++; else quiet = 0;
  if (quiet >= 2 || tries >= 60) clearInterval(timer); // 30 秒兜底
}, 500);
```

```js
// 新增行：带值 + 生成子表编码
module.exports = function (request, ctx, params) {
  if (!ctx.getValue("input_<主表合同id>")) { ctx.message("请先选择合同", "error"); return false; }
  const rows = ctx.getArrayValue(SUB) || [];
  const prefix = ctx.getValue("input_<主表编号id>") || "";
  const row = {};
  row["input_<子表字段id>"] = ctx.getValue("input_<主表字段id>");
  if (prefix) row["input_<子表编码id>"] = prefix + "-" + pad(maxSerial(rows, "input_<子表编码id>", prefix) + 1, 5);
  ctx.getArrayFormApi(SUB).append(row);   // 追加行只用 append，不要 setArrayValue
};
```

## 编号规则速查（表单编号从哪来）

表单编号由**数据库里的规则**生成，不在前端代码里。要判断"编号依赖哪些字段"，直接查库：

| 表 | 用途 |
|---|---|
| `plant.dy_number_table` | 表名 → 规则：`{number_rule_id, table_name}` |
| `plant.dy_number_rule` | 规则头：`{rule_number, name, table_field, autofill}`（`autofill=true` = 保存时服务端自动填） |
| `plant.dy_number_rule_definition` | 规则组成，按 `sort` 拼接。`type`：`1`=流水号(`placeholder_num` 位数)、`2`=常量(`constant_value`)、`4`=日期字段、`5`=值表字段(`value_table_field`，取那一列的值) |

```sql
select d.type, d.value_table_field, d.placeholder_num, d.constant_value, d.sort
from plant.dy_number_rule_definition d
where d.number_rule_id = (select number_rule_id from plant.dy_number_table where table_name = 'xxx')
order by d.sort;
```

**两个必须提前告知用户的点**：

1. `type:5` 的字段为空时，编号会**缺段**；且编号一旦落库，再改这些字段**不会重编号** → 生成时机应放在这些字段填完之后。
2. `/dynamic/number/rule/generate` 这类接口**可能不在前端产物里**（扫 `web/umi.*.js`、`cdnbase/bstBase.min.js`、
   `cdnworkbook/bstWorkBook.min.js` 可确认）。要验证契约别猜，让用户抓一次真实请求，或直接把三个包下下来 grep。
   （注意：这些包可以直接 `curl http://<host>:<port>/web/<文件名>` 下载，无需登录。）

## 脚本规范：编辑器 lint 两条规则 + 代码块/工具函数机制

> 来源：8700 前端产物 `web/umi.526025e0.js` 里编辑器 lint 的**源码原文**（不是文档推测）。
> 写事件脚本前先按这两条自查，能省掉一轮返工。

**规则 1（warning）—— 嵌套 Function**
统计 `FunctionDeclaration` / `FunctionExpression`，**第 2 层起**报
「不建议嵌套Function,建议使用代码块功能,使代码结构更清晰」。
`module.exports = function (params, ctx, block) {...}` 是最外层（深度 1），所以主代码里
再写 `function pad(){}` 或 `rows.forEach(function(){})` 就会报；**箭头函数（ArrowFunction）不在统计内**。
最稳的写法：主代码里一个内联函数都不写，循环用 `for`，回调用箭头。

**规则 2（error）—— 子表方法参数必须是控件 id**
`ctx.getArrayValue / setArrayValue / getArrayFormApi / getArrayInstance / setArrayInstance /
validateArray` 的**第一个字符串字面量参数**必须在白名单内
（白名单 = `flatInstances.map(i => [i.id, i.props.dataBind]).flat()`）。
传变量就绕过这条校验，但传错值照样运行失败 —— 所以把配对表集中到"工具函数"里一处维护。

**三种抽公共逻辑的位置（运行时已核实）**

| 机制 | 存在哪里 | 怎么调 | 谁可用 |
|---|---|---|---|
| 表单级**工具函数** | `props.utilsJs[]`，条目 `{title, desc, code, type:"function"}` | `ctx.utils.块名(...)` | **任何脚本**，含子表动作按钮 |
| 事件级**代码块** | `events[].codeItem.utils[]`，同一结构（主代码的 `title` 固定 `"main"`） | `block.块名(...)` | 只有事件（codeItem） |
| 子表动作按钮 | `actions[].event` | — | **拿不到 `block`** |

- 两者运行时都是 `模块导出函数.apply(undefined, [ctx, ...调用参数])` —— **平台自动把 ctx 注入第一个形参**，
  所以块内第一个形参固定写 `ctx`，调用时不用传。块可以写成 `async function (ctx)` 用 await。
- **子表动作按钮无 block 的铁证**（onClick）：
  `onClick: function(){ var f = getCodeDefaultExports(a.event); f(subTable, ctx, a) }` —— 只传 3 个参数。
  但它拿到的 ctx 自带 `.utils`，所以动作按钮里 `ctx.utils.xxx()` 可用。
- 分工原则：**共用纯逻辑 → 表单级 `ctx.utils`；只此一处用的逻辑 → 事件级 `block`。**

```js
// 表单级工具函数（props.utilsJs 里一条，标题 dfPad）
module.exports = function (ctx, n, len) {          // ctx 由平台注入
  let s = "" + n;
  while (s.length < len) s = "0" + s;
  return s;
};

// 事件主代码里调用
ctx.utils.dfPad(2, 5);

// 事件 main 调自己的代码块
block.genStorageNumber();
```

## 参考

- `references/api.md` — 完整 API 与数据结构
- `references/tree-filter.md` — **目录树截断的诊断与正确写法**（含真实事故复盘）
- `references/form-design-put-guide.md` — **表单设计 PUT 更新完整指南**（payload 结构/替换数据源/加预暖/换 children/通用脚本用法）
- `scripts/` — 可直接跑的注入/诊断/校验脚本
- `assets/datasource_dir_tree.js` — 目录树数据源模板（目录级过滤 + 缓存）
