// ===== 目录树型数据源模板（目录级过滤 + globalThis 缓存）=====
//
// 使用前提：先用 scripts/diagnose_tree.py 确认过滤锚点。
// 核心原则：分类标识取「目录主表」那一行，不要按节点表逐行过滤
//          （节点级同名字段常常大面积为 NULL，会把树拦腰截断）。
//
// 注入前，scripts/inject.py 会按分类替换下面这一行（变量名由 --var 指定）：
const SPECIALTIES = ["<枚举1>", "<枚举2>"];

const __CACHE__ = (globalThis.__df_tree_cache__ = globalThis.__df_tree_cache__ || {});

module.exports = async function (ctx, payload) {
  const companyId = JSON.parse(localStorage.getItem("userInfo") || "{}").companyId;

  // 缓存 key 必须带上全部分类维度，否则多分类会串数据
  const cacheKey = companyId + "::" + SPECIALTIES.join(",");

  // ① 读缓存：命中直接返回（控件挂载/重挂载不再打接口）
  if (__CACHE__[cacheKey]) return __CACHE__[cacheKey];

  const companyQuery =
    companyId !== "<免过滤的公司Id，留空即都过滤>"
      ? { resp_company_id: companyId }
      : {};
  const queryMap = { sys_deleteflag: false, ...companyQuery };

  // ② 目录主表：一行 = 一个分类的完整目录，这才是权威的分类锚点
  const mainRes = await ctx.http.request("POST", "/dynamic/function/api/table")({
    tbName: "<目录主表名>",
    fields: ["id", "<状态字段>", "<分类字段>"],
    queryMap: { sys_deleteflag: false },
  });

  const mainIds = (mainRes || [])
    .filter(
      (m) =>
        m["<状态字段>"] === "<已发布值>" &&
        SPECIALTIES.indexOf(m["<分类字段>"]) !== -1,
    )
    .map((m) => m.id);

  if (!mainIds.length) return [];

  // ③ 节点表：按外键整棵纳入，不再逐行过滤分类
  const res = await ctx.http.request("POST", "/dynamic/function/api/table")({
    tbName: "<节点表名>",
    fields: [
      "id", "<名称字段>", "<父级字段>", "<排序字段>",
      "resp_company_id", "<指向主表的外键>", "<分类字段>",
    ],
    orderBy: { "<排序字段>": true },
    queryMap,
  });

  const rows = (res || []).filter(
    (item) => mainIds.indexOf(item["<指向主表的外键>"]) !== -1,
  );

  rows.sort((a, b) => a["<排序字段>"] - b["<排序字段>"]);

  // ④ 建树
  const map = {};
  rows.forEach((item) => {
    if (item.id && item["<父级字段>"]) {
      map[item.id] = {
        ...item,
        children: [],
        parentId:
          item["<父级字段>"] == 0 || item["<父级字段>"] === "0"
            ? null
            : item["<父级字段>"],
        label: (item["<排序字段>"] ? item["<排序字段>"] + " " : "") + item["<名称字段>"],
        value: item.id,
        disabled: false,
      };
    }
  });

  rows.forEach((item) => {
    if (item.id && item["<父级字段>"] && map[item.id] && map[item["<父级字段>"]]) {
      const parentId = map[item.id].parentId;
      if (parentId !== null) {
        if (!map[parentId].children) map[parentId].children = [];
        map[parentId].children.push(map[item.id]);
      }
    }
  });

  const result = Object.values(map).filter((node) => node.parentId === null);

  // ⑤ 写缓存
  __CACHE__[cacheKey] = result;
  return result;
};
