---
name: prp-function-publish
description: |
  bestdt「表单发布页」功能批量发布 + 批量重挂到菜单（API 版，替代浏览器自动化）。
  发布：翻页拉未发布功能 → GET 详情整份回显 → 改 3 项（pushStatus / parentMenuId /
  dyFunctionButtonAddDtoList 5 核心权限）→ PUT。
  重挂：菜单重分类后批量改 dy_function.parent_menu_id（列表接口过滤不到，必须逐条详情）。
  关键实测：currentPage+size(上限20) 翻页、total 不可信、formButtonId 按表单各自生成（错用报 900）、
  TREE_SHOW 的 treeFunctionId 悬空需人工、TREE_MAINTENANCE 的 menuColumnDtoList 必须去掉（否则 900 入参错误）、
  permissionId 为全球常量、sys_menu 的 code 列实际必填。
  关键词：功能发布、批量发布、重挂、菜单分类、pushStatus、parentMenuId、formButtonId、permissionId、
  menuColumnDtoList、LIST_FORM、TREE_SHOW、TREE_MAINTENANCE、treeFunctionId、dynamic/function、菜单树。
user-invocable: true
---

# PRP 功能发布（API 批量发布，★ 推荐）

> 把「表单发布页」里**未发布**的功能批量发布到菜单：勾齐 5 个核心权限（新增/编辑/保存/查看/删除）+ 选对**上级菜单**。
> **替代浏览器自动化（bsk / chrome-devtools MCP）发布**——后者在 antd 受控复选框勾选、守护进程保活上极不稳定，已废弃（见结尾）。
> 首次落地：智慧工地 PRP（172.19.18.223:1112），50 条未发布一次发布 31 条 LIST_FORM，剩下 8 条 TREE_SHOW 因 `treeFunctionId` 悬空需人工。

---

## 一、鉴权与环境

- 鉴权头：`Authorization: Bearer <access_token>`，token 取 `localStorage.access_token`，**会过期**，返回 401/403 即要换新。
- **环境地址 + 账号不落库**（每次单独提供）；页面路由见  技能。
- 实测用 Python 标准库 `urllib` 直连 HTTP 即可，不依赖浏览器。

---

## 二、★ 三个关键接口（实测）

| 用途 | 接口 | 要点 |
| :--- | :--- | :--- |
| 功能列表（分页） | `GET /apis/dynamic/function/page?currentPage=N&size=20` | ⚠ `currentPage`（不是 `current`/`page`）；`size` 上限 20（超了也只回 20）；`total` 字段**不可信**，必须翻页 + 按 id 去重 |
| 功能详情 | `GET /apis/dynamic/function/{id}` | 返回**完整对象**（菜单/按钮/列/自定义 JS 全在），发布时整份回显避免丢字段 |
| **发布（写）** | **`PUT /apis/dynamic/function`** | body = 详情全量 + 改下面 3 项；把只读字段 `dyFunctionButtonVoList` 剔除 |
| 菜单树 | `GET /apis/menu/getMenuTree` | 解析祖先链，定位"上级菜单"节点 id |
| 表单按钮清单 | `GET /apis/dynamic/form/button/{formId}` | 拿到**该表单自己**的 `formButtonId`（11 个权限复选框的来源） |

> `PUT` 是**集合路径** `/apis/dynamic/function`（不是 `/function/{id}`，不是 `/function/attribute`）。

---

## 三、发布要改的 3 项

1. **`pushStatus = true`** —— 发布开关。
2. **`parentMenuId` = 上级菜单节点 id** —— 例：「高处作业票」的 `parentId` = 「相关功能」`c910c5edfa8b88e7df283aa5b5f1150b`，那就是正确的上级菜单。
3. **`dyFunctionButtonAddDtoList`** = 5 个核心权限，每项 `{ formButtonId, permissionId, permissionCode }`：
   - `permissionCode`：`add / edit / save / view / delete`
   - `permissionId`：**全球常量**（与表单无关）
     `add=8dd9b7bc741513c94d01800563206872`、`edit=dd500b47c8296368f1f70ef684836c14`、`save=335fc5a71509944cf6d298842bf93c90`、`view=d7e163ad677f3c8ab1ab42298f8257bc`、`delete=b16ab9588e571e5ac35d92990c30c6e3`
   - `formButtonId`：**每个表单不同** → 必须 `GET /apis/dynamic/form/button/{formId}` 取本表单的（见 §四）

---

## 四、★ 权限按钮是"按表单"的（最易踩坑）

- 同一操作（如「新增」）的 `permissionId` 全局一样，但 `formButtonId` **每个表单各自生成**。
- 错用别的表单的 `formButtonId` 提交 → 返回 **900「表单按钮不匹配」**，且整条写入回滚（`pushStatus` 也改不了）。
- 正确做法：对每条功能，先 `GET /apis/dynamic/form/button/{formId}` 取该表单的 11 个按钮，按 `permissionCode` 挑出 5 个核心的 `id` 当 `formButtonId`。
- 某表单若缺某个核心权限（如「选目录」类表单没有增删改），只挂它有的，缺的不强塞。

---

## 五、★ 上级菜单怎么定位

- `GET /apis/menu/getMenuTree` → 递归找目标功能节点 → 取其 `parentId`。
- 例：菜单树里「高处作业票」`menuType=func`，`parentId=相关功能(c910c5ed…)`；「相关功能」又挂在「智慧工地」下。所以"高处作业票的上级菜单" = 「相关功能」。
- **已发布的同级功能**详情里的 `parentMenuId` 也可直接参考（如隐患排查治理的 `parentMenuId=c910c5ed…`，与菜单树一致，双重佐证）。

---

## 六、★ 树形功能发布坑（实测，必看）

### 6.1 TREE_SHOW：treeFunctionId 悬空

- `type=TREE_SHOW` 的功能，`treeFunctionId` 必须指向一个**真实存在**的功能。
- 若该 id 悬空（`GET /apis/dynamic/function/{treeFunctionId}` 返 900「功能信息不存在」）→ `PUT` 必报 **900「树形功能不存在」**，**即使保留原 parentMenuId、只置发布状态也照样失败**。
- 这类无法靠 API 直接发布：需人工在平台把 `treeFunctionId` 指向有效树功能，或新建对应树功能后再发。
- 排查脚本：`GET` 一下 `treeFunctionId` 这个 id 是否存在即可判定。

### 6.2 TREE_MAINTENANCE：menuColumnDtoList 必须去掉（2026-10-23 实测）

- `type=TREE_MAINTENANCE`（树维护表单）PUT 时报 **900「入参错误」**，原样回传详情也报。
- **元凶 = 详情里的 `menuColumnDtoList` 字段**；`det.pop("menuColumnDtoList", None)` 后 PUT 即成功。
- 已固化进 `scripts/reparent_functions.py`（每次 PUT 前统一 pop，LIST_FORM 不受影响）。
- 现成案例：68 个功能重挂时 67 条直接成功，仅「安全会议类型设置」（TREE_MAINTENANCE）报错，去字段后成功。

---

## 七、★ 重挂：菜单重分类后批量搬家（2026-10-23 新增）

**场景**：`sys_menu` 菜单重分类（parent_id 改了）后，`dy_function.parent_menu_id` 还指着旧目录 → 发布页的树不跟随。只改菜单表没用，**必须批量改 `dy_function.parent_menu_id`**。

**流程**（幂等，可重跑）：

1. 拿映射：菜单重分类 SQL 里每条 `UPDATE sys_menu SET parent_id='<目录>' ... WHERE id='<菜单>'` 就是现成的「菜单id → 目录id」映射（**逐行 `re.search` 解析**；全文 `findall` 会被 `\r\n` 行尾坑到只命中部分行；菜单 id 有 31 位也有 32 位，正则别写死 `{32}`）。
2. 翻页拉功能 id（`page?currentPage=N&size=20`，按 id 去重）。
3. **逐条 GET 详情过滤**——⚠ 列表接口返回的 `menuId`/`parentMenuId` **恒为 null**，列表层按目录筛不了，只能逐条看详情。
4. `parentMenuId == 旧目录` 的：整份回显 + 改 `parentMenuId` + 重建按钮 + **pop 掉 `dyFunctionButtonVoList` 和 `menuColumnDtoList`** → PUT。
5. 查库验证：`SELECT m.name, COUNT(*) FROM dy_function f JOIN sys_menu m ON m.id=f.parent_menu_id WHERE f.del=0 GROUP BY m.name`；旧目录残留应为 0。

**现成脚本**：`scripts/reparent_functions.py`（映射支持 sql/json 两种文件，--dry-run 先演练，日志落盘，token 失效自动停）。实战战绩：68/68 全部重挂成功（人6/机1/料13/法13/安12/进20/质3）。

---

## 八、sys_menu 直改相关坑（配合菜单重分类）

| 坑 | 对策 |
| :--- | :--- |
| INSERT 菜单报「code不能为null」 | `sys_menu.code` 实际必填（达梦约束里查不出来，但全表都有值）；照拼音给，如 人=ren/机=ji/料=liao/法=fa/安=an/进=jin/质=zhi，插前查重 |
| dbx 连接只读 | 改数据一律走平台 API，别硬写库 |
| `sys_menu.form_address` 与表单发布无关 | 全库只有系统菜单有值，别被它误导 |

---

## 九、通用套路（可重跑、幂等）

1. **翻页拉全未发布**：`currentPage` 1..N，`size=20`，收集后按 `id` 去重。
2. **逐条**：`GET` 详情 → 只动 `pushStatus=false` 的（已发布跳过，天然幂等）→ 取本表单按钮 → 改 3 项 → `PUT`。
3. **token 失效**（401/403）立即停并报，别硬刷。
4. **逐条记成败**，报告具体到「哪条失败 + 原因」（900 树形功能不存在 / 表单按钮不匹配 …）。
5. **改前整份回显**：只覆盖要改的字段，其余原样传回，避免丢菜单列/自定义 JS。

---

## 十、坑汇总

| 现象 | 根因 / 对策 |
| :--- | :--- |
| 翻页每次返回同一页 | 用了 `current`；改用 `currentPage` |
| 一页超 20 条被截断 | `size` 上限 20，翻页拿全 |
| `total` 字段显示 50 但只枚举到 39 | `total` 不可信，以实际去重条数为准 |
| 900「表单按钮不匹配」 | `formButtonId` 用了别的表单的；用本表单 `GET /form/button/{formId}` 取 |
| 900「树形功能不存在」 | `treeFunctionId` 悬空；TREE_SHOW 需人工修（§6.1） |
| 900「入参错误」（TREE_MAINTENANCE） | 详情里的 `menuColumnDtoList` 导致；pop 掉再 PUT（§6.2） |
| 按目录筛功能筛不出来 | 列表接口 `menuId`/`parentMenuId` 恒为 null；逐条 GET 详情判断（§七） |
| PUT 后 `pushStatus` 没变 | 校验失败整条回滚；先看返回 `msg` |
| 写接口把别的字段搞没了 | 别自己造 body，详情整份回显只改要改的字段 |
| ⚠ 只改 `sys_menu.parent_id` 重分类菜单 | 发布页的树**不会**跟着变；必须同步改 `dy_function.parent_menu_id`（§七） |
| 菜单 id 位数不一致 | 有 31 位也有 32 位，正则别写死 `{32}` |
| 解析返回文本踩 `\r\n` | 逐行 `re.search`，别用全文 `findall`（只命中部分行） |
| INSERT 菜单报「code不能为null」 | `sys_menu.code` 实际必填（§八） |

---

## 十一、交付脚本

- **`scripts/reparent_functions.py`（本技能自带）** —— 批量重挂 parentMenuId（§七完整流程固化版：sql/json 映射、--dry-run、日志落盘、token 失效自动停、自动 pop TREE_MAINTENANCE 的 menuColumnDtoList）。
- 工作区历史脚本（`batch_publish_api.py` 批量发布、`test_publish_one.py` 单条试点、`probe*.py` 侦察）——下次批量发布时也收编进本技能。

---

## 十二、关联

- 同系列批量写见知识库《批量配置与自动化》（表单事件注入、资源接口上下线）
- 表单原理与写代码：知识库《自定义表单开发实战》《PRP 功能发布 API》
- ★ **已废弃**：浏览器自动化发布（bsk / chrome-devtools MCP）—— antd 受控组件勾选靠真实鼠标事件才稳，守护进程保活困难，批量发布不可靠；一律改本 API 方法。相关技能 web-form-regression / form-browser-capture 已删除。
