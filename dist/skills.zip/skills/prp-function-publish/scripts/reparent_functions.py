# -*- coding: utf-8 -*-
"""批量重挂已发布功能到新菜单目录（parentMenuId 批量改挂）。

场景：菜单重分类后，dy_function.parent_menu_id 还指着旧目录，发布页树不跟随。
做法：翻页拉功能 id -> 逐条 GET 详情 -> parentMenuId==旧目录 的按映射改新目录 -> PUT。

用法:
  python reparent_functions.py --base http://ip:port --token <access_token> \
      --old-parent <旧目录菜单id> --map-file <映射文件> [--map-type sql|json] [--dry-run]

映射文件二选一:
  sql  : 菜单重分类 SQL 文本（每行 UPDATE ... SET parent_id='<目录id>' ... WHERE id='<菜单id>'）
  json : {"<菜单id>": "<目录id>", ...}

关键实测坑（必读）:
  1) 列表接口 /apis/dynamic/function/page 的 menuId/parentMenuId 恒为 null，
     按目录过滤必须逐条 GET /apis/dynamic/function/{id} 详情判断。
  2) TREE_MAINTENANCE 类型 PUT 报 900「入参错误」= 详情里的 menuColumnDtoList 导致，
     去掉该字段再 PUT 即成功。
  3) token 失效(401/403) 立即停，换新 token 重跑（幂等，已改过的自动跳过）。
  4) 改完查库核对: SELECT parent_menu_id, COUNT(*) FROM dy_function WHERE del=0 GROUP BY parent_menu_id。
"""
import argparse, json, re, time, datetime, os
import urllib.request, urllib.error


def log(path, s):
    with open(path, "a", encoding="utf-8") as f:
        f.write("[%s] %s\n" % (datetime.datetime.now().strftime("%H:%M:%S"), s))


class Api:
    def __init__(self, base, token):
        self.base = base.rstrip("/")
        self.head = {"Authorization": "Bearer " + token, "Accept": "application/json"}
        self.headj = dict(self.head, **{"Content-Type": "application/json"})

    def get(self, path):
        r = urllib.request.Request(self.base + path, headers=self.head)
        with urllib.request.urlopen(r, timeout=40) as resp:
            return json.loads(resp.read(400000).decode("utf-8", "replace"))

    def put(self, path, data):
        r = urllib.request.Request(self.base + path, data=json.dumps(data).encode(),
                                   headers=self.headj, method="PUT")
        try:
            with urllib.request.urlopen(r, timeout=40) as resp:
                return resp.status, json.loads(resp.read(8000).decode("utf-8", "replace"))
        except urllib.error.HTTPError as e:
            try:
                return e.code, json.loads(e.read(8000).decode("utf-8", "replace"))
            except Exception:
                return e.code, {"code": e.code, "msg": "HTTPError"}

    def build_buttons(self, form_id, core=("add", "edit", "save", "view", "delete")):
        btns = self.get(f"/apis/dynamic/form/button/{form_id}").get("data") or []
        m = {b["permissionCode"]: b for b in btns}
        out = [{"formButtonId": m[c]["id"] or m[c].get("formButtonId"),
                "permissionId": m[c]["permissionId"], "permissionCode": c}
               for c in core if c in m]
        return out, [x["permissionCode"] for x in out]


def load_map(path, mtype):
    txt = open(path, encoding="utf-8").read()
    if mtype == "json":
        return json.loads(txt)
    # sql 模式：逐行解析（别全文 findall，\r\n 行尾会漏行；id 有 31 位也有 32 位）
    mp = {}
    for line in txt.splitlines():
        m = re.search(r"SET parent_id='([0-9a-f]{24,40})'.*?WHERE id='([0-9a-f]{24,40})'", line)
        if m:
            mp[m.group(2)] = m.group(1)
    return mp


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    ap.add_argument("--token", required=True)
    ap.add_argument("--old-parent", required=True, help="旧目录菜单 id")
    ap.add_argument("--map-file", required=True)
    ap.add_argument("--map-type", choices=["sql", "json"], default="sql")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--log", default="reparent.log")
    a = ap.parse_args()

    open(a.log, "w", encoding="utf-8").close()
    menu_map = load_map(a.map_file, a.map_type)
    log(a.log, "映射条数: %d" % len(menu_map))
    if not menu_map:
        log(a.log, "!! 映射为空，停止")
        return

    api = Api(a.base, a.token)
    ids, seen = [], set()
    for cp in range(1, 40):
        d = api.get(f"/apis/dynamic/function/page?currentPage={cp}&size=20")
        recs = d.get("data", {}).get("records", [])
        if not recs:
            break
        for r in recs:
            if r["id"] not in seen:
                seen.add(r["id"]); ids.append(r["id"])
        if cp * 20 >= (d.get("data", {}).get("total") or 0):
            break
    log(a.log, "全部功能数: %d" % len(ids))

    ok = skip = 0
    fail = []
    for fid in ids:
        try:
            det = api.get(f"/apis/dynamic/function/{fid}")["data"]
        except Exception as e:
            fail.append((fid, "GET", str(e)[:80])); continue
        if det.get("parentMenuId") != a.old_parent:
            skip += 1; continue
        name, mid = det.get("name"), det.get("menuId")
        new_parent = menu_map.get(mid)
        if not new_parent:
            fail.append((name, "NO_MAP", "menuId=%s" % mid)); continue
        if a.dry_run:
            log(a.log, "[dry] %s -> %s" % (name, new_parent)); ok += 1; continue
        try:
            btns, codes = api.build_buttons(det["formId"])
            det["pushStatus"] = True
            det["parentMenuId"] = new_parent
            det["dyFunctionButtonAddDtoList"] = btns
            det.pop("dyFunctionButtonVoList", None)
            det.pop("menuColumnDtoList", None)  # TREE_MAINTENANCE 必须去掉，否则 900 入参错误
            code, resp = api.put("/apis/dynamic/function", det)
            if code in (401, 403):
                log(a.log, "token 失效(%s)，停止" % code); fail.append((name, code, "TOKEN")); break
            if code == 200 and resp.get("code") == 200:
                ok += 1; log(a.log, "OK %s -> %s 按钮=%s" % (name, new_parent[-6:], codes))
            else:
                fail.append((name, code, str(resp.get("msg"))[:100]))
                log(a.log, "FAIL %s code=%s msg=%s" % (name, code, resp.get("msg")))
            time.sleep(0.2)
        except Exception as e:
            fail.append((name, "EXC", str(e)[:100]))
    log(a.log, "=" * 40)
    log(a.log, "完成: 成功 %d / 跳过 %d / 失败 %d" % (ok, skip, len(fail)))
    for n, c, m in fail:
        log(a.log, "   - %s | %s | %s" % (n, c, m))


if __name__ == "__main__":
    main()
