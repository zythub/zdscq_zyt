---
name: form-browser-capture
description: 用 BrowserSkill（bsk）连接自定义表单设计/发布页面，抓取表单定义、事件代码、按钮 clickEvent，并整理到 Obsidian 知识库。适用于低代码平台自定义表单的数据沉淀与知识库更新。
version: 1.0.0
agent_created: true
---

# 表单浏览器抓取与知识库整理

## 用途

当用户需要从自定义表单设计页面（如 `http://172.19.18.223:1103/web/#/custom/form-definition/design`）抓取真实表单数据（字段、事件代码、按钮事件、发布关系），并整理到 Obsidian 知识库时使用。

## 触发条件

- 用户要求「连浏览器抓表单数据」
- 用户要求「把表单代码整理到知识库」
- 用户要求「更新某个专题的真实代码」
- 用户给出表单设计/发布 URL 和 token

## 前置条件

1. `bsk` CLI 已安装且在 PATH 上。
2. BrowserSkill 扩展已加载并连接（`bsk status` / `bsk browsers` 显示绿色）。
3. 用户已提供或环境已配置 Bearer token。
4. 目标 URL 在用户浏览器可达的内网/VPN 环境下。

## 标准步骤

### 1. 启动浏览器会话并导航

```bash
bsk session start --no-focus
# 记下 4 位 session id

bsk navigate "http://172.19.18.223:1103/web/#/custom/form-definition/design" --session xxxx --wait-until domcontentloaded
```

### 2. 找到目标表单

- 用右侧「名称」搜索框搜索关键词（如「出库」），点「查询」按钮。
- 或展开左侧分类树定位分类（如「物资管理」）。
- 通过 `bsk snapshot --session xxxx` 定位行内「编辑」按钮。

### 3. 进入表单设计器

```bash
bsk click @eXXX --session xxxx    # 编辑按钮
bsk click @eYYY --session xxxx    # 表单设计/设计器按钮
```

### 4. 获取 formId

方式 A：查看 network 请求。

```bash
bsk network --session xxxx --limit 50
```

找到形如 `GET /apis/dynamic/form/{formId}` 的请求。

方式 B：用 JS fetch 查列表页。

```bash
bsk evaluate "fetch('/apis/dynamic/form/page?currentPage=1&pageSize=20&search=%E5%87%BA%E5%BA%93',{headers:{'Authorization':'Bearer <token>'}}).then(r=>r.json()).then(d=>JSON.stringify(d.data.records.map(x=>({id:x.id,name:x.name}))))" --session xxxx
```

### 5. 拉取表单定义并保存到本地

```bash
bsk evaluate "fetch('/apis/dynamic/form/{formId}',{headers:{'Authorization':'Bearer <token>'}}).then(r=>r.json()).then(d=>{localStorage.setItem('__form',JSON.stringify(d.data)); return d.data.id;})" --session xxxx

bsk evaluate "(()=>{const data=localStorage.getItem('__form');const blob=new Blob([data],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='form.json';document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(url);a.remove();},2000);return 'downloaded';})()" --session xxxx
```

文件默认下载到 `~/Downloads`。移动到 vault 临时目录再分析。

### 6. 分析表单定义

用 Python 读取 JSON，提取：
- `formAttributeJson` 字符串 → 反序列化
- 顶层字段与控件 id
- `props.events` 里的 created / beforeSubmit / change 等事件代码
- `props.btns` 里的按钮列表
- 子表（`subtable` / `ArrayForm`）结构与字段

### 7. 获取按钮 clickEvent

```bash
bsk evaluate "fetch('/apis/dynamic/form/button/{formId}',{headers:{'Authorization':'Bearer <token>'}}).then(r=>r.json()).then(d=>{localStorage.setItem('__btns',JSON.stringify(d.data)); return JSON.stringify(d.data.map(b=>({name:b.name,code:b.permissionCode,clickEventLen:(b.clickEvent||'').length})));})" --session xxxx
```

按钮 clickEvent 常是 URL 编码，读取时用 `urllib.parse.unquote`。

### 8. 获取表单发布关系

导航到表单发布页：

```bash
bsk navigate "http://172.19.18.223:1103/web/#/custom/form-definition/publish" --session xxxx --wait-until domcontentloaded
```

搜索表单名，查看发布后对应的菜单 code（如 `MA_StorageOut`、`MA_SpecialTools`）。

### 9. 整理到 Obsidian

- 将真实字段、事件代码、按钮事件写入对应专题文件（如 `01-自定义开发/自定义表单开发实战.md`）。
- 保留「来源：BrowserSkill 抓取」标注，不编造数据。
- 不确定字段/接口标为「待查」，并写明如何继续查（数据库 / 浏览器）。

### 10. 清理临时文件

删除 vault 根目录的 `.tmp_*.json`、`.tmp_*.js`、`.tmp_*.png` 等中间文件，保持目录干净。

```bash
rm .tmp_*
```

### 11. 停止会话

```bash
bsk session stop xxxx
```

## 关键 API

| 接口 | 用途 |
| :--- | :--- |
| `GET /apis/dynamic/form/{formId}` | 获取表单定义（含 `formAttributeJson`） |
| `GET /apis/dynamic/form/button/{formId}` | 获取按钮列表（含 `clickEvent`） |
| `GET /apis/dynamic/form/page?search=xxx` | 搜索表单列表 |
| `GET /apis/dynamic/form/relation/{formId}` | 获取表单关联关系 |

## 注意事项

- `formAttributeJson` 是字符串，需 `JSON.parse`。
- 保存表单用 `PUT /apis/dynamic/form`（集合路径），不是 `/form/{id}`。
- 按钮 clickEvent 可能是 URL 编码：读时 `decodeURIComponent`，保存时 `encodeURIComponent`。
- 一个表单可发布成多个菜单 code，通过 URL `customform/{code}` 区分。
- 控件 id 在不同环境可能不同，优先用 `dataField` 字段名 + `getControlIdByField` 动态解析。

## 失败处理

- 页面加载超时 → 检查 VPN/内网、浏览器响应；先 `bsk snapshot` 看当前状态。
- 401 → Token 过期或 Authorization 头格式错误。
- 405 → 路径错误，应为 `/apis/dynamic/form`。
- 搜索无结果 → 尝试不同关键词或左侧分类树。
- 弹窗关不掉 → 用 JS 强制隐藏 mask/modal，或 `bsk press Escape`。
