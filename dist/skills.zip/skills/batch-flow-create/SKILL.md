---
name: batch-flow-create
description: |
  bestdt 平台批量给表单配流程（API 版，海门 1103 环境实测跑通 7 张表）。
  全链路：detect_forms.py 探测表单 → pick_nodes.py 从表单设计自动提取审批节点（date配对+范围词典，多余的删 nodes.json）→ build_flows.py 按节点数动态生成流程（节点/审批人绑表单字段/节点表单权限/
  日期回填变量/线状态/编号规则）→ 导入 → 发布 → 列表列配置 → 自动发起测试（含真实模拟：
  按必填控件生成合法值）→ 流程改名/改编号（导出副本法）→ 清理历史部署。
  关键实测：拖控件+保存设计器才写 dy_form_field（PUT /dynamic/form 静默忽略 vos，假成功；
  正确姿势 PUT /dynamic/form/attribute + dyFormFieldAddList，且 addList 是全量替换语义——
  只发新增行会把整表注册删光）；建数据=POST /dynamic/form/scheme/data/{functionId}（不带
  dataId，dictData 键=bindingField 真实列名；子表必填字段的值必须进子表行）；modelKey 改名
  只能导出副本（save 接口锁死 key，生效口径=BPMN process id）；删模型不删已部署定义，
  历史部署去 #/flow/deploy 或 DELETE /workflow/deploy/{procdefId} 删，否则发起时让手动二选一；
  importModel 连发撞"请勿重复提交"间隔 6~8s；改设计不发布=页面跑老版本快照。
  ★ 流程图不偏移（references/diagram-layout.md）：平台设计器是 bpmn-js，**完全忽略
  Bounds 的宽高**，userTask 一律渲染 90x60、事件 36x36，而 waypoint 按 XML 原样画、不吸附
  ——所以宽高写 140x56 就必然箭头悬空 50px；铁律=宽高写平台尺寸 + 端点贴边(≤1px) +
  全正交 + 每行≤6 蛇形折行 + 导入前 diagram.py 体检五项全 0。
  ★ 节点属性（references/node-attr-spec.md）：nodeAttrs 每条必须带 8 个表单字段，否则
  发布报「基础属性未填写」、设计器不显示节点 ID；改包必须从线上导出再改（attr.modelId 是
  旧环境则子表插不进去）、包内 XML 文件名要带目标分类 ID、nodeForms 缺 createTime 会被丢弃。
  关键词：批量流程、流程设计、审批人、节点权限、发布、deploy、modelKey、改名、导入导出、
  historyFlow、发布流程管理、formInfo、编号规则、qssj、日期回填、真实模拟、流程图偏移、
  线偏移、端点贴边、waypoint、Bounds、90x60、节点ID不显示、基础属性未填写、PRP迁移。
user-invocable: true
---

# 批量新增/配置流程（bestdt 平台，API 版）

> 场景：N 张业务表要挂同一套审批流（施工单位 → 监理 → 工程部专工 → 工程部主任），
> 审批人从**表单字段**取、审批日期自动回填、节点字段只读、最后一根线置「已完成」。
> 2026-10-29 海门 1103 环境实测：7 张表从零到全部走通 + 真实模拟测试 7/7 PASS。
> 脚本在 `scripts/`（自包含），改 `prp.py` 顶部 `BASE`/`TOKEN` 即可换环境。

---

## ★ 怎么调用（对 AI 说这些话）

| 你说 | AI 执行 |
| :--- | :--- |
| 「帮 XX、YY、ZZ 表单各建一个流程，模板用 模板.zip，建完发布并测试」 | ① `detect_forms.py XX YY ZZ` → tables.json（核对编号字段 bh）→ ② `pick_nodes.py XX YY ZZ` → nodes.json（**核对节点清单，删不要的**）→ ③ `build_flows.py --template 模板.zip --apply`（按 nodes.json 动态生成 N 节点）→ ④ `real_test7.py` 出报告 |
| 「就建一个，TS_xxx」 | 同上，code 只传一个 |
| 「从模板文件取，几十个表单」 | code 全列在命令行；tables.json 可手工增删；模板同一个 |
| 「流程名称/编号怎么定」 | **约定：流程名称=表单名称；流程编号=表单编号（功能 code，如 TS_dtts）** |
| 「节点从哪来」 | **自动从表单设计提取**（pick_nodes.py）：取 office 选人控件，按表单出现顺序排；有同名 _date 字段=审批节点（日期回填），否则 label 命中范围词典（施工单位/监理/设计/造价/代保管/工程部/安质部/计划部/物资部/建设单位）才算；都不满足的排除。**多余的节点在 nodes.json 里删（want 改 false）**。模板节点数不重要——节点链按 nodes.json 动态生成 |
| 「字段注册/列表空白/发起时让我选流程」 | 对应 SKILL 第六节/第一节/第五节的修复动作 |

调用案例（一句话直接用）：
> 「帮我给 TS_kxjy、TS_aqjc 这两个表单创建流程，模板用 ts_flow.zip，从模板里取节点，建完发布，再按真实模拟跑一遍出报告」

**必要口径**（说需求时不用重复，AI 应默认遵守）：
- 模板 zip = 平台上 exportModel 导出的任意一个同类流程模型
- 节点链完全按 nodes.json 动态生成（BPMN+设计行），模板里有没有残留节点、几个节点都无所谓；线状态自动：前 N 条=进行中、最后一条=已完成
- 表单里缺审批字段（如 sgdw_id/对应日期）时直接报错，不会静默出错
- 修改任何设计后必须重新发布；同一表单只留一个已发布定义（`#/flow/deploy` 清历史）

---

## 一、前置条件（缺一个就卡半天）

1. **业务表有列**：每张表需要 `sgdw_id/sgdw_name/sgdw_date`、`jldw_*`、`gcbzg_id/gcbzg_name`、
   `gcbzr_id/gcbzr_name/gcbzr_date`、`flow_instance_id/flow_id/flow_startflag/flow_bizstate`。
   缺列页面保存直接 500。幂等加列 SQL 生成器见交付包 `SQL/01_加列.sql` 的写法。
2. **字段注册齐全**（dy_form_field）：注册不是设计器画布本身——**拖控件 + 点保存**才会写。
   脚本直改库/接口加的控件不算注册。检查：`GET /dynamic/form/field/{formId}` 数量 vs 设计控件数。
3. 表单功能已发布（`GET /dynamic/function/{code}` 拿 functionId）。

**补注册的正确姿势**（fix_fields_all.py）：
- ❌ `PUT /dynamic/form` —— 服务端**静默忽略** dyFormFieldVos，返回 200 但是假成功
- ✅ `PUT /dynamic/form/attribute`，body = 表单元数据 + formAttributeJson + mainTable +
  dyFormFieldVos(全量) + dyFormFieldAddList(要加的行)
- ⚠️ **addList 是全量替换语义**：只发新增的 7 行会把该表注册删得只剩 7 行（实测踩雷）。
  必须发「旧全量 + 新增」。addList 行结构：`{title, bindingTable, bindingField, code,
  subForm, subFormCode, virtualField, virtualBindingTable, virtualBindingField, extendAttribute[, datePattern]}`

## 二、批量生成流程（模板法）

单一来源：先在页面手工配好一个模板流程 → `GET /workflow/model/exportModel?modelId=` 导出 ZIP
（`{key}#&{categoryId}#&xml.xml` = BPMN；`entity.xml` = Java XMLDecoder 序列化的 FwDesignVo 全量设计）。

build_flows.py 对每张表做：解析 entity.xml → 剔除模板残留节点 → 改 attr(key/name/startFormId) →
**nodeForms 权限按目标表控件重建**（edit=2 只读 / required=2 / view=按设计器 visible，子表行 type=3，
每行 nodeFormId 发新 uuid）→ nodeUsers（type=8，assignmentId=数据字段名，assignmentKey=表名，
remark=控件 id）→ nodeVars（varId=qssj 的行绑目标日期控件）→ ruleNames（前缀换名、formInfo 绑
`表名.bh 字段`）→ 打包 → `POST /workflow/model/importModel`（multipart，file 字段；连发撞
「请勿重复提交」，间隔 6~8s）→ `POST /workflow/model/deploy {"modeId": modelId}`。

**流程图排版（2026-10-30 用户确认的规范）**：节点**蛇形折行，每行最多 6 个**（`COLS=6`），
不是一条长直线——19 个节点排一行会缩得看不清。折行处自动改成垂直连线（行末节点与下一行行首同列），
箭头方向随奇偶行镜像。改这个只动 DI 坐标段，不影响流程行为。


## 二·五、分支与流转条件（★ 2026-10-30 实测打通）

**这个平台的分支不用网关**——一个 userTask 直接出多条 `sequenceFlow`，每条线上挂条件，
引擎按条件选一条走（等价 PRP 的「连线 Caption 分支」）。样例：`outStoreFlowNative`
（专业工程师同时出「类型≠备件→仓管员」「类型=备件→部门负责人」两条）。
所以做分支**不需要加网关节点**，只改连线和线属性。

### 1. BPMN 侧：线要带条件表达式

```xml
<sequenceFlow id="Flow_b1" name="非汽机专业跳过专业监理" sourceRef="Activity_n3" targetRef="Activity_n5">
  <conditionExpression xsi:type="tFormalExpression"><![CDATA[${sequenceAttrExpression.evaluate(execution, "Flow_b1")}]]></conditionExpression>
</sequenceFlow>
```
表达式是**固定模板**，只换线 id；真正的条件内容不写在 BPMN 里。

### 2. 线属性表 `wf_design_sequence_attribute`（entity.xml 的 nodeSequences）

```json
{"modelId":"<模型id>","nodeId":"Flow_b1",
 "varType":"1","varBean":"formInfo","varDataType":"String",
 "varText":"#{formInfo.<表名>.<字段>}",          // 左值：表单字段
 "varCondition":"1",                              // 比较符枚举
 "varOperation":"#{value.<字典类型>.<字典值>}",     // 右值：字典项 / 字面量
 "remark":"[{\"type\":\"source\"...},{\"type\":\"operator\"...},{\"type\":\"value\"...}]",
 "sortNum":1}
```

- `varBean`：`formInfo`（表单字段）或 `variable`（流程变量，varText 写 `#{variable.a1.a1}`）
- **varCondition 枚举**：`1`== `2`> `3`< `4`!= `5`>= `6`<=（与 UI 下拉顺序一致）
- `varOperation`：字典值写 `#{value.sis_specialty.sis_specialty-QJ}`；普通值直接写
- `remark`：CDATA 里的 JSON 数组，source/operator/value 三段，多条件再插
  `{"type":"connector","label":"&&"|"||"|"("|")"}`，`sortNum` 递增
- **XMLDecoder 细节（不做就 204「导入数据错误!」）**：
  `sortNum` 必须是 `<int>1</int>` 不能是 `<string>`；
  `WfDesignSequenceAttribute` **没有 id 属性**，多写 `<void property="id">` 导入会挂；
  其余字段照 `createBy/createTime/delFlag/modelId/nodeId/remark/updateBy/updateTime/var*` 写。

### 3. 接口

| 用途 | 接口 |
| :--- | :--- |
| 读线条件 | `GET /workflow/design-sequence-attr/list/{modelId}/{flowId}` |
| 写线条件 | `PUT /workflow/design-sequence-attr/addAndEdit`（**body 必须带 bpmnXml**，否则 503「模型xml不能够为空」） |
| 读节点属性 | `GET /workflow/design-node-attribute/list/{modelId}/{nodeId}` |
| 变量候选 | `GET /workflow/design-node-form/getTableFieldsByNodeKeyAndModelId?modelId=&nodeKey=Flow_x&formSourceType=1` |

### 3·5 线条件addAndEdit 500 的真相（2026-11-03 98 环境实测）

对**不存在记录的线**调 `design-sequence-attr/addAndEdit` 报
`500 Cannot invoke "java.util.List.size()" because "sourceList" is null`——
**该接口只能改已有记录，不能新建**（和 nodeAttrs 一样）。
新建线条件唯一姿势 = **改包重导**：exportModel → entity.xml 的 nodeSequences 段写行
（XMLDecoder：sortNum 用 `<int>`、无 id、remark 用 CDATA 的 JSON 数组）+ BPMN 注入
`<conditionExpression>${sequenceAttrExpression.evaluate(execution,"Flow_x")}</conditionExpression>`
→ importModel（同 key 幂等覆盖）→ deploy。

**表单控件 props 认字段口诀**：列名匹配用 `props.dataField`（`dataBind` 是控件 code），
options 数据源（非字典）的 select/radio 选项在 `props.options`（[{label,value}]），条件右值直接写字面量。

### 4. 怎么找现成的分支样本

并发扫全部模型，数 `conditionExpression` 出现次数 > 1 的就是配过分支的（375 个模型里 14 个）：

```python
from concurrent.futures import ThreadPoolExecutor
# GET /workflow/model/{id} → bpmnXml → len(re.findall(r'<conditionExpression', xml)) > 1
```
样本 key：`outStoreFlowNative`、`wsh-cs-001`、`tud_a19anew`、`SY_wdgcysgl`。

### 5. 图上画分支线（DI）

新加的线必须给 `bpmndi:BPMNEdge` waypoint，否则全部堆在左上角 (0,0)。
跨节点绕行用 4 点折线：源底边中点 → 下一行空隙 → 目标底边中点正下方 → 目标底边中点。
源/目标坐标从已有 `BPMNShape` 的 `omgdc:Bounds` 解析，别硬编码。

> 参考实现：`D:\zyt\workbuddy\2026-10-30-13-41-59\flow\branch.py`（19 节点加 3 个分支点、
> 6 条条件线的完整生成脚本，含 BPMN 改造 + 线属性注入 + DI 折线）。

## 二·六、并行会签网关与节点类型（★ 2026-10-30 从 8700 现场样本学到）

**8700 现场只读样本**（`http://111.9.171.57:8700`，token 另给；**只许 GET/exportModel，严禁改**）：
- `tud_ncb2701`：**parallelGateway 并行会签**——建设单位文件中心后 `Gateway_0i5tprm`(会签) 分出
  工程部/计划部/安健环 **三条并行支线**，各支线走完后全部汇入 `Gateway_02cn2gm` 再继续。
- `tud_c13xb`：**一个节点多条出线**（监理单位资料室出 3 条），线可以有自己的
  `nodeAttrs.nodeName`（如「跳过相关单位审批」「主送单位资料员流转」）——线名就配在节点属性表里。

要点（全部实测核对过 entity）：
1. **网关在 entity 里也是一行 `WfDesignNodeAttribute`**（nodeId/nodeKey=Gateway_x、nodeName=会签），
   没有特殊 nodeType 字段；**网关没有 nodeForms/nodeUsers**。网关类型由 BPMN 标签决定
   （parallelGateway / exclusiveGateway / inclusiveGateway）。
2. **`nodeUsers` 的 type 枚举**：`9`=流程发起人（起草人，assignmentId=0）、`1`=指定用户
   （assignmentId=用户 uuid）、`3`=指定用户（同 1 的另一种，8700 样本在用）、
   `8`=表单字段（assignmentId=字段名，assignmentKey=表名）。
3. **`nodeVars`**：审批回填变量绑定（varId=ry/yj/rq/ryid 等），变量本体在 `variables`
   （WfDesignVariable：varName/varType=variable/varValue）。
4. **`ruleNames`**：待办标题规则，`fixedCode`（固定文字）与 `formInfo`（表单字段，value=表名.字段）
   按 sortNum 拼接。
5. `nodeForms` 同一节点可以多行（多个 formSourceType）；并行网关分支内的节点照常配。

**全覆盖测试流程**（1103 `TUD_CSZDSCLC`，脚本 `build_test.py`，已部署 v7）：19 个审批节点不变，
条件分支 ×3 + 并行会签（GW1 分叉 3 支 / GW2 汇聚）+ 回退线 ×1（建设单位负责人按条件回经办人）
+ 线名 ×4 + 线条件 ×7。手排布局 + 手工路由 waypoint（`XY` 字典 + `R` 字典），比蛇形自动布局更适合带分支的图。

## 二·七、外部子流程 callActivity（★ 2026-10-30 从 26.3.10.81 样本学到）

样本：`tud_fb_b22`（表B.0.22 施工/调试进度计划报审表 EPC分包）主流程里嵌「总包内审表」子流程
（26.3.10.81:8700，只读学习；被引用的模型 key 是 **zb-zbnsb**，与表单同名模型 tud_zbnsb 是两个东西）。

**语义**：主流程走到该节点 → 启动子流程实例 → **子流程全部走完才回主流程继续**（Flowable callActivity 语义）。

**BPMN 写法**：
```xml
<callActivity id="Activity_0w6e3t0" name="总包内审表"
              calledElement="zb-zbnsb"                       <!-- 子流程 modelKey -->
              flowable:calledElementType="key"
              flowable:inheritVariables="true"               <!-- 主流程变量透传 -->
              flowable:assignee="${currentUserName}">
  <extensionElements>
    <flowable:executionListener event="start" class="com.best.flow.common.listener.CallActivityExecutionListener"/>
  </extensionElements>
  <multiInstanceLoopCharacteristics isSequential="false" flowable:elementVariable="currentUserName">
    <extensionElements><flowable:inputDataItem><![CDATA[call_activity_inst_count]]></flowable:inputDataItem></extensionElements>
    <loopCardinality>${loopCount}</loopCardinality>
    <completionCondition>${nrOfCompletedInstances == loopCount}</completionCondition>
  </multiInstanceLoopCharacteristics>
</callActivity>
```
多实例 = 按 currentUserName 列表并行起多个子流程实例，全部完成才算过。

**entity 侧（WfDesignNodeAttribute）子流程节点的专有字段**：
```
nodeCallId   = zb-zbnsb        ← 子流程 modelKey（与 BPMN calledElement 一致）
childTable   = tud_zbnsb       ← 子流程业务表
childField   = bh              ← 子流程关联字段
parentField  = bh              ← 主流程关联字段
```

**连线**：子流程节点的出线在子流程实例结束后才走（平台上主流程该节点前后各接一个"文书"类节点，如 总包文书→callActivity→总包文书）。

**布局经验（流程图折行/分支/回退的手工排版）——★ 用户明确要求：以后的流程都要注意美观性**：
- **区域均衡优先**：先算好画布占用，主链蛇形回折（行1 左→右、行2 右→左），让分支区/底行填进
  空象限，不要出现大片空白象限（如左下/右上全空、内容全挤右侧）。
- 回退线优先走**空间更空的一侧**（顶部/底部选一个，别和分支绕行线同层）；竖边要避开所有节点 x 区间；
- 并行支线区：GW1 出线用一条竖向汇流线（x 固定）分三叉，GW2 从**顶/左/底三向进线**；
- 长横线错层 30px 以上（如 y=80/110 两层顶线、y=815/845 两层底线）；
- 同一节点顶边又进又出时，出点/入点 x 错开 25px 以上；
- **★ 网关禁止「同轴穿越」**：进线从顶进、出线从底出时，即使 x 错开 20px，视觉上仍像一条线把
  网关穿透。正确做法：进线分配到**顶/左/底三个方向**（x 也错开 ≥15px），出线固定从**右缘**水平出
  20px 再转向（如 `[(620,600),(640,600),(640,880)]`）；
- 坐标全部收在 `XY`（节点）和 `R`（线路由）两个字典里，改布局只动字典。
- **★ 生成后必须自动校验线端点**（2026-10-30 教训：改节点坐标后线端点没跟着改，7 条线悬空被用户抓到）：
  每条线的**首 waypoint 必须落在 source 的 Bounds 边界上、末 waypoint 落在 target 边界上**
  （容差 2px，在边框上或在矩形内均可，但不能在节点内部悬空）。
  校验逻辑已内置在 `build_test.py` 末尾，不合格直接报错退出、不允许导入。
  注意 waypoint 的命名空间是 **`omgdi`（http://www.omg.org/spec/DD/20100524/DI）**，
  与 BPMNShape/BPMNEdge 的 `bpmndi`（…/BPMN/20100524/DI）不同，解析时别用错。
- 支线/网关进出点 y 坐标 = 节点 y + 高/2（边界中点），改节点 y 后要同步重算，别沿用旧值。
- **★ 端点禁止手算，必须自动吸附（2026-10-30 二次教训）**：手算端点在节点挪动后必错位。
  正确实现：`route()` 只给**中间拐点**，首尾点用 `snap_anchor(rect, other, horizontal)` 自动吸附——
  按首段/末段方向（水平段贴左右缘并保持 y、垂直段贴顶底缘并保持 x），其余坐标 clamp 到节点范围。
  这样全图永远正交、永远贴紧。`boundary_point`（中心连线交点）会破坏正交性，弃用。
- 相邻两条线在同一节点同一边进出时（如 g2 终点与 b4 起点都在 n17 顶边），把其中一条改为**另一侧出**
  （b4 改从 n17 右缘水平出再上绕），避免同点重叠。

## 二·八、审批回填变量（nodeVars / variables，★ 2026-10-30 实测打通）

审批后自动回填签署人/意见/日期到表单字段，靠三层配置，**缺一层就静默不回填（或直接 500）**：

1. **`variables`**：变量定义（WfDesignVariable：varName/varType=variable/varValue=''）。
   **nodeVars 里引用的 varId 必须在这里有定义，variables 为空 = 回填静默不执行**。
2. **type=2 行（取值）**：审批时把 taskInfo 的值写入变量——
   `text=[{"textKey":"taskInfo","textValue":"taskDate","id":"<时间戳>"}]`（紧凑 JSON + CDATA），
   `textParam=taskInfo`，`varId=变量名`，`isappendVal=0`。taskDate=审批日期、taskAssigneeName=审批人名。
3. **type=1 行（回填）**：把变量值写回表单字段——
   `text=字段名(如 sgdw_date)`、`textFiledId=该字段控件id`、`textParam=主表名`、
   `varId=变量名`、`isappendVal=1`。

**血泪坑**：
- **变量值类型必须与列类型匹配**：把签署人（人名字符串）回填进 `date` 类型列 → 审批直接
  500「`[dataUpdateByFormId]表单服务不可用`，update ... set xxx_date=?」SQL 类型错误。
  日期字段必须绑日期类变量（taskDate），别绑错。
- type=1 行的 `isappendVal=1`（生产样本口径）。
- text 的 JSON 必须**紧凑无空格**并包 CDATA，照生产样本抄。
- 生成 nodeVars 时**检查 variables 是否包含全部 varId**，缺就补定义。

**变量名惯例**（8700/1103 样本）：`ry`=审批人、`yj`=意见、`rq`/`qssj`=日期、`ryid`/`qsrid`=人员id、
`fqr`=发起人（variables 里可挂 `text=userName, textParam=startUserInfo` 自动取发起人）。

参考实现：`D:\zyt\workbuddy\2026-10-30-13-41-59\flow\rebuild_nodevars.py`
（19 节点 × 2 行 + EventStart 初始化行的完整重建，含段定位技巧：
FwDesignVo 里 nodeVars 可能是最后一个属性，找"下一个属性"定位段尾会返回 -1 把 entity 截断，
要用 ArrayList 的闭合标记 `'\n   </object>\n  </void>'` 定位段尾）。

### 2.8.5 审批意见回填（2026-11-04 TS_gcdb 实测走通，样本=tud_B109）

表单的意见栏（textarea，如 projectpeng_opinion）要回填审批人填的意见，配两层（结构同日期回填）：

**① 取值行（nodeVars，type=2）**——挂在审批节点上，把该节点填的意见存进变量：
- `varId`=变量名（如 gc_yj，每个意见栏独立变量，不要共用）
- `varType`=variable、`isappendVal`=0、`textParam`=taskInfo
- `text`=CDATA JSON：`[{"textKey":"taskInfo","textValue":"taskComment","id":"<节点id+变量名>"}]`
  ——**taskComment=审批意见、taskDate=完成日期**（B109 样本实证）

**② 回填行（nodeVars，type=1）**——同一个 nodeId，把变量写进表单字段：
- `varId`=同一个变量名、`text`=意见字段（如 projectpeng_opinion）
- `textFiledId`=该字段的**控件 id**（formAttributeJson 里 textarea 的 id，如 textarea_xxx）
- `textParam`=表名、`varType`=variable、`isappendVal`=0

**参数命名规范（2026-11-04 用户定稿，必须遵守）**：
- **拼音首字母缩写**，全局统一：意见=`yj`、时间=`sj`（签收人 `qsr`/`qsrid` 只能用于「签收人」语义，
  **不许拿来当日期回填变量**——2026-11-04 tsd 就是回填行写成 `qsr` 导致一张单的日期全是空）
- **意见只保留一个参数 `yj`**，各节点（工程部主任/安质部主任/创优办负责人…）**共用同一个 yj**，
  不许按节点单独起名（gc_yj/az_yj/cgb_yj 都是错的）；时间同理统一 `sj`（qssj 也是错的）
- 共用不串：每个节点审批完立即用 yj 回填自己的意见栏，下一个节点再覆盖 yj → 实测 7 节点走完
  三处意见栏各自=对应节点的意见 ✓
- **variables（流程参数）段要注册 yj/sj**（WfDesignVariable：varName CDATA、varType=variable、varValue 空），
  这样「流程设计 → 编辑 → 流程参数」页能看到
- 批量改法：导出线上包 → 正则替换 `(<void property="varId">\s*<string>)旧名(</string>)`（**注意多行格式，必须 \s***）
  → variables 补行 → import → deploy → 复核 varId 只剩 yj/sj

**注意**：
- variables 不注册也能回填（机制上不强依赖），但**按用户规范必须注册**
- 同组共享一个意见栏时挂**组内最后一个审批节点**（如工程部主任），取主任的意见
- 验证方法：发起→审批时 complete 的 comment 填不同文字→查表单意见列是否=对应文字
- 字段/变量名**不要手写猜测**：意见字段查表单 textarea 控件 dataField，编号字段用 tables.json 的 bh（detect_forms 探测，如 gcdb=number、其他=bh）

### 2.8.6 改节点参数走接口，不要重导整个包（★ 2026-11-04 实测，比改包快且不升版本）

改 nodeVars 的老做法是「导出包 → 改 entity.xml → importModel → deploy」，慢、易把别的段搞坏。
**平台自带节点参数接口，UI「参数操作」面板就是它**：

```
GET  /workflow/design-node-variable/list/{modelId}/{nodeId}   # 读该节点全部参数行
PUT  /workflow/design-node-variable/addAndEdit                # 写（全量替换该节点）
```
PUT body（缺一个就 500）：
```json
{"modelId":"<模型id>","nodeId":"<节点id>","xml":"<当前 bpmn xml 全文>","bo":[ ...参数行... ]}
```
- `xml` **必带**：先 `GET /workflow/model/exportModel?modelId=` 取 zip，读里面 `KEY#&cat#&xml.xml`
- `bo` 是**该节点参数行的全量数组**（数组，不是对象）；行结构直接复用 list 返回的对象最稳
  （把 `varId` 改掉即可；新增行则去掉 `id` 置 null，别的字段照抄）
- 改完必须 `POST /workflow/model/deploy {"modeId":...}` 才生效（版本号 +1）
- 复核：再 GET list 看 varId 是否已改；然后用**新发起的实例**跑，老实例永远跑旧版本

配套脚本：`scripts/fix_tsd_nodevars.py`（qsr→sj 案例，含 dry-run）

### 2.8.7 子表标记错乱 `isInSubForm`（★ 2026-11-04 TS_tsd 实测）

`dyFormFieldVos.subForm` 完全由控件的 `props.isInSubForm` 推出来。从子表复制控件到主表区域，
`isInSubForm=true` 会跟着留下，字段就变成「主表上的子表字段」→ 打开单据 500 `SUB_TABLE_PARAM_NOT_EXIST`。

一键体检（7 张表单同时扫）：
```python
bad = [v for v in dyFormFieldVos if v.get('subForm') and v.get('bindingTable') == mainTable]
```
修：`props.isInSubForm = False` → `PUT /dynamic/form/attribute`（addList 全量，`subForm` 取 `isInSubForm`）。
参考 `scripts/fix_tsd_subform.py`。**别浪费时间查 relation / dy_form_relation**——主从表配置一致也会报这个错。

## 二·九、线生命周期状态（★ 必配，漏配 = 线全是「未启动」，流程状态不流转）

**规则（用户口径）**：**结束节点前的那条线 = 已完成（finish），其余全部线 = 流程中（going）**——
包括分支线、回退线、网关连线，一条都不能漏。

- 存储：`design-node-attribute.lifeCycleState`，**线 id 当 nodeId 用**，nodeType=sequenceFlow。
  （不是 wf_design_sequence_attribute，别再猜错表。）
- 值：`FlowTemplateStates-flowstate-going` / `FlowTemplateStates-flowstate-finish`。
- 不配的后果：走到那条线时业务状态停在「未启动」，列表流程状态列显示不对。
- 模板自带的线平台会自动带状态行；**自己新增的线（分支/回退/网关连线）默认无行，必须补**。

**接口契约（2026-10-30 UI 抓包，键名特殊）**：
```
PUT /workflow/design-node-attribute/addAndEdit
{ "modelId": ..., "nodeId": "Flow_x",
  "xml": "<BPMN 全文>",                    ← 键名是 xml，不是 bpmnXml！
  "bo": { "nodeKey":"Flow_x", "modelId":..., "nodeId":"Flow_x", "nodeName":"",
          "nodeProgress":null, "messageType":"", "nodeUserSingle":"0",
          "nodeMustOpinion":"0", "selectUserSingleton":"0", "submitMustUser":"0",
          "childTable":"", "childField":"", "parentField":"", "taskInstName":"[\"${InstNameKey}\"]",
          "autoAgree":"0", "openRevoke":"1", "confirmcopyMessageType":"", "doCopy":"0",
          "remark":"", "sortNum":null, "lifeCycleState":"FlowTemplateStates-flowstate-going",
          "messageApitypeJson":"" } }
```
平铺写、用 bpmnXml 键 → 503「模型主键ID不能够为空」/500，别再试错。
改完必须 `POST /workflow/model/deploy`（异步几秒生效），再全量复核每条线。

**脚本**：`scripts/fix_lifecycle.py <modelId>` —— 自动解析 BPMN 线清单、自动识别结束前那条，
批量设置 + 部署 + 32 点复核。**build_flows 部署完成后固定跑一遍**。

## 三、建数据与发起测试

- **创建**：`POST /dynamic/form/scheme/data/{functionId}`（**不带 dataId**；带 = 更新语义，
  新 id 会报「主表数据为空」或生成错误 UPDATE）。body=`{表名:{列:值}}`，**键是 bindingField
  真实列名**，不是控件 code。
- **子表必填字段**：值必须放进子表行 `dictData[子表名]=[{'id':..,字段:值}]`，塞主表会报
  「列 X 不存在」（判断前先看控件 props 的 dataTable / isInSubForm！zgwcsj/clcs 两次误判的教训）。
- **真实值来源**：radio 取 props.options[0].value；select 字典走
  `GET /dictionary-value/categoryCode?code=字典类型`；office=用户 id + dataNameField 填姓名；
  date=当天；switch=defaultValue。必填生成不了就 FAIL，别跳过。
- **发起**：`POST /workflow/process/start/{procdefId}`，procdefId 用
  `GET /workflow/process/flowDefInfoList?formId=&formType=0` 里版本最高的。
- **走节点**：`POST /workflow/task/complete`（todoList 取 taskId，buttonCode=agree）。
  审批人配了表单字段就不用传 nextUserIds。
- **验证**：三个审批日期=当天、flow_startflag=2、flow_bizstate=`FlowTemplateStates-flowstate-finish`。

## 四、流程改名 / 改编号（modelKey）

`POST /workflow/model/save` 会**忽略 modelKey**（UI 也 disabled）——直接改不了。
唯一可行 = **导出副本法**（rename_model.py）：
`exportModel` → zip 内 entity.xml + BPMN 全局替换旧 key → `importModel` → `deploy` →
`DELETE /workflow/model/{modelId}` 删旧。**生效口径是 BPMN 里的 process id**。
回执 `204 流程不存在删除失败` 有误导，以复查为准；连续删间隔 8s。

## 五、★ 删模型 ≠ 删部署（发起时让手动选流程的原因)

删掉模型后，**已部署定义还在引擎里**——同一表单挂两个定义，发起时框架让你手动二选一。
清理：流程中心 → **发布流程管理 `#/flow/deploy`**（页面删），或
`DELETE /workflow/deploy/{procdefId}`。
注意：`GET /workflow/deploy/listAll` **必须带 ?key=xxx** 才返回数据（无参返回空）；返回有抖动需重试。

## 六、列表列配置（不配 = 列表空白）

「表单发布」页每列要勾选，否则一条数据都不显示。批量配（publish_columns_all.py /
fix_must_columns.py）：`PUT /dynamic/function`，body 带全量 `menuColumnDtoList`。

### ★ 必勾字段固定清单（按 bindingField 精确匹配，不许猜字段名）

| bindingField | 名称 | 勾选 | 显示 |
| :--- | :--- | :--- | :--- |
| `id` | 主键ID | 必勾 | 隐藏 |
| `company_code` | 单位代码 | 必勾 | 隐藏 |
| `flow_id` | 流程编号 | 必勾 | 隐藏 |
| `flow_instance_id` | 流程实例ID | 必勾 | 隐藏 |
| `flow_startflag` | 流程状态(flag) | 必勾 | 隐藏 |
| `flow_bizstate` | 流程业务状态 | 必勾 | **可见**（列表「流程状态」列，别名流程状态） |

另外勾选并隐藏：`fdd_dzqz_file_id`（签章文件id）、所有 office 人员 id 列（label 不含 Name 的 office 控件）。
漏勾的后果：别的功能/列表取数时这些字段为空。

**表单里没有该控件时列配置补不了**——注册表/设计树查不到 bindingField 就直接报出来，
让用户在表单设计器里加控件（例：TS_gcdb 表单无「单位代码」控件，列表就带不出 company_code）。

其他要点：
- 流程状态 select 置顶别名「流程状态」+ customJs 着色（流程中橙/已完成绿，code 用各表 select）
- **别名必须 name + fieldAlias 一起改**（服务端用 fieldAlias 覆盖 name）
- **宽度存 fieldAttribute JSON 的 `width` 键**（URL 编码的 JSON，字符串），顶层没有 width 键

### ★ 流程字段列的 fa 生产口径（2026-10-30 实测，TUD_CSZDSCLC 补配验证）

挂了流程的表单，上面 4 个流程字段列必须按生产口径补 fa（占位行只有 code、fa 为空 → 列表不带流程状态）：
- `flow_instance_id` / `flow_id` / `flow_startflag`：**isHidden=true 支撑列**（name/description/title 设好、status=true、virtualField=false、sort/width=None）
- `flow_bizstate`：**虚拟 select「流程状态」**——`virtualField=true`、`virtualBindingTable=sys_dictionary_value`、
  `virtualBindingField=label`、`sort=1` 置顶、`width='100'`、`fieldAlias=流程状态`、
  `extendAttribute={"multiple":false,"dictionaryType":"FlowTemplateStates-flowstate","dataSourceType":"dictionary","type":"select"}`、
  `isHidden=None`（**显示**）
- fa 整体是 **URL 编码的 JSON**（quote 后存 fieldAttribute）
- 参考实现：`flow/final_patch.py`（对照 TS_dtts 生产列逐字段拷贝，只换 menuId/code/formFieldId/bindingTable）

### ★ PUT /dynamic/function 的按钮键是 `dyFunctionButtonAddDtoList`（血泪）

- `PUT /dynamic/function` **会清空按钮**——body 里传 `dyFunctionButtonVoList` **被服务端忽略**（照样清空）。
  正确键：**`dyFunctionButtonAddDtoList` = `[{"functionId":"<功能id>","formButtonId":"<按钮定义id>"}]`×8**，
  formButtonId 从现有 VoList 或 `GET /dynamic/form/button/{formId}` 的按钮定义表按 permissionCode 取。
- **UI「编辑→勾按钮→保存」也会把列 fa 重算覆盖**（虚拟列变 virtual=false/isHidden=true）——
  所以顺序必须是：**UI 勾按钮（或 API 带 AddDtoList）→ API 一次 PUT 修正列 fa（同时带上 AddDtoList 保按钮）**。
  一次 PUT 同时完成列+按钮，不要分两步。
- 每次 PUT 后必须核对：按钮 permissionCode 8 个（流程表单）/6 个（普通表单，含 formTempPrint）+ 4 个流程列 fa。

### ★ 流程状态列显示英文的根因与解法（2026-10-30 实测闭环）

虚拟列（virtualField=true）的字典 join **不可依赖**——同样配置下「机组」列被翻译成中文，
「流程业务状态」列却返回原文 key（FlowTemplateStates-flowstate-going），两者 fa 完全一致，
后端 page 接口的翻译行为不一致（join 参数疑与流程实例相关，主表值为 None 的行反而能翻译出「已完成」）。

**可靠解法：customJs 前端映射**（value 进 renderText 时是原始 key）：

```js
module.exports = function () {
return {
renderText: (value, record, index, code) => {
const map = {"FlowTemplateStates-flowstate-unstart":"未启动","FlowTemplateStates-flowstate-going":"流程中",
"FlowTemplateStates-flowstate-finish":"已完成","FlowTemplateStates-flowstate-reject":"驳回",
"FlowTemplateStates-flowstate-end":"终止"};
const zh = map[value] || (value ? value : "未启动");
let style;
if (zh === "流程中") { style = "color:orange"; } else if (zh === "已完成") { style = "color:green"; }
else if (zh === "驳回") { style = "color:red"; }
return (`<span class='bst-customTable-cellRender' style='${style}'>` + (zh || "") + `</span>`);
},
};
};
```

写入：`PUT /dynamic/function` 的 **customJs** 字段（body 带 `dyFunctionButtonAddDtoList` 保按钮）。
验证：列表页流程状态列显示「未启动/流程中/已完成」中文 + 橙/绿着色，原文 key 不再出现。
**注意 customJs 会被覆盖/清空**——每次 PUT function 都要检查 customJs 是否还在。

## 七、坑清单（全部实测）

| 坑 | 结论 |
| :--- | :--- |
| 改了设计不发布 | 页面跑老版本快照（nodeFormAuth 按 deployment 固化）。**改完必发布** |
| PUT /dynamic/form 回 200 | 假成功，vos 被忽略；用 /dynamic/form/attribute |
| dyFormFieldAddList 只发新增行 | 全量替换，整表注册被删光 |
| importModel 连发 | 「请勿重复提交」，间隔 6~8s |
| 时钟回拨 | `Clock moved backwards`，重试即可 |
| 节点日期权限 | 节点上 edit=2/required=2，日期由 qssj 变量回填，不需要编辑权限 |
| 起始表单必填 + 子表字段 | 值进子表行；脚本按控件 dataTable 分流 |
| 删数据 | `DELETE /dynamic/form/scheme/data/{functionId}/{dataId}` |
| 节点权限有两行 | type=1 和 type=2 **都会生效**（UI 权限面板只显示 type=1），批量改时两种行一起改 |
| 节点字段权限口径 | 日期 + 审批人字段在节点上一律**只读 edit=2**；日期连必填也关掉；审批人必填保留（新建单子时已填） |
| 改配置不发布=白改 | 运行时读**部署快照**；发布异步几秒生效；老实例永远跑老版本；必须用**新发起的实例**验证 |
| 假发布 | 页面模拟点击「发布」可能根本没调部署接口——认准 `POST /workflow/model/deploy`，发布后查 flowDefInfoList 版本号确认 |
| 线状态漏配 | 结束前那条=finish、其余=going，部署后跑 `fix_lifecycle.py <modelId>`（二·九节） |
| **build_flows 生成的流程 deploy 204「连线ID:[Flow_n4]条件表达式绑定表单参数错误」** | 模板 zip 的 nodeSequences 段残留行（绑的是模板表字段），目标表单没有这些字段 → 部署校验失败。修：**无分支流程=改包删掉整个 nodeSequences 段**；有分支=按目标字段重写行 |
| **改包删段后 deploy 204「流程模型命名规则未填写」** | 段删除时 end 定位用了 `find('</void>')` 误配嵌套闭合 → 残缺 XML 导入成功但把后续段（nodeUsers/ruleNames）清空。**必须用配对计数**（references/node-attr-spec.md 的 block_end 模式）找段尾 |
| **entity 段清空写成自闭合 `<object class="java.util.ArrayList"/>`** | importModel 报「导入数据错误!」。必须展开写：`<object class="java.util.ArrayList">\n   </object>`（或整块删除该 void 属性） |
| **残缺导入的恢复** | 残缺导入会把受损段之后的所有属性清空——**不要在线上残缺版上修补**，回到本地 build_flows 生成的完整版 entity 重做 |
| **表单看不了附件（审批页附件不显示）** | **节点表单字段权限缺 `formFile`**（平台附件控件的标准 filedKey）。平台 UI 手动新建流程会自动生成全控件权限（含 formFile），build_flows 生成的只有表单业务字段（34 vs 43）。修：**拿一个手动新建的同表单流程的 nodeForms 权限行做模板**，把它的 43 条权限行整段重建到每个节点的 `wfDesignNodeFormauthList`（`nodeFormId` 换成本模型各块自己的值），别只插一行 |
| **改 nodeForms 后 deploy 204「命名规则未填写」** | 局部插入权限行时 `rfind('   </object>')` 定位错位 → 残缺 XML 把后续段（ruleNames 等）弄丢。**整段重建 + 配对计数定位段尾**，导出后自检各段都在再导入 |
| **`SUB_TABLE_PARAM_NOT_EXIST`（打开单据/查详情 500）** | **主表控件的 `isInSubForm` 残留 true**。从子表里复制控件（或复制整个子表行）到主表区域时，`isInSubForm`/`parent` 不会自动清 → 字段元数据 `dyFormFieldVos.subForm=true`，但 `bindingTable` 是主表 → 平台给主表找子表参数，找不到就抛这个错。**判定一行命令**：`dyFormFieldVos` 里 `subForm=true` 且 `bindingTable == mainTable`。修：设计树里把这些控件的 `isInSubForm` 置 false → `PUT /dynamic/form/attribute`（addList 全量，`subForm` 取自 `isInSubForm`，脚本 `regenerate_fields.py` 就是这个口径）→ 详情立刻恢复 200。**别去查 relation / 主从表配置**（1102/1103 relation 完全一致，纯控件级标记问题） |
| **节点日期/意见回填为空（流程走完但字段 null）** | **取值行与回填行的 `varId` 不是同一个变量**。典型：取值行 `varId=sj`（taskInfo.taskDate），回填行 `varId=qsr` → 回填行读的 qsr 从没被赋值，静默写空、不报错。**逐节点核对**：同 nodeId 下 type=2 行与 type=1 行的 varId 必须相同。修：`PUT /workflow/design-node-variable/addAndEdit`（见二·八·六），改完 deploy，用**新实例**验证 |

## 七·五、编号规则 ruleNames（待办标题）

待办/消息标题 = ruleNames 按 sortNum 拼接：`fixedCode`（固定文字）+ `formInfo`（value=表名.字段）。
生产口径：**「请审批【表名 ： 编号】」**——固定文字 + 该表编号字段（bh / number，按 detect_forms 探测结果）。
**ruleNames 也是模板残留重灾区**：build_flows 复制模板后 ruleNames 里的 formInfo 还绑着模板表的字段，
批量建流程时要按本表重建（name/value 换成本表表名和编号字段）。

## 八、scripts/ 一览

| 脚本 | 用途 |
| :--- | :--- |
| `prp.py` | 环境 BASE/TOKEN + 带重试的 get/req（服务抖动必重试） |
| `detect_forms.py` | 功能 code → 自动探测 formId/主表/编号字段 → tables.json |
| `pick_nodes.py` | 表单设计 → 自动提取审批节点（date 配对 + 范围词典）→ nodes.json |
| `fix_fields_all.py` | 补字段注册（检测缺失 → addList 全量回写） |
| `build_flows.py` | 模板法批量生成流程 → 导入（--apply） |
| `rename_model.py` | 改名/改编号（导出副本法） |
| `publish_columns_all.py` | 批量配列表列（含必勾字段） |
| `fix_must_columns.py` | 按固定清单校正必勾字段（缺失补列、该隐藏的改隐藏），可反复跑 |
| `run_flow7.py` | 全自动建数据→发起→走 4 节点→验证（BH 环境变量指定编号） |
| `real_test7.py` | 真实模拟版（必填控件生成合法值，出报告） |
| **`prp_env.py`** | **公共模块**：环境 BASE/TOKEN/分类（可用 `PRP_HOST`/`PRP_TOKEN`/`PRP_CATEGORY` 覆盖）+ 请求封装 + 导出/导入模型 + 表单查询。**换环境只改这里** |
| **`diagram.py`** | **流程图几何**：尺寸规范 / 端点吸附 / 正交走线 / 五项体检 / 自动修复（`--fix`） |
| **`check_diagram.py`** | 线上流程图几何批量体检，`--fix` 可直接修好回写 |
| **`layout.py`** | 确定性自动排版：蛇形折行、每行≤6、事件居中、任务 90×60 |
| **`node_attrs.py`** | 节点属性补齐 + 全量校验（`--check` / `--apply`），nodeAttrs 8 字段 / nodeUsers / nodeForms |
| **`clear_invalid_forms.py`** | 清理指向不存在表单的引用（起始表单 / 节点表单 / nodeForms.formId） |
| **`bind_form.py`** | 绑定起始表单（PC + 移动端），`--auto` 按流程名自动匹配 |
| **`bind_node_forms.py`** | 给每个 userTask 建节点表单（`formSourceType=2`） |
| `references/diagram-layout.md` | 流程图画线与布局规范（★ 线不偏移） |
| `references/node-attr-spec.md` | 节点属性规范 + entity.xml 结构 + 报错对照 |
| `references/prp-migration-sop.md` | PRP 迁移全链路 SOP + 接口清单 + 故障排查 |

表清单由 `detect_forms.py` 生成 tables.json（formId/mainTable/编号字段 bh 自动探测，bh 拿不准会标 [确认]）。
表单与流程**同包更新**（表单以 SQL 落库、formId 不变）时，模型里的 startFormId 直接对得上，无需重绑；
仅现场表单是新建的才需在流程「基础配置」里重选表单。

## 九、PRP json 解析与单张生成（★ 配合第十二节批量流水线）

> 本节=怎么把一张 PRP json 变成 bestdt 模型；**批量跑、环境问题看第十二节**；画线规范看第十节。

PRP 导出的流程 json 结构（样例 `C:\Users\Administrator\Desktop\prp迁移流程\测试.json`）：

```json
{"nodes": {"nodes_rect21j85i7km0": {"x":268,"y":234,"type":"rect","ActivityType":1,
                                     "Caption":"项目经理","OID":"3edad4c3-..."}},
 "edges": {"2_edges51j85inhfn": {"source":{"id":"nodes_rect61j85id9hf","PtSrc":14},
                                  "target":{"id":"nodes_rect71j85idpvg","PtDst":6},
                                  "Caption":"单源","lineKind":2}}}
```

**节点**：`ActivityType` `7`=开始（ellipse）、`8`=结束（ellipse）、`1`=审批人节点（rect），
`Caption` = 节点名称，`OID` = 稳定 uuid。

**连线**：`source.id` → `target.id`，**`Caption` 就是分支条件的业务文字**
（例："单源"/"非单源"/"修改反馈"）；无 Caption = 无条件线。

**映射到 bestdt**：

| PRP | bestdt |
| :--- | :--- |
| ActivityType 7 / 8 | `startEvent` / `endEvent` |
| ActivityType 1 | `userTask`，name 取 Caption |
| 一个节点多条出边 + Caption | 多条 `sequenceFlow` + 各自的 `conditionExpression` + 线属性（**不加网关**） |
| Caption 文本（单源/修改反馈） | 转成 `varText`(表单字段) + `varCondition` + `varOperation`，**具体字段口径必须问用户** |
| 回退线（如"修改反馈"→回到前面节点） | 普通 sequenceFlow 指回前面节点即可 |

### ★ 一键迁移脚本 `prp_build.py`（2026-11-02 首个实战：集中采购立项请购审批表，效果与原图一致）

用法：拷 scripts/prp_build.py 到工作区，改顶部 4 个常量（SRC_JSON / MODEL_KEY / MODEL_NAME / SKELETON 骨架 zip），
直接跑：解析 PRP json → 生成 BPMN（**布局按 PRP 坐标缩放映射，形状与原图一致**）+ entity → 导入 → 部署。
然后跑 `fix_lifecycle.py <新modelId>` 补线状态。

**PRP 特有处理**：
- ActivityType 7=开始 8=结束 1=审批；**「起草人修改」类节点（有出线无入线）是老系统驳回落点——2026-11-03 用户口径：一比一复刻，要建**（孤立 userTask，Flowable 允许；运行时不可达不影响流转，驳回时平台可指定回到它）**，
  bestdt 用平台驳回替代，不建节点**，其连线一并跳过
- 分支线 Caption（如「单源采购（法规部）」）先写 BPMN 线 name；**条件（design-sequence-attr）
  等表单迁移后再配**（没有表单没法指定 varText 的表名.字段）
- 节点审批人暂绑管理员（nodeUsers type=1），表单迁移后改成表单字段取人
- modelKey 临时起（如 PRP_CGLX），表单迁移后按「流程编号=表名」用导出副本法改名

**迁移踩的坑（都已修进脚本）**：
| 坑 | 结论 |
| :--- | :--- |
| 部署 204「流程模型命名规则未填写」 | **ruleNames 不能为空**，至少放一条 fixedCode（请审批【表名：）；表单迁移后补 formInfo 编号行 |
| 线状态 PUT 204「节点名称与流程图节点名称不一致」 | bo.nodeName 必须 = BPMN 里该线的 name（fix_lifecycle 已自动带） |
| **多条线进结束**（多分支各自汇聚） | **每条 target=endEvent 的线都是已完成(finish)**，fix_lifecycle 已按此判断 |
| entity modelName 改名 | attr.modelName 直接替换即可（列表名称列有缓存，强刷页面） |
| PRP 坐标映射 | 节点中心缩放映射（去负坐标×1.35/0.95），节点 140×56，形状与原图一致 |

### ★ 批量迁移 SOP（用户预告：会来一批测试.json 同款，要求每个达到可用效果）

用户将提供多个 PRP json（简单流程为主）。每个流程按下面 checklist 走，**每一步都有现成脚本/接口**：

| 步骤 | 做什么 | 用什么 |
| :--- | :--- | :--- |
| 0. 摸底 | 每个流程找对应**功能 code / formId / 主表**（表可能已存在：去功能列表/表单注册搜同名；不存在则按布局范式新建） | `GET /dynamic/function/{code}`、`GET /dynamic/form/attribute/{formId}`、按名称模糊搜 |
| 1. 字段 | 从 PRP 节点 Caption 找表单签认控件（office+date 五件套 `_id/_name/_sign/_yj/_date`），缺列生成幂等加列 SQL 并执行 | `GET /dynamic/form/fieldByTable?tableName=` |
| 2. 表单 | 缺表单就按「布局范式」设计（签认块表格布局），**拖控件+保存**才算注册 | `PUT /dynamic/form/attribute`（addList 全量！） |
| 3. 功能 | 功能发布：按钮（流程表单 8 个/普通 6 个）+ 列配置（必勾清单 + 流程 4 列 fa + customJs） | 第六节口径、`final_patch.py`（AddDtoList 键！） |
| 4. 流程 | detect → pick_nodes（节点=Caption 顺序，与签认控件对齐）→ 模板导出 → build_flows → 分支/回退/线条件 | 第二、二·五节 |
| 4.5 线状态 | 结束前那条=已完成、其余=流程中，部署后全量复核 | 二·九节、`fix_lifecycle.py` |
| 5. 回填 | nodeVars + variables 三层配置（日期/签署人） | 二·八节、`rebuild_nodevars.py` |
| 6. 部署核对 | flowDefInfoList 唯一、列表流程状态列显示 | `GET /workflow/process/flowDefInfoList` |
| 7. 测试 | 每个流程发起 1 实例走通（分支多的用回退+改数据覆盖） | `walk_test.py` / `continue2.py` |
| 8. 报告 | 每流程一行：节点序列 / 分支实测 / 回填 / 问题 | 出汇总报告 |

批量执行约定：
- **逐个跑 checklist，不要并行写库**（importModel 有频率限制，服务也会抖）；
- 每个流程失败即记录并继续下一个，最后统一出报告（哪个流程卡在哪一步、缺什么字段）；
- 字段对不上的（PRP 节点在表单里找不到签认控件）**明确列出，不硬编**；
- 全部完成后统一核对：定义唯一、按钮、列、回填、分支行为。

## ★ 加列 SQL 口径（别再按测试环境裁剪）

现场执行环境和测试环境**列现状不一定一致**——按测试环境裁剪过的 SQL，到现场会缺列，
表现为审批人取值为空、日期不落库。

正确做法：**流程要用到的字段全量给**，靠幂等保证安全：

```sql
DO $ddl$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns c
                 WHERE c.table_schema = current_schema()
                   AND c.table_name = 'tts_dtts' AND c.column_name = 'sgdw_id') THEN
    ALTER TABLE tts_dtts ADD COLUMN sgdw_id VARCHAR(200);
  END IF;
END;
$ddl$;
```

- 审批人 id/name 用 `VARCHAR(200)`，审批日期用 `date`
- 用 `DO $ddl$`（不是 `DO $$`），避免和函数体内的 `$$` 冲突
- 现场已有的列会被跳过，重复执行无副作用

## 交付包口径（对齐 update-package skill）

现场交付包**只放交付物，不放 py 脚本**（脚本在 skill 里）：

```
交付包/
├── 流程模型/<模型中文名>.zip ×N  ← exportModel 导出，**必须保留响应里的原始文件名（中文模型名）**，
│                                   勿改名勿换成 key——文件名即中文模型名，无需映射表
├── 表单设计/
│   ├── 【MongoDB】-【表单名,…】.sql        ← 必须用 pack_update.py 拆分成两个文件，
│   └── 【POSTGRESQL/DM】-【表单名,…】.sql     原始下载.sql 不交付
├── SQL/                ← 加列 SQL（现场已有的列不用给，只给真缺的；沿用现场已有 SQL 原文件名）
└── 更新说明.md         ← 必须写：更新的哪些表单、加了哪些字段、做了什么流程、测试结果（≤100 字）；
                          不写「已知坑」长篇、不写列配置步骤（发布时列默认有）
```

**两条铁律（每次都要做，别等用户提醒）：**
1. **流程模型文件名 = exportModel 响应 Content-Disposition 里的名字**（URL 编码的中文模型名，unquote 解码）。
   不要自命名成 key.zip。
2. **表单设计 SQL 下载后必须拆分**（update-package skill 的 pack_update.py），拆成
   【MongoDB】和【业务库】两个文件放进包里；现场是 MongoDB 跑 Mongo 段、业务库跑另一段，
   两个都要执行。只丢一个合体 原始下载.sql 给现场 = 没做完。

命令（环境地址/token 每次单独提供）：
```bash
# 下载表单设计（--database 按现场业务库：POSTGRESQL / MYSQL / DM）
python <update-package>/scripts/download_form_sql.py --host <host> --token <token> \
  --form-ids "<id1>,<id2>,..." --database POSTGRESQL --out 交付包/表单设计/原始下载.sql
# 拆分
python <update-package>/scripts/pack_update.py --sql 交付包/表单设计/原始下载.sql \
  --forms "表单名1,表单名2,..." --out-dir 交付包/表单设计
# 拆完删除原始下载.sql，只留两个分段文件
```

导出流程模型保留原始文件名：
```python
import urllib.request
from urllib.parse import unquote
r = urllib.request.Request(BASE + '/workflow/model/exportModel?modelId=' + mid,
                           headers={'Authorization': 'Bearer ' + TOKEN})
with urllib.request.urlopen(r) as resp:
    name = unquote(resp.headers['Content-Disposition'].split('filename=')[-1].strip('"'))
    data = resp.read()
open(name, 'wb').write(data)   # 例：单体调试记录与审核.zip
```

## 十、流程图画线与布局规范（★ 线不偏移，2026-11-03 实测定稿）

**完整版见 `references/diagram-layout.md`，这一节是必读摘要。**

### ★ 先搞清楚「线偏移」的真正原因（不是画线技巧问题）

平台设计器是 **bpmn-js**，实测行为：

| 你在 XML 里写的 Bounds 宽高 | 平台实际渲染 |
| :--- | :--- |
| userTask `140×56` | **90×60**（宽高被丢弃） |
| userTask `90×60` | 90×60 ✅ |
| 事件 `30×30` | **36×36** |
| 事件 `36×36` | 36×36 ✅ |

而 **waypoint 是严格按 XML 原样绘制的，bpmn-js 不做任何端点吸附**。
Bounds 的 x/y 平台是认的，**只有宽高不认**。

于是：宽高写成 140×56 → 你按 140 算端点 → 平台画出来只有 90 宽 → **箭头悬空 50px** = 「线飘了」。

实测 36 张 PRP 流程 325 条边：端点未贴边 6 条，**全部**集中在写 140×56 的 2 张上，偏移 26~50px。

### 五条铁律

1. **Bounds 宽高 = 平台尺寸**：userTask `90×60`、开始/结束 `36×36`。
   改尺寸时**保持中心不变**（新 x = cx−45，新 y = cy−30）。
   ⚠️ 不要照抄平台原生流程的事件 `30×30`，那是平台自己的老口径，写 `36×36` 才是零偏移。
2. **端点必须贴边**，容差 ≤1px，且按平台尺寸算。**不许手算端点**——必须由
   `snap()` / `snap_anchor()` 生成（节点一挪，手算的端点必错位）。
3. **全正交**：相邻 waypoint 必须 x 相同或 y 相同；坐标用整数
   （平台 `save` 会把 `183.2` 取整成 `183.0`，取整前就已经有误差）。
4. **蛇形折行，每行 ≤6 个**；行末节点垂直落到下一行行尾，不要拉长线横跨；
   带的层数**平均分配**（7 层 → 4+3，不是 6+1）。
5. **导入前必须体检，五项全 0 才准导入**：
   ```bash
   python scripts/diagram.py 模型.zip            # 体检
   python scripts/check_diagram.py               # 线上批量体检
   ```
   五项 = 尺寸错 / 端点偏 / 斜线 / 穿节点 / 无点。

### 画线标准姿势

```
直连（同排）  源右边中点 → 目标左边中点                    2 个 waypoint
折行         源右边中点 →(中间列,源y) →(中间列,目标y) → 目标左边中点
分支线      从节点右侧水平出 20px 再转向；网关禁止「同轴穿越」
回退线      走更空的一侧（顶/底），竖边避开所有节点 x 区间；长横线错层 30px+
同节点进出  出点/入点 x 错开 25px+
```

### 自动修复（尺寸归一 + 端点重吸附 + 阶梯正交化）

```bash
python scripts/diagram.py 模型.zip --fix --out 模型_fixed.zip
```

实测：4 张问题流程（140×56 / 端点偏 / 斜线）修复后五项全绿。
正交化有两条硬约束，返工过三次才做对：
- **只动内部折点，端点绝不移动**（动了就破坏贴边）；
- 后一个点是**固定端点**时不能拉直（两端被节点边界钉死、y 差 2px），
  要**插入阶梯中间点** `mid=(b.x, a.y)`。

### 常见错误对照

| 现象 | 根因 | 修法 |
| :--- | :--- | :--- |
| 箭头悬空几十 px | 宽高写成 140×56 | 改 90×60，端点重算 |
| 线从框里穿出去 | 端点没贴边 | `snap()` 重新吸附 |
| 线是斜的 | 拐点没正交 | 阶梯正交化 |
| 线全堆左上角 | sequenceFlow 没写 waypoint | 每条线都要 `omgdi:waypoint` |
| 线整体错位 | `attr.modelId` 是旧环境 | 从**线上**导出再改包 |

## 十一、节点属性与发布（★ 能发布、能显示节点 ID）

**完整版见 `references/node-attr-spec.md`。**

### nodeAttrs 每条必须带齐 8 个字段

```
nodeFormId / nodeFormType / phoneNodeFormId / phoneNodeFormType
childField / childTable / parentField / messageType
```

- 缺任意一个 → **发布报「流程模型节点[xxx]基础属性未填写！节点ID：[Activity_p12]」**
  且**设计器右上角不显示节点 ID**（属性面板加载不出来）
- `nodeName` 必须与 BPMN 里该 userTask 的 name 一致，否则发布报「节点名称与流程图节点名称不一致」
- `modelId` 必须是**当前线上环境**的 modelId
- `nodeFormId` 没有表单时写**空串**，不要写占位 ID

### 平台没有「新建节点属性」的接口

`PUT /workflow/design-node-attribute/addAndEdit` 对**不存在的**记录直接
`Cannot invoke "Object.getClass()" because "source" is null`（试过 14 种嵌套字段名全部失败）。
→ 只能**从线上导出 → 改 entity.xml → 改包 → importModel 原地覆盖**。

### 改包重导的正确姿势

```
线上 exportModel → 改 entity.xml
                 → 包内 XML 文件名改成 {modelKey}#&{目标分类ID}#&xml.xml
                 → POST /apis/workflow/model/importModel（multipart，字段名 file）
```

- 必须在**包里**改分类 ID（两处：文件名 + entity.xml 的 categoryId）
- `importModel` 对已存在 modelKey **幂等**：原地覆盖，modelId 不变、数量不变
- 连发间隔 6~8s；自写 curl multipart 会返回「导入数据错误!」，用 `prp_env.import_zip`
- 校验不能拿 XML 字节一致当依据：`POST /model/save` 会把 waypoint 坐标**取整**

### nodeForms 的坑

- 缺 `createTime` / `updateTime` → **平台导入时整条丢弃**（数量不涨但接口返回成功）
- `wfDesignNodeFormauthList` 属性不能省（哪怕空 ArrayList）
- 平台不认 entity.xml 里的 nodeForms，必须用接口写：
  `PUT /apis/workflow/design-node-form/addAndEdit`
  body = `{modelId, nodeId, nodeKey, formId, formSourceType:"2", xml, wfDesignNodeFormauthList:[]}`

### 发布接口不可用

`POST /workflow/model/deploy` 一律返回 `{"code":204,"msg":"模型ID为空！！"}`
（入参不是 `{modeId: modelId}`，试过 8 种写法全失败，同 URI 连发还会撞「重复提交了」）。
→ **发布只能由用户在设计器里点**。

### 清理无效表单引用

迁过来的流程往往还指向**源环境**的表单 ID（本环境查 `GET /dynamic/form/attribute/{id}` 返回
`code:900 表单不存在`）。留着坏 ID 的后果：设计器起始表单是坏的、发布后发起失败。
→ 一律清空，等表单建好再用 `bind_form.py` / `bind_node_forms.py` 绑回去。

```bash
python scripts/clear_invalid_forms.py --dry     # 先看清单
python scripts/clear_invalid_forms.py           # 清 4 处：startFormId/phoneStartFormId、
                                                #        nodeFormId/phoneNodeFormId、nodeForms.formId
```

## 十二、PRP 批量迁移 SOP 与故障排查

**完整版见 `references/prp-migration-sop.md`。**

### 一键流水线

```
① PRP json 解析建图（ActivityType 7/8=事件, 1=任务）
② 生成 BPMN（分支=多条 sequenceFlow + 条件，**不加网关**）
③ 排版（layout.py：蛇形折行、90×60、事件 36×36 居中）
④ 画线（route + snap，正交、端点贴边）
⑤ 体检（diagram.py 五项全 0）★ 不合格不许往下走
⑥ 线上 exportModel → 改 entity.xml（nodeAttrs 8 字段 / nodeUsers / nodeForms）
   → 改包内 XML 文件名为目标分类 ID → importModel（间隔 6~8s）
⑦ 绑起始表单 + 节点表单
⑧ node_attrs.py --check --all 全量校验
⑨ 用户在设计器点发布
⑩ 发起 → 审批 → 验证
```

### 接口清单速查

| 用途 | 接口 |
| :--- | :--- |
| 导出/导入模型 | `GET /workflow/model/exportModel?modelId=` / `POST /workflow/model/importModel` |
| 模型保存 | `POST /workflow/model/save`（整个 data 回传，只改 startFormId/phoneStartFormId） |
| 节点属性 | `GET /workflow/design-node-attribute/list/{modelId}/{nodeId}`（写接口对不存在的记录会 NPE） |
| 节点表单 | `GET /workflow/design-node-form/list/{modelId}/{nodeId}` / `PUT .../addAndEdit` |
| 可选表单 | `GET /workflow/form/data` → `data.<组>[]={code,value}` |
| 表单校验 | `GET /dynamic/form/attribute/{id}`（不存在返回 `code:900`） |
| 线条件 | `GET /workflow/design-sequence-attr/list/{modelId}/{flowId}` / `PUT .../addAndEdit`（**body 必须带 bpmnXml**） |
| 发起流程 | `POST /workflow/process/start/{processDefId}` |
| 审批 | `POST /workflow/task/complete` |

### 发起载荷（踩过的坑）

```json
{"dictData": {"mainTable": {"字段key": "值"}}}
```

**必须包一层 `mainTable`**，平铺字段会报「请传入业务数据ID！」。
子表必填字段的值要放进子表行 `dictData[子表名]=[{...}]`。键是 `bindingField` 真实列名。

### ★ 新环境发不起流程（`token ALL`）——环境级问题，不是配置问题

```
INSERT ALL INTO ACT_HI_VARINST ... SELECT * FROM dual
```

Flowable 按 **oracle 方言**生成 `INSERT ALL ... SELECT * FROM dual`（DM 兼容这语法，SQL 本身没错），
**拦截点在 Druid 的 SQL 解析器**（prepareStatement 阶段先 parse，报 `not supported. token ALL`，
根本没到数据库）——所以是 **98 后端的 Druid 版本/配置问题**，不是库的问题：
① 对比 1103（同 DM、发起正常）的 druid 版本（lib 下 druid-*.jar）；
② 对比 application.yml 数据源 `filters` 配置（98 可能开了 wall filter，去掉 `wall` 即可）；
③ 升级 druid 到 1.2.x（对 INSERT ALL 解析完善）。
抓包已确认：完整报错 7439 字符，`Cause: com.alibaba.druid.sql.parser.ParserException: not supported.pos 10, token ALL`，
17 个变量批量 → INSERT ALL 多 INTO；dictData 减到 4 个变量同样触发（MyBatis 语句模板固定）。

对照实验：

| 场景 | 结果 |
| :--- | :--- |
| 新环境 + 我们迁的流程 | ❌ |
| 新环境 + **平台自带的**「项目管理策划」 | ❌ 同样失败 |
| 老环境 + 同一调用 | ✅ |

→ **环境级问题，需运维修新环境 Flowable 数据库类型**。
修好之前**无法在本环境模拟跑数据、无法覆盖多分支**，这条只能等运维，别再从流程配置上找原因。

**已实测绕不过（2026-11-03）**：发起时 dictData 只传必填字段（4 个变量）**同样 500**——
bulkInsert 语句是 MyBatis 固定模板（INSERT ALL 多 INTO），与变量条数无关，API 层无解。
运维侧排查点：① 98 库类型（报错特征是 Oracle 方言，库可能不是 Oracle 却被 Flowable 判成 oracle）
② druid 版本（旧版不认 INSERT ALL，1.2.x 支持）③ 对照 1103 环境（发起正常）的 flowable/druid 配置。


## 二·十 启动时选人 / 全局选人（PRP 98 环境实测 2026-11-05）

### 启动时选人（流程级，发起时弹选人）
- 位置：流程列表「编辑」→ 流程属性 → 基础配置 → **启动时选人**（○配置人员 ●全部人员 ○否）
- **字段：wfDesignAttribute.startUser**（0=否 / 1=配置人员 / **2=全部人员**）
- 改法：GET /workflow/model/{modelId} 取 data → data.wfDesignAttribute.startUser='2' →
  **POST /workflow/model/save（整个 data 原样回传）** → 重新发布
- 批量：对每张 model 改 startUser 后 save；保存不动 BPMN，但发布后才对新实例生效

### 全局选人（节点级，无审批人时由人选人）
- 位置：设计器节点 → 基础配置 → 底部 **全局选人 是/否**
- **字段：design-node-attribute.nodeUserSingle**（"1"=开）；注意不是 submitMustUser（那是"提交必须选人"）
- 改法：GET /workflow/design-node-attribute/list/{modelId}/{nodeId} 取 attr → attr.nodeUserSingle='1' →
  **PUT /workflow/design-node-attribute/addAndEdit，body={modelId, nodeId, xml, bo:attr全量对象}**（bo 必须完整对象，缺 nodeId 会 503）

### 坑
- 「全局选人」≠ submitMustUser；UI 单选 radio 多组并存（通知策略/全局选人/流程审批人单选），
  脚本定位要按 label 文本「全局选人」+同排 y 坐标找"是"
- 启动时选人改完**必须重新发布**；运行中实例绑旧定义，撤回重走才生效
- nodeUsers 清空的节点，无全局选人开关时任务默认落发起人/管理员（即"默认管理员"现象）


## 二·十一 PRP 节点配置定稿、回滚与测试（2026-11-06 会话沉淀）

> 与 11-05 会话 + 本 skill 二·十 对比后补齐。已有：startUser=2（启动时选人=全部人员）、
> nodeUserSingle 字段含义、formFile 附件权限。本次新增：7 项开关、移动端对齐、默认人、
> 回滚清单、测试链路、口径修正。

### 1. 节点基础配置 7 项开关（字段映射，全 39 流程 239 节点）
| 页面开关 | 字段 | 定稿值 |
|---|---|---|
| 全局选人 | nodeUserSingle | 按场景（见 2） |
| 流程审批人单选 | selectUserSingleton | 0 否 |
| 意见是否必填 | nodeMustOpinion | 1 是 |
| 处理时是否同时转发 | doCopy | 0 否 |
| 流转时是否必须选人 | submitMustUser | 1 是 |
| 是否自动同意 | autoAgree | 0 否 |
| 审批任务查看后允许撤回 | openRevoke | 1 是 |

保存：PUT /workflow/design-node-attribute/addAndEdit
body={modelId, nodeId, xml, bo: GET list 的完整 attr 对象（改完回传）}。改完必须重新发布。

### 2. ★ 全局选人开/关是业务口径，别写死
- 11-05：开着（nodeUserSingle=1）时人员选择器异常 → 改回 0，靠「流转必须选人=是」+「启动时选人=全部人员」选人
- 11-06：**当前页面缺少对应的人员字段** → 用户要求全部改回 1，实测选人器正常：
  弹窗「请选择下一节点审批人」列出完整组织/人员树（POST /workflow/instance/fastNodeUsersAndAttrStartUser/{procdefId} [200]、
  /system/frequent/user 常用人员），选人后成功发起、停第一节点
- 结论：**页面有人员字段时用字段选人可关全局选人；页面缺人员字段时开全局选人**。
  选人器异常不是开关本身坏，是配置组合/人员字段缺失，先核对页面字段再切开关。

### 3. 移动端字段权限必须和 PC 一致（以 PC 为准）
- design-node-form/list 每节点返回 **2 条**：formSourceType=1（PC）、2（移动端），各自独立 authList
- 只配 PC（lst[0]）会让移动端停在模板默认 → 权限不一致
- 修复：PUT /workflow/design-node-form/addAndEdit 的 **bo 同时发两条**（1 和 2），
  移动端 auth = PC auth 全量拷贝（含 formFile 附件权限行）
- formFile（平台附件控件标准 filedKey）缺了审批页附件不显示；sync 类脚本全量 PUT 会覆盖它，每次跑完要确认

### 4. 默认人（占位管理员）清除
- 迁移导入时每个节点插了 type=1、assignmentId=管理员账号的占位条目；后续只覆盖部分节点 → 残留"默认人"
- 排查：GET /workflow/design-node-user/list/{modelId}/{nodeId}，数据在 **data.bo 数组**（不是 list 本身）
- 清除：PUT /workflow/design-node-user/addAndEdit {modelId, nodeId, xml, bo:去掉占位后的条目, userJson:''}
  有真实审批人的节点只删占位条目；BPMN XML 里没有硬编码 assignee，不用改 XML
- 11-05 实测 39 张 182 个节点一次清完，复验 0 残留

### 5. 回滚清单做法（用户要求"方便改回来"）
- 批量改配置前，先存每节点改前的 7 字段快照 + modelKey/modelId/nodeId/nodeName
- 输出 JSON：`全局选人改动回滚清单.json`（含 time/reason/scope/change/restore/count/changes）
- 回滚 = 按清单把 nodeUserSingle 改回 before 值，PUT 同接口，改完重新发布
- 原则：任何"暂时全打开/全关闭"性质的批量改动都要留这份快照

### 6. 测试验证链路（改完必跑）
1. UI 发起：业务页 → 新增 → 填必填 → 保存 → 启动流程
2. 看弹窗「请选择下一节点审批人」是否有人员树（=选人器正常）
3. 选人 → 确定 → 确认启动 → GET /workflow/process/todoList 出现第一节点任务 = 发起成功
4. 接口证据：flowDefInfoList 拿最新 procdefId；fastNodeUsersAndAttrStartUser 200；start 200

### 7. 本轮踩过的工程坑（别重复）
- 项目 scripts 与 skill scripts 都有 bind_form.py：sys.path 里 BASE 必须**最后** insert(0)，否则 import 错模块
- urllib 的 GET design-node-form/list 偶发返回空（curl 稳定）→ 读接口用 curl，大 body POST/PUT 用 urllib
- 自封函数返回单值别按 (st, r) 解包；URL 拼接别重复 /apis（404）
- token 有效期短（隔天失效）：浏览器登录态里取 localStorage.access_token 写入 .token_cache.txt
- 运行中实例绑旧流程定义：改配置并发布后，旧实例不受影响，要撤回重走才验证新行为
