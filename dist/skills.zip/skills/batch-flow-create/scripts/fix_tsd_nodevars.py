# -*- coding: utf-8 -*-
"""修 TS_tsd 节点参数：qsr -> sj（流程参数只注册了 yj/sj），并给 n4 补取值行"""
import json, io, sys, zipfile, urllib.request, time
import prp

MID = 'ee3bc808-d40b-11f1-a271-286ed488d29a'
KEY = 'TS_tsd'
NODES = ['Activity_n1', 'Activity_n2', 'Activity_n4']

# ---- 1. 导出模型拿 bpmn xml ----
def export(mid, path):
    r = urllib.request.Request(prp.BASE + '/workflow/model/exportModel?modelId=' + mid, method='GET')
    r.add_header('Authorization', 'Bearer ' + prp.TOKEN)
    r.add_header('accesstype', '1')
    with urllib.request.urlopen(r, timeout=120) as resp:
        open(path, 'wb').write(resp.read())
    return path

zp = export(MID, 'tmp_tsd_live.zip')
z = zipfile.ZipFile(zp)
names = z.namelist()
print('导出内容:', names)
bpmn_name = [n for n in names if n.endswith('xml.xml')][0]
bpmn = z.read(bpmn_name).decode('utf-8')
print('bpmn 长度', len(bpmn))

# ---- 2. 读现有参数行 ----
def list_vars(node):
    st, r = prp.req('GET', '/workflow/design-node-variable/list/%s/%s' % (MID, node))
    return r.get('data') or []

data = {n: list_vars(n) for n in NODES}
for n, rows in data.items():
    print('\n%s -> %d 行' % (n, len(rows)))
    for x in rows:
        print('   type=%s varId=%-6s text=%-16s filedId=%s' % (x.get('type'), x.get('varId'), x.get('text'), x.get('textFiledId')))

# ---- 3. 构造 bo ----
DRY = '--apply' not in sys.argv
for node in NODES:
    rows = data[node]
    bo = []
    for x in rows:
        y = dict(x)
        if y.get('type') == '1' and y.get('varId') == 'qsr':
            y['varId'] = 'sj'
        bo.append(y)
    # n4 补取值行（从 n1 的 type=2 行克隆）
    if node == 'Activity_n4' and not any(y.get('type') == '2' for y in bo):
        tpl = next(x for x in data['Activity_n1'] if x.get('type') == '2')
        new = {k: v for k, v in tpl.items() if k not in ('id', 'createTime', 'updateTime')}
        new.update({'nodeId': node, 'varId': 'sj', 'id': None})
        bo.append(new)
        print('\n%s 补取值行: %s' % (node, json.dumps(new, ensure_ascii=False)[:220]))
    if DRY:
        print('\n[DRY] %s 将提交 %d 行: %s' % (node, len(bo), [(y.get('type'), y.get('varId'), y.get('text')) for y in bo]))
        continue
    body = {'modelId': MID, 'nodeId': node, 'xml': bpmn, 'bo': bo}
    st, r = prp.req('PUT', '/workflow/design-node-variable/addAndEdit', body, timeout=120)
    print('\nPUT %s -> %s code=%s msg=%s' % (node, st, r.get('code'), str(r.get('msg') or r.get('message'))[:200]))
    time.sleep(2)

if DRY:
    sys.exit(0)

# ---- 4. 复核 + 部署 ----
for n in NODES:
    print('\n复核 %s:' % n)
    for x in list_vars(n):
        print('   type=%s varId=%-6s text=%-16s' % (x.get('type'), x.get('varId'), x.get('text')))

st, r = prp.req('POST', '/workflow/model/deploy', {'modeId': MID}, timeout=180)
print('\ndeploy ->', st, r.get('code'), r.get('msg'))
