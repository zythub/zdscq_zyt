# -*- coding: utf-8 -*-
"""真实模拟测试：按表单设计的必填控件逐个生成合法值（等同页面填写），再发起流程。

与 run_flow7.py 的区别：数据不再是全空，必填字段全部按控件类型取真实可选值；
某个必填控件无法生成值 → 该表直接 FAIL 并写明原因，不跳过。

用法: python real_test7.py [BH最终测试]        # 默认编号=最终测试2026年10月30日
报告: 真实模拟测试报告.md
"""
import json, os, sys, time, uuid
from datetime import date
import prp

DIR = os.path.dirname(os.path.abspath(__file__))
ADMIN = '1023f2f07eb790966dce67621f0f889c'
TODAY = date.today().isoformat()
BH = sys.argv[1] if len(sys.argv) > 1 else '最终测试2026年10月30日'

TABLES = {
    'gcdb': dict(func='TS_gcdb', form='7390e6eb320788f67b48786287eed104', table='tts_gcdb_cybyd', bfield='number', model='TS_gcdb'),
    'dbzc': dict(func='TS_dbzc', form='fd740e456753081832cf9869fad71060', table='tts_dbzc',        bfield='bh',     model='TS_dbzc'),
    'ydgl': dict(func='TS_ydgl', form='5bcafee0aa894c93dc4a4d6fe1d8b204', table='tts_ydsq',        bfield='bh',     model='TS_ydgl'),
    'tsd':  dict(func='TS_tsd',  form='bba965a26c6c37bcfbed76e99bf0a2fe', table='tts_tsdgl',       bfield='bh',     model='TS_tsd'),
    'qxgl': dict(func='TS_qxgl', form='e8e8bda8e043329094912a7f3e023b4e', table='tts_qxgl',        bfield='bh',     model='TS_qxgl'),
    'ztts': dict(func='TS_ztts', form='3fc319030c744637a312347d33dc15b5', table='tts_ztts',        bfield='bh',     model='TS_ztts'),
    'dtts': dict(func='TS_dtts', form='d610096003c7d9185a8e1eedcee55846', table='tts_dtts',        bfield='bh',     model='TS_dtts'),
}

_dic_cache = {}


def dic_value(code):
    """字典类型 → 第一个 (value,label)"""
    if code in _dic_cache:
        return _dic_cache[code]
    st, r = prp.get('/dictionary-value/categoryCode?code=' + code)
    rows = r.get('data') or []
    out = (rows[0].get('value'), rows[0].get('label')) if rows else None
    _dic_cache[code] = out
    return out


def org_id():
    st, r = prp.get('/organization/allList?showHidden=false&orgMode=ALL')
    rows = r.get('data') or []
    return (rows[0].get('id'), rows[0].get('name')) if rows else (None, None)


def collect_required(key):
    """起始表单 required+visible 控件清单"""
    d = json.load(open(os.path.join(DIR, 'tmp_forms', key + '.json'), encoding='utf-8'))
    fa = json.loads(d['formAttributeJson'])
    out = []

    def rec(n):
        if isinstance(n, dict):
            p = n.get('props') or {}
            bind = p.get('dataBind')
            if (bind and p.get('required') and p.get('visible') is not False
                    and not p.get('virtualField') and not bind.startswith('subtable_')
                    and not bind.endswith('Name')):
                out.append({'type': n.get('type'), 'code': bind, 'field': p.get('dataField'),
                            'label': p.get('label') or '', 'props': p,
                            'table': p.get('dataTable')})
            for v in n.values():
                rec(v)
        elif isinstance(n, list):
            for v in n:
                rec(v)
    rec(fa)
    # 按 dataField 去重
    seen, uniq = set(), []
    for c in out:
        if c['field'] not in seen:
            seen.add(c['field'])
            uniq.append(c)
    return uniq


def gen_value(c):
    """返回 (值, 描述) 或 (None, 失败原因)"""
    t, p, f = c['type'], c['props'], c['field']
    if t == 'date':
        return {f: TODAY}, '今天'
    if t == 'office':
        name_f = p.get('dataNameField')
        extra = {name_f: '管理员'} if name_f else {}
        return dict([(f, ADMIN)] + list(extra.items())), '管理员(%s)' % ('+姓名' if name_f else '')
    if t == 'org':
        oid, oname = org_id()
        if not oid:
            return None, '机构列表为空'
        name_f = p.get('dataNameField')
        extra = {name_f: oname} if name_f else {}
        return dict([(f, oid)] + list(extra.items())), '机构:' + str(oname)[:10]
    if t == 'select':
        dt = p.get('dictionaryType')
        if p.get('dataSourceType') == 'dictionary' and dt:
            v = dic_value(dt)
            if not v:
                return None, '字典 %s 无值' % dt
            name_f = p.get('dataNameField')
            extra = {name_f: v[1]} if name_f else {}
            return dict([(f, v[0])] + list(extra.items())), '字典%s=%s' % (dt, v[0])
        opts = p.get('options') or []
        if opts:
            return {f: opts[0].get('value')}, '选项:' + str(opts[0].get('label'))
        return None, 'select 无数据源'
    if t in ('radio',):
        opts = p.get('options') or []
        if opts:
            return {f: opts[0].get('value')}, '选项:' + str(opts[0].get('label'))
        return None, 'radio 无选项'
    if t == 'switch':
        dv = p.get('defaultValue')
        return {f: dv if dv is not None else False}, '开关=%s' % (dv if dv is not None else False)
    if t in ('input', 'textarea', 'editor', 'number', 'inputnumber'):
        return {f: '真实模拟测试数据'}, '文本'
    if t == 'text':
        return None, '静态文本被设为必填(配置异常)'
    return None, '未知类型 %s' % t


def latest_def(form_id, model_key):
    st, r = prp.get('/workflow/process/flowDefInfoList?formId=%s&formType=0' % form_id)
    best, bv = None, -1
    for x in (r.get('data') or []):
        pid = str(x.get('procdefId') or '')
        if not pid.startswith(model_key + ':'):
            continue
        try:
            v = int(pid.split(':')[1])
        except (IndexError, ValueError):
            v = 0
        if v > bv:
            best, bv = pid, v
    return best


def read_record(fn_id, data_id):
    st, r = prp.get('/dynamic/form/scheme/data/%s/%s' % (fn_id, data_id))
    d = r.get('data') or {}
    out = {}
    mt = d.get('mainTable') or {}
    if mt:
        out[mt['table']] = {x['field']: x.get('value') for x in (mt.get('mainData') or [])}
    return out


def todo(ins):
    st, r = prp.get('/workflow/process/todoList?currentPage=1&pageSize=200')
    return [x for x in ((r.get('data') or {}).get('records') or [])
            if x.get('procInsId') == ins]


def run_one(key):
    cfg = TABLES[key]
    res = {'key': key, 'name': cfg['model'], 'required': [], 'ok': False}
    print('=' * 66)
    print('[%s] %s' % (key, cfg['model']))

    # 1) 必填控件 → 生成值
    reqs = collect_required(key)
    st, r = prp.get('/dynamic/form/field/' + cfg['form'])
    fields = [x for x in (r.get('data') or [])
              if not x.get('subForm') and x.get('bindingTable') == cfg['table']]
    row = {x['bindingField']: None for x in fields}
    row.pop('sys_deleteflag', None)
    data_id = uuid.uuid4().hex
    row['id'] = data_id
    row[cfg['bfield']] = BH

    fail = None
    sub_rows = {}  # 子表字段：{子表名: 行dict}
    for c in reqs:
        v, desc = gen_value(c)
        if v is None:
            fail = '必填「%s」(%s) 无法生成值: %s' % (c['label'], c['field'], desc)
            res['required'].append({'field': c['field'], 'label': c['label'],
                                    'type': c['type'], 'value': '!! ' + desc})
            continue
        if c.get('table') and c['table'] != cfg['table']:
            # 子表字段：写入对应子表行
            srow = sub_rows.setdefault(c['table'], {'id': uuid.uuid4().hex})
            srow.update(v)
        else:
            row.update(v)
        vv = v.get(c['field'])
        res['required'].append({'field': c['field'], 'label': c['label'],
                                'type': c['type'], 'value': str(vv)[:40],
                                'table': c.get('table')})
    if fail:
        res['error'] = fail
        print('  !! 校验不过:', fail)
        return res

    # 2) 保存（子表字段随 dictData 一并提交；缺列剔除仅作兜底）
    fn = (prp.get('/dynamic/function/' + cfg['func'])[1].get('data') or {}).get('id')
    body = dict({cfg['table']: row}, **{k: [v] for k, v in sub_rows.items()})
    missing_note = []
    for attempt in range(3):
        st, r = prp.req('POST', '/dynamic/form/scheme/data/%s' % fn, body)
        if r.get('code') == 200:
            break
        msg = str(r.get('msg') or '')
        import re as _re
        m = _re.search(r'列 "([^"]+)"在关系"([^"]+)"中不存在', msg)
        if not m:
            break
        col = m.group(1)
        row.pop(col, None)
        missing_note.append(col)
        print('  !! 物理表缺列 %s，剔除后重试（页面填写会报错）' % col)
        time.sleep(1)
    res['save'] = '%s %s %s' % (st, r.get('code'), (r.get('msg') or ''))[:80]
    if missing_note:
        res['missing_cols'] = missing_note
    print('  保存 ->', res['save'])
    if r.get('code') != 200:
        res['error'] = '保存失败: ' + res['save']
        return res

    # 3) 发起
    time.sleep(1)
    dict_data = read_record(fn, data_id)
    proc = latest_def(cfg['form'], cfg['model'])
    st, r = prp.req('POST', '/workflow/process/start/' + proc,
                    {'processDefId': proc, 'dictData': dict_data,
                     'nextUserIds': '', 'copyUserIds': '', 'comment': '真实模拟发起'})
    res['start'] = '%s %s' % (r.get('code'), (r.get('msg') or ''))[:60]
    print('  发起 ->', res['start'])
    if r.get('code') != 200:
        res['error'] = '发起失败: ' + json.dumps(r, ensure_ascii=False)[:200]
        return res
    ins = res['ins'] = r['data']

    # 4) 走 4 节点
    steps = []
    for step in range(1, 5):
        time.sleep(1.5)
        ts = todo(ins)
        if not ts:
            steps.append('第%d步: 无待办' % step)
            break
        t = ts[0]
        for attempt in range(3):
            st, r2 = prp.req('POST', '/workflow/task/complete',
                             {'taskId': t['taskId'], 'procInsId': ins,
                              'comment': '同意(%s)' % t.get('taskName'),
                              'nextUserIds': '', 'copyUserIds': '', 'buttonCode': 'agree'})
            ok2 = (st == 200 and r2.get('code') == 200)
            if ok2 or 'moved backwards' not in str(r2.get('msg') or ''):
                break
            time.sleep(5)
        steps.append('第%d步 %s: %s' % (step, t.get('taskName'), 'OK' if ok2 else ('FAIL ' + str(r2.get('msg'))[:60])))
        if not ok2:
            break
    res['steps'] = steps
    for s in steps:
        print('   ', s)

    # 5) 验证
    time.sleep(1.5)
    rrow = read_record(fn, data_id).get(cfg['table']) or {}
    dates = {f: rrow.get(f) for f in ('sgdw_date', 'jldw_date', 'gcbzr_date')}
    biz = str(rrow.get('flow_bizstate') or '')
    dates_ok = all(str(v or '').startswith(TODAY) for v in dates.values())
    res['verify'] = {'bh': rrow.get(cfg['bfield']), 'startflag': rrow.get('flow_startflag'),
                     'bizstate': biz, 'dates': dates}
    res['ok'] = bool(dates_ok and biz.endswith('finish') and len(steps) == 4)
    print('  验证 [%s]' % ('PASS' if res['ok'] else 'FAIL'))
    return res


def report(results):
    lines = ['# 7 张表单流程真实模拟测试报告', '',
             '- 时间：%s' % time.strftime('%Y-%m-%d %H:%M:%S'),
             '- 方式：按各表起始表单设计的**必填控件逐个生成合法值**（等同页面填写），保存 → 发起 → 四节点审批 → 验证',
             '- 单据编号：%s' % BH, '',
             '## 总结果', '',
             '| 表单 | 必填项数 | 保存 | 发起 | 四节点 | 日期回填 | 结论 |',
             '|---|---|---|---|---|---|---|']
    for x in results:
        n_req = len(x.get('required') or [])
        save = 'OK' if (x.get('save') or '').startswith('200 200') else (x.get('save') or '-')
        start = 'OK' if (x.get('start') or '').startswith('200') else (x.get('start') or '-')
        steps_ok = len([s for s in x.get('steps') or [] if s.endswith('OK')])
        v = x.get('verify') or {}
        dates_ok = all(str(d or '').startswith(TODAY) for d in (v.get('dates') or {}).values()) if v else False
        lines.append('| %s | %d | %s | %s | %d/4 | %s | **%s** |' % (
            x['name'], n_req, save, start, steps_ok,
            ('OK' if dates_ok else '-'), 'PASS' if x.get('ok') else 'FAIL'))
    lines.append('')
    for x in results:
        lines.append('## %s（%s）' % (x['name'], x['key']))
        lines.append('')
        if x.get('error'):
            lines.append('- ❌ 失败原因：%s' % x['error'])
        if x.get('missing_cols'):
            lines.append('- ⚠️ 字段 %s 保存时仍被写入主表并报缺列（兜底剔除后走通），需检查该控件的表绑定。' % '、'.join(x['missing_cols']))
        if x.get('required'):
            lines.append('')
            lines.append('| 必填控件 | 字段 | 类型 | 填的值 |')
            lines.append('|---|---|---|---|')
            for c in x['required']:
                lines.append('| %s | %s | %s | %s |' % (c['label'], c['field'], c['type'], c['value']))
        if x.get('steps'):
            lines.append('')
            for s in x['steps']:
                lines.append('- ' + s)
        v = x.get('verify') or {}
        if v:
            lines.append('')
            lines.append('- 最终：startflag=%s，bizstate=%s' % (v.get('startflag'), v.get('bizstate')))
            lines.append('- 日期：sgdw=%s jldw=%s gcbzr=%s' % tuple(
                (v.get('dates') or {}).get(f) for f in ('sgdw_date', 'jldw_date', 'gcbzr_date')))
        lines.append('')
    p = os.path.join(DIR, '真实模拟测试报告.md')
    open(p, 'w', encoding='utf-8').write('\n'.join(lines))
    print('\n报告 ->', p)
    return p


def main():
    keys = list(TABLES)
    results = []
    for k in keys:
        try:
            results.append(run_one(k))
        except Exception as e:
            results.append({'key': k, 'name': TABLES[k]['model'], 'ok': False,
                            'error': '异常: ' + repr(e)[:150]})
        time.sleep(2)
    print('\n汇总:')
    for x in results:
        print('  %-6s %s' % (x['key'], 'PASS' if x.get('ok') else 'FAIL  ' + (x.get('error') or '')[:80]))
    report(results)


if __name__ == '__main__':
    main()
