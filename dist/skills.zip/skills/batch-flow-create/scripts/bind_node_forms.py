# -*- coding: utf-8 -*-
"""给流程的每个用户节点绑定表单（设计态节点表单 + 字段权限）。

参照平台自带流程（缺陷管理 TS_qxgl）：每个 userTask 的 nodeAttrs.nodeFormId 指向同一张
流程表单，同时设计态表 design_node_form 里有一条 WfDesignNodeForm 记录（含字段权限列表）。

平台不认 entity.xml 里带的 nodeForms（改包重导会被丢弃），只能用接口写：

  PUT /apis/workflow/design-node-form/addAndEdit
    {modelId, nodeId, nodeKey, formId, formSourceType:"2", xml, wfDesignNodeFormauthList:[]}

  三个坑：
   - 必须带 xml，否则报「字段:xml不允许值:null」
   - 必须带 wfDesignNodeFormauthList（哪怕空数组），否则接口返回 200 但数据不落库
   - formSourceType 用 "2"（跟缺陷管理一致）
  查询：GET /apis/workflow/design-node-form/list/{modelId}/{nodeId}

用法：
  export PRP_HOST=http://98.87.119.14
  export PRP_TOKEN=xxx
  python scripts/bind_node_forms.py --list
  python scripts/bind_node_forms.py --flow PRP_CGLX
  python scripts/bind_node_forms.py --all
  python scripts/bind_node_forms.py --all --dry
"""
import argparse
import os
import re
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import prp_env as E          # noqa: E402


def tasks(xml):
    out = []
    for m in re.finditer(r"<userTask([^>]*)>", xml):
        a = m.group(1)
        i = re.search(r'id="([^"]+)"', a)
        n = re.search(r'name="([^"]*)"', a)
        if i:
            out.append((i.group(1), n.group(1) if n else i.group(1)))
    return out


def bind_flow(key, fid, dry=False):
    recs = E.models()
    m = next((r for r in recs if r["modelKey"] == key), None)
    if not m:
        print("  没找到流程", key)
        return False
    mid = m["modelId"]
    st, d = E.get("/workflow/model/" + mid)
    xml = (d.get("data") or {}).get("bpmnXml") or ""
    okc = 0
    for nid, nname in tasks(xml):
        st, cur = E.get("/workflow/design-node-form/list/%s/%s" % (mid, nid))
        cur = cur.get("data") or []
        if any(x.get("formId") == fid for x in cur):
            okc += 1
            continue
        if dry:
            print("    %-16s %s -> %s" % (nid, nname, fid))
            continue
        body = {"modelId": mid, "nodeId": nid, "nodeKey": nid, "formId": fid,
                "formSourceType": "2", "xml": xml, "wfDesignNodeFormauthList": []}
        st, r = E.put("/workflow/design-node-form/addAndEdit", body)
        time.sleep(0.4)
        if r.get("code") == 200:
            okc += 1
        else:
            print("    !! %s %s" % (nid, str(r)[:120]))
    total = len(tasks(xml))
    print("  %-12s %-24s 节点 %d，已绑定 %d %s" % (key, m["modelName"], total, okc,
                                                  "(dry)" if dry else ""))
    return okc == total


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--flow")
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--dry", action="store_true")
    a = ap.parse_args()

    fmap = E.form_map()
    recs = E.models()
    pairs = [(r["modelKey"], r["modelName"], fmap[r["modelName"].strip()])
             for r in recs if r["modelName"].strip() in fmap]

    if a.list:
        for k, n, f in pairs:
            print("%-12s %-26s %s" % (k, n, f))
        print("能按同名对上的 %d / %d" % (len(pairs), len(recs)))
        return

    if a.all:
        for k, n, f in pairs:
            bind_flow(k, f, a.dry)
            time.sleep(1)
        return

    if not a.flow:
        ap.error("需要 --flow / --all / --list")
    rec = next((r for r in recs if r["modelKey"] == a.flow), None)
    if not rec:
        sys.exit("没找到流程 " + a.flow)
    fid = fmap.get(rec["modelName"].strip())
    if not fid:
        sys.exit("平台上没有同名表单：%s" % rec["modelName"])
    bind_flow(a.flow, fid, a.dry)


if __name__ == "__main__":
    main()
