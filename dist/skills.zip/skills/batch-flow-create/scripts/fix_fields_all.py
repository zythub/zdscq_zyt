# -*- coding: utf-8 -*-
"""盘点并补齐 6 张表的 dy_form_field 注册（审批 7 字段）

对每张表：
  1. GET /dynamic/form/attribute/{formId} → 存 tmp_forms/{key}.json（供 build_flows.py 用）
  2. GET /dynamic/form/field/{formId}     → 已注册 code 集合
  3. 找出设计里绑定了 sgdw_id/jldw_id/gcbzg_id/gcbzr_id/sgdw_date/jldw_date/gcbzr_date
     但未注册的控件 → 生成 new_row → PUT /dynamic/form 补注册
用法: python fix_fields_all.py [--apply]
"""
import json, os, sys, uuid, prp

DIR = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(DIR, 'tmp_forms')
os.makedirs(OUT, exist_ok=True)

FORMS = [
    # key, formId, 表名
    ('gcdb', '7390e6eb320788f67b48786287eed104', 'tts_gcdb_cybyd'),
    ('dbzc', 'fd740e456753081832cf9869fad71060', 'tts_dbzc'),
    ('ydgl', '5bcafee0aa894c93dc4a4d6fe1d8b204', 'tts_ydsq'),
    ('tsd',  'bba965a26c6c37bcfbed76e99bf0a2fe', 'tts_tsdgl'),
    ('qxgl', 'e8e8bda8e043329094912a7f3e023b4e', 'tts_qxgl'),
    ('ztts', '3fc319030c744637a312347d33dc15b5', 'tts_ztts'),
]

NEED = {'sgdw_id', 'jldw_id', 'gcbzg_id', 'gcbzr_id',
        'sgdw_date', 'jldw_date', 'gcbzr_date'}

EXT = {
    'office': '{"multiple":false,"valueRange":"all","currentOrg":null,"type":"office"}',
    'date': '{"dateFormat":"YYYY-MM-DD","dateType":"date","type":"date","datePattern":"YYYY-MM-DD"}',
}


def ctrl_kind(code):
    if code.startswith('office'):
        return 'office'
    if code.startswith('date'):
        return 'date'
    return ''


def new_row(code, title, field, kind, table, sort):
    return {
        'subForm': False, 'subFormCode': None,
        'code': code, 'title': title, 'fieldAlias': title,
        'bindingTable': table, 'bindingField': field,
        'virtualField': False, 'virtualBindingTable': '', 'virtualBindingField': '',
        'attributeJson': None, 'sort': sort,
        'datePattern': 'YYYY-MM-DD' if kind == 'date' else None,
        'extendAttribute': EXT[kind],
        'viewStatus': None, 'updateStatus': None,
        'id': uuid.uuid4().hex,
    }


def walk_controls(data, out):
    """递归收集控件：来自 formAttributeJson 设计树（dataBind/dataField/label）+ 已注册 vos"""
    fa = data.get('formAttributeJson')
    tree = json.loads(fa) if isinstance(fa, str) else (fa or {})

    def rec(n):
        if isinstance(n, dict):
            props = n.get('props') or {}
            bind = props.get('dataBind')
            if bind:
                out.append({'code': bind,
                            'title': props.get('label') or '',
                            'field': props.get('dataField')})
            for v in n.values():
                rec(v)
        elif isinstance(n, list):
            for v in n:
                rec(v)

    rec(tree)
    for v in data.get('dyFormFieldVos') or []:
        out.append({'code': v.get('code'), 'title': v.get('title') or '',
                    'field': v.get('bindingField')})


def main():
    apply = '--apply' in sys.argv
    for key, form_id, table in FORMS:
        print('=' * 60)
        print(key, form_id, table)
        for attempt in range(5):
            st, d = prp.get('/dynamic/form/attribute/' + form_id)
            if st == 200 and d.get('data'):
                break
        data = d.get('data')
        if not data:
            print('  !! attribute 拉取失败')
            continue
        json.dump(data, open(os.path.join(OUT, key + '.json'), 'w',
                             encoding='utf-8'), ensure_ascii=False, indent=1)

        ctrls = []
        walk_controls(data, ctrls)
        by_field = {}
        for c in ctrls:
            by_field.setdefault(c['field'], []).append(c)

        st, r = prp.get('/dynamic/form/field/' + form_id)
        rows = (r.get('data') if isinstance(r, dict) else None) or []
        have = {x['code'] for x in rows}
        print('  控件 %d 个，已注册 %d 条' % (len(ctrls), len(have)))

        vos = data.get('dyFormFieldVos') or []
        sort = max([v.get('sort') or 0 for v in vos] or [0]) + 1
        add = []
        for field in sorted(NEED):
            cs = [c for c in by_field.get(field, []) if not c['code'].endswith('Name')]
            if not cs:
                print('  !! 设计里没有绑定 %s 的控件' % field)
                continue
            c = cs[0]
            if c['code'] in have:
                continue
            kind = ctrl_kind(c['code'])
            if kind not in ('office', 'date'):
                print('  !! %s 类型异常: %r' % (field, kind))
                continue
            add.append(new_row(c['code'], c['title'], field, kind, table, sort))
            sort += 1

        if not add:
            print('  注册已齐')
            continue
        for a in add:
            print('  + %-32s %-10s %s' % (a['code'], a['bindingField'], a['title']))
        if not apply:
            print('  [dry] 加 --apply 才写')
            continue
        data['dyFormFieldVos'] = vos + add
        st, r = prp.req('PUT', '/dynamic/form', data)
        print('  PUT ->', st, r.get('code'), r.get('msg'))
        st, r = prp.get('/dynamic/form/field/' + form_id)
        got = {x['code'] for x in ((r.get('data') or []))}
        print('  回读 %d 条，缺:' % len(got),
              [a['code'] for a in add if a['code'] not in got] or '无')


if __name__ == '__main__':
    main()
