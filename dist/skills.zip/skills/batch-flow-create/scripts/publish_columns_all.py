# -*- coding: utf-8 -*-
"""6 张表批量配「表单发布」列（dtts 已配好，不动）

策略（对齐 dtts 模板）：
  隐藏：主键id / 签章文件id / 流程实例id / 流程编号 / 流程状态flag / office人员id列
  可见：流程业务状态(select, 别名「流程状态」, 置顶) + 其余全部业务列（按注册顺序，统一宽度）
  customJs：流程中橙色 / 已完成绿色
用法: python publish_columns_all.py [--apply]
"""
import json, os, sys, uuid
from urllib.parse import quote
import prp

DIR = os.path.dirname(os.path.abspath(__file__))

SELECT_BIZ = {
    'gcdb': 'select_kap6ml002usrwldz8a',
    'dbzc': 'select_j4o9p9wucdvlihigmi',
    'ydgl': 'select_8y58kohrze0pk7jse1',
    'tsd':  'select_b5moku65g2jgbbgw71',
    'qxgl': 'select_3rccyxvutkqdvwhf59',
    'ztts': 'select_0o7qgqzao84w77rj6u',
}
TABLES = {
    'gcdb': dict(form='7390e6eb320788f67b48786287eed104', table='tts_gcdb_cybyd'),
    'dbzc': dict(form='fd740e456753081832cf9869fad71060', table='tts_dbzc'),
    'ydgl': dict(form='5bcafee0aa894c93dc4a4d6fe1d8b204', table='tts_ydsq'),
    'tsd':  dict(form='bba965a26c6c37bcfbed76e99bf0a2fe', table='tts_tsdgl'),
    'qxgl': dict(form='e8e8bda8e043329094912a7f3e023b4e', table='tts_qxgl'),
    'ztts': dict(form='3fc319030c744637a312347d33dc15b5', table='tts_ztts'),
}

CUSTOM_JS = """module.exports = function () {
return {
renderText: (value, record, index, code) => {
let style;
if (code === "%s") {
if (value === "流程中") {
style = "color:orange";
} else if (value === "已完成") {
style = "color:green";
}
}
return (
`<span class='bst-customTable-cellRender' style='${style}'>` +
(value || "") +
`</span>`
);
},
};
};"""

# 必勾隐藏字段（固定口径，按 bindingField 匹配，不许猜字段名）
HIDDEN_FIELDS = {'id', 'company_code', 'flow_id', 'flow_instance_id', 'flow_startflag', 'fdd_dzqz_file_id'}


def width_of(code, meta):
    if code == '__sel__':
        return 100
    if code.startswith('date'):
        return 115
    if code.startswith('textarea') or code.startswith('editor'):
        return 180
    return 130


def build_column(code, meta, old, alias, hidden, sort, menu_id, width):
    e = {
        'id': (old or {}).get('id') or uuid.uuid4().hex,
        'menuId': menu_id,
        'code': code,
        'name': alias or meta.get('title'),
        'description': meta.get('title'),
        'sort': sort,
        'status': True,
        'formFieldId': code,
        'supportQuery': (old or {}).get('supportQuery') or False,
        'mobileSupportQuery': None,
        'dictCategoryNumber': None,
        'subForm': bool(meta.get('subForm')),
        'subFormCode': meta.get('subFormCode'),
        'title': meta.get('title'),
        'bindingTable': meta.get('bindingTable'),
        'bindingField': meta.get('bindingField'),
        'virtualField': bool(meta.get('virtualField')),
        'virtualBindingTable': meta.get('virtualBindingTable') or '',
        'virtualBindingField': meta.get('virtualBindingField') or '',
        'attributeJson': None,
        'datePattern': meta.get('datePattern'),
        'extendAttribute': meta.get('extendAttribute'),
        'viewStatus': None,
        'updateStatus': None,
        'headerQuery': False,
    }
    if alias:
        e['name'] = alias
        e['fieldAlias'] = alias
    attr = dict(e)
    if hidden:
        attr['isHidden'] = True
    if width:
        attr['width'] = str(width)
    e['fieldAttribute'] = quote(json.dumps(attr, ensure_ascii=False), safe='')
    return e


def do_one(key, apply):
    cfg = TABLES[key]
    st, d = prp.get('/dynamic/function/' + 'TS_' + ('dtts' if key == 'dtts' else key))
    fn = d['data']
    if not fn:
        print(key, '!! 功能不存在')
        return
    json.dump(fn, open(os.path.join(DIR, 'backup', 'function_TS_%s.json' % key), 'w',
                       encoding='utf-8'), ensure_ascii=False, indent=1)
    for _ in range(4):
        st, r = prp.get('/dynamic/form/field/' + cfg['form'])
        rows = r.get('data') or []
        if rows:
            break
    meta = {x['code']: x for x in rows}
    old = {x['code']: x for x in (fn.get('menuColumnDtoList') or [])}
    menu_id = fn['menuId']

    sel = SELECT_BIZ[key]
    cols, sort = [], 0
    # 1) 流程状态置顶
    if sel in meta:
        sort += 1
        cols.append(build_column(sel, meta[sel], old.get(sel), '流程状态', False, sort, menu_id, 100))
    else:
        print(key, '!! 找不到流程状态 select', sel)
    # 2) 隐藏系统列 + office id 列；其余可见
    for code, m in sorted(meta.items(), key=lambda kv: kv[1].get('sort') or 0):
        if code == sel or m.get('subForm') or m.get('virtualField'):
            continue
        bf = m.get('bindingField') or ''
        is_office_id = code.startswith('office') and not code.endswith('Name')
        if bf in HIDDEN_FIELDS or is_office_id:
            cols.append(build_column(code, m, old.get(code), None, True, None, menu_id, None))
        else:
            sort += 1
            alias = None
            if code.endswith('Name') and m.get('title', '').endswith('Name'):
                alias = m['title'][:-4] or None
            cols.append(build_column(code, m, old.get(code), alias, False, sort, menu_id,
                                     width_of(code, m)))

    body = {k: fn.get(k) for k in ('id', 'type', 'menuTypeList', 'path', 'menuId', 'menuSort',
                                   'parentMenuId', 'code', 'name', 'pushStatus', 'functionConfig',
                                   'formId')}
    body['dyFunctionButtonAddDtoList'] = [
        {'functionId': fn['id'], 'formButtonId': b['formButtonId'] if isinstance(b, dict) and b.get('formButtonId') else b.get('id')}
        for b in (fn.get('dyFunctionButtonVoList') or [])]
    body['menuColumnDtoList'] = cols
    body['customJs'] = CUSTOM_JS % sel

    n_vis = sum(1 for c in cols if 'isHidden' not in c['fieldAttribute'])
    n_hid = len(cols) - n_vis
    print('%s: 可见 %d + 隐藏 %d' % (key, n_vis, n_hid))
    if not apply:
        return
    st, r = prp.req('PUT', '/dynamic/function', body)
    print('  PUT ->', st, r.get('code'), str(r.get('msg'))[:60])
    st, chk = prp.get('/dynamic/function/' + fn['code'])
    mc = (chk['data'] or {}).get('menuColumnDtoList') or []
    cj = (chk['data'] or {}).get('customJs') or ''
    print('  回读列数=%d customJs着色=%s' % (len(mc), 'color:orange' in cj))


def main():
    apply = '--apply' in sys.argv
    for key in TABLES:
        do_one(key, apply)


if __name__ == '__main__':
    main()
