# -*- coding: utf-8 -*-
"""修 TS_tsd：主表签认控件残留 isInSubForm=true -> SUB_TABLE_PARAM_NOT_EXIST
   1) 清 isInSubForm  2) 重建 dyFormFieldAddList(全量)  3) PUT /dynamic/form/attribute  4) 验证 detail
"""
import json, time, os, urllib.request, urllib.error

BASE = 'http://172.19.18.223:1103/apis'
TK = '132db4a6753b251914ab1670685af914'
FORM_ID = 'bba965a26c6c37bcfbed76e99bf0a2fe'
FUNC = '125327872804d19370041a3fce329767'
CODE = 'TS_tsd'
SUB_TABLE = 'tts_tsdgl_files'
MASTER = 'tts_tsdgl'

def req(method, path, body=None):
    data = json.dumps(body, ensure_ascii=False).encode() if body is not None else None
    r = urllib.request.Request(BASE + path, data=data, method=method)
    r.add_header('Authorization', 'Bearer ' + TK)
    r.add_header('Content-Type', 'application/json')
    r.add_header('accesstype', '1')
    try:
        return urllib.request.urlopen(r, timeout=120).status, json.loads(urllib.request.urlopen(
            urllib.request.Request(BASE + path, data=data, method=method),
            timeout=120).read().decode() or '{}')
    except urllib.error.HTTPError as e:
        txt = e.read().decode('utf-8', 'replace')
        try: return e.code, json.loads(txt)
        except Exception: return e.code, txt
    except Exception as e:
        return 0, str(e)

def req1(method, path, body=None):
    data = json.dumps(body, ensure_ascii=False).encode() if body is not None else None
    r = urllib.request.Request(BASE + path, data=data, method=method)
    r.add_header('Authorization', 'Bearer ' + TK)
    r.add_header('Content-Type', 'application/json')
    r.add_header('accesstype', '1')
    try:
        with urllib.request.urlopen(r, timeout=180) as resp:
            txt = resp.read().decode('utf-8', 'replace')
            return resp.status, (json.loads(txt) if txt.strip().startswith('{') else txt)
    except urllib.error.HTTPError as e:
        txt = e.read().decode('utf-8', 'replace')
        try: return e.code, json.loads(txt)
        except Exception: return e.code, txt
    except Exception as e:
        return 0, str(e)

# ---------- 1. 取表单 ----------
st, r = req1('GET', '/dynamic/form/' + FORM_ID)
if st != 200 or r.get('code') != 200:
    raise SystemExit('取表单失败 %s %s' % (st, str(r)[:300]))
form = r['data']
os.makedirs('backup', exist_ok=True)
open('backup/tsd_form_before_%s.json' % time.strftime('%m%d_%H%M%S'), 'w', encoding='utf-8').write(
    json.dumps(form, ensure_ascii=False, indent=1))
print('表单:', form.get('name'), '| formAttributeJson', len(form.get('formAttributeJson') or ''))

faj = json.loads(form['formAttributeJson'])

# ---------- 2. 清主表控件的 isInSubForm ----------
fixed = []

def fix(n, in_sub=False):
    if not isinstance(n, dict):
        return
    if n.get('type') == 'subtable':
        in_sub = True          # subtable 内部才是真子表
    p = n.get('props')
    if isinstance(p, dict) and p.get('isInSubForm') and not in_sub:
        tbl = p.get('dataTable')
        fixed.append((n.get('id'), n.get('type'), p.get('dataField'), tbl))
        p['isInSubForm'] = False
        p.pop('parent', None) if p.get('parent') else None
    for c in n.get('children') or []:
        # 进入 subtable 子树后不再复位
        fix(c, in_sub if n.get('type') == 'subtable' else in_sub)

fix(faj)
print('\n清掉 isInSubForm 的控件 %d 个:' % len(fixed))
for x in fixed:
    print('   %-30s %-8s %-14s table=%s' % x)

if not fixed:
    print('没有需要修的（可能已修过）')

# ---------- 3. 重建 addList ----------
flat = []
def walk(ns):
    for n in ns or []:
        p = n.get('props') or {}
        if p.get('dataField'):
            flat.append(n)
        walk(n.get('children'))
walk(faj['children'])

def jstr(o):
    return json.dumps({k: v for k, v in o.items() if v is not None},
                      ensure_ascii=False, separators=(',', ':'))

P = [n for n in flat if (n.get('props') or {}).get('dataField')]
T = [n for n in P if (n.get('props') or {}).get('dataNameField')]
add_list = []
for n in P:
    p = n['props']
    ext = {'precision': p.get('precision'), 'thousandth': p.get('thousandth'),
           'dateFormat': p.get('format'), 'dateType': p.get('type'),
           'orgMode': p.get('orgMode'), 'multiple': p.get('multiple'),
           'valueRange': p.get('valueRange'), 'currentOrg': p.get('currentOrg'),
           'dictionaryType': p.get('dictionaryType'),
           'dataSourceType': p.get('dataSourceType'), 'type': n.get('type'),
           'datePattern': p.get('format')}
    add_list.append({'title': p.get('label'), 'bindingTable': p.get('dataTable'),
                     'bindingField': p.get('dataField'), 'code': p.get('dataBind'),
                     'subForm': bool(p.get('isInSubForm')),
                     'subFormCode': p.get('parent') if p.get('isInSubForm') else None,
                     'virtualField': bool(p.get('virtualField')),
                     'virtualBindingTable': p.get('virtualBindingTable'),
                     'virtualBindingField': p.get('virtualBindingField'),
                     'datePattern': p.get('format'),
                     'extendAttribute': jstr(ext)})
for n in T:
    p = n['props']
    add_list.append({'title': str(p.get('label') or '') + 'Name',
                     'bindingTable': p.get('dataTable'),
                     'bindingField': p.get('dataNameField'),
                     'code': str(p.get('dataBind')) + 'Name',
                     'subForm': bool(p.get('isInSubForm')),
                     'subFormCode': p.get('parent') if p.get('isInSubForm') else None,
                     'virtualField': False,
                     'virtualBindingTable': p.get('virtualBindingTable'),
                     'virtualBindingField': p.get('virtualBindingField'),
                     'datePattern': p.get('format'),
                     'extendAttribute': jstr({'isNameFields': True, 'precision': p.get('precision'),
                                              'thousandth': p.get('thousandth'),
                                              'dateFormat': p.get('format'), 'dateType': p.get('type'),
                                              'orgMode': p.get('orgMode'), 'multiple': p.get('multiple'),
                                              'valueRange': p.get('valueRange'),
                                              'currentOrg': p.get('currentOrg'),
                                              'dictionaryType': p.get('dictionaryType')})})
print('\naddList=%d 条, 其中 subForm=True %d 条' % (len(add_list), sum(1 for x in add_list if x['subForm'])))
for x in add_list:
    if x['subForm']:
        print('   sub %-30s %-16s %s' % (x['code'], x['bindingTable'], x['bindingField']))

# ---------- 4. PUT ----------
form['formAttributeJson'] = json.dumps(faj, ensure_ascii=False, separators=(',', ':'))
form['dyFormFieldAddList'] = add_list
form['dyFormFieldVos'] = []
st, r = req1('PUT', '/dynamic/form/attribute', form)
print('\nPUT /dynamic/form/attribute ->', st, str(r)[:300] if not isinstance(r, dict) else
      'code=%s msg=%s' % (r.get('code'), str(r.get('msg') or r.get('message'))[:200]))

# ---------- 5. 验证 ----------
st, r = req1('GET', '/dynamic/form/attribute/' + FORM_ID)
fv = (r.get('data') or {}).get('dyFormFieldVos') or []
print('\n重建后 dyFormFieldVos=%d 条' % len(fv))
bad = [f for f in fv if f.get('subForm')]
print('subForm=True:', [(f['code'], f['bindingTable'], f['bindingField']) for f in bad])

body = {'currentPage': 1, 'pageSize': 5, 'conditionDtoList': [], 'searchList': [],
        'userId': '1023f2f07eb790966dce67621f0f889c', 'myToDo': False,
        'multipleBindingFunctionId': FUNC, 'sortFieldList': None, 'totalFieldCodeList': []}
st, r = req1('POST', '/dynamic/form/scheme/data/page/' + CODE, body)
recs = (r.get('data') or {}).get('records') or []
ids = [i['value'] for x in recs for i in (x.get('mapList') or []) if i.get('field') == 'id' and i.get('value')]
print('\n记录数', len(ids))
for did in ids[:3]:
    st, d = req1('GET', '/dynamic/form/scheme/data/%s/%s' % (FUNC, did))
    print('  detail %s ->' % did[:8], (d.get('code') if isinstance(d, dict) else d),
          str(d.get('msg'))[:120] if isinstance(d, dict) else '')
