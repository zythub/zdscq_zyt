# -*- coding: utf-8 -*-
"""探测表单信息 → 生成 tables.json（build_flows.py 的输入）

用法: python detect_forms.py TS_gcdb TS_dbzc ...
输出 tables.json：
  { "TS_gcdb": {"code":"TS_gcdb","form":"<formId>","table":"<主表>","bh":"<编号字段>","name":"..."}, ... }

探测逻辑：
  功能 code → GET /dynamic/function/{code} → formId
  → GET /dynamic/form/attribute/{formId} → mainTable、formAttributeJson
  → 编号字段：注册表里 bindingField 叫 bh/number/code/no 的第一个（拿不准会在输出里标 [确认]）
"""
import json, os, sys, time
import prp

DIR = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(DIR, 'tables.json')


def main():
    codes = sys.argv[1:]
    if not codes:
        print('用法: python detect_forms.py TS_gcdb TS_dbzc ...')
        sys.exit(1)
    out = {}
    for code in codes:
        st, r = prp.get('/dynamic/function/' + code)
        fn = r.get('data') or {}
        fid = fn.get('formId')
        if not fid:
            print('!! 功能不存在:', code)
            continue
        d = None
        for _ in range(5):
            st, r2 = prp.get('/dynamic/form/attribute/' + fid)
            if st == 200 and r2.get('data'):
                d = r2['data']
                break
            time.sleep(1)
        table = d.get('mainTable')
        # 编号字段候选：从注册表找
        for _ in range(4):
            st, r3 = prp.get('/dynamic/form/field/' + fid)
            fields = r3.get('data') or []
            if fields:
                break
            time.sleep(1)
        bh, mark = None, ' [确认]'
        for x in fields:
            bf = x.get('bindingField') or ''
            if bf in ('bh', 'number', 'code', 'no') and not x.get('subForm') \
                    and x.get('bindingTable') == table:
                bh = bf
                mark = ''
                break
        out[code] = {'code': code, 'form': fid, 'table': table,
                     'bh': bh or '(填编号字段)', 'name': fn.get('name') or ''}
        print('%-10s form=%s table=%-16s bh=%s%s' % (code, fid[:10] + '…', table, bh, mark))
    # 合并已有文件（保留人工改过的行）
    old = {}
    if os.path.exists(OUT):
        old = json.load(open(OUT, encoding='utf-8'))
        for k, v in out.items():
            if k in old and old[k].get('bh') and not old[k]['bh'].startswith('('):
                v['bh'] = old[k]['bh']   # 人工确认过的不覆盖
    json.dump(out, open(OUT, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print('\n→', OUT, '（bh 带 [确认] 的请人工改一下再跑 build_flows.py）')


if __name__ == '__main__':
    main()
