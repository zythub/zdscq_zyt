# -*- coding: utf-8 -*-
"""
确定性自动排版（v4）：默认从左到右，超过 6 个折行；必要时用从上到下。

规范：
  1. 分层：从"开始"沿正向边做最长路径分层，回边不参与分层。
  2. 层内排序：重心法，初始顺序沿用 H5 的 y/x，保留设计者原本次序。
  3. 尺寸：任务节点 90x60，**开始/结束 36x36**（不放大，居中放在格子里）。
  4. 每 6 层折一行（LR）或折一列（TB），折返方向交替，使两行之间的连线最短。
  5. 同一层内的节点沿垂直方向居中排布，整体尽量接近正方形。
"""
import os
import sys

TASK_W, TASK_H = 90.0, 60.0
EVENT_W, EVENT_H = 36.0, 36.0

HGAP = 56.0          # 同层相邻节点的间隔
VGAP = 44.0          # 层间间隔
BAND_GAP = 56.0      # 折行时两行之间的间隔
MARGIN = 40.0
MAX_PER_BAND = 6     # 一行最多放几层
MAX_PER_BAND_TB = 13 # 竖排时一列最多放几层（基本等于不折列）

LANE_BASE = 34.0     # 回边走外侧通道的距离


# ------------------------------------------------------------------ graph
def _adj(nodes, edges):
    succ, pred = {}, {}
    for s, t in edges:
        succ.setdefault(s, []).append(t)
        pred.setdefault(t, []).append(s)
    return succ, pred


def find_back_edges(nodes, edges, order_key=None):
    succ, _ = _adj(nodes, edges)
    keys = order_key or {}
    color, back = {}, set()
    for root in sorted(nodes, key=lambda n: keys.get(n, (0, 0, 0))):
        if color.get(root):
            continue
        color[root] = 1
        stack = [(root, iter(succ.get(root, [])))]
        while stack:
            n, it = stack[-1]
            pushed = False
            for m in it:
                c = color.get(m, 0)
                if c == 1:
                    back.add((n, m))
                elif c == 0:
                    color[m] = 1
                    stack.append((m, iter(succ.get(m, []))))
                    pushed = True
                    break
            if not pushed:
                color[n] = 2
                stack.pop()
    return back


def compute_ranks(nodes, edges, back):
    succ, _ = _adj(nodes, edges)
    fwd = [e for e in edges if e not in back]
    indeg = {n: 0 for n in nodes}
    for s, t in fwd:
        indeg[t] += 1
    rank = {n: 0 for n in nodes}
    q = [n for n in nodes if indeg[n] == 0]
    order = []
    while q:
        n = q.pop()
        order.append(n)
        for m in succ.get(n, []):
            if (n, m) in back:
                continue
            indeg[m] -= 1
            if indeg[m] == 0:
                q.append(m)
    for n in order:
        for m in succ.get(n, []):
            if (n, m) in back:
                continue
            rank[m] = max(rank[m], rank[n] + 1)
    return rank


def order_layers(nodes, edges, rank, seed=None, iterations=6):
    _, pred = _adj(nodes, edges)
    succ, _ = _adj(nodes, edges)
    layers = {}
    for n in nodes:
        layers.setdefault(rank[n], []).append(n)
    seed = seed or {}
    for r in layers:
        layers[r].sort(key=lambda n: seed.get(n, (0, 0, 0)))
    pos = {}
    for r in layers:
        for i, n in enumerate(layers[r]):
            pos[n] = i
    rs = sorted(layers)

    def refresh():
        for r in rs:
            for i, n in enumerate(layers[r]):
                pos[n] = i

    for _ in range(iterations):
        for r in rs[1:]:
            def bc(n, r=r):
                ps = [pos[p] for p in pred.get(n, []) if rank[p] < r]
                return (sum(ps) / len(ps)) if ps else pos[n]
            layers[r].sort(key=bc)
            refresh()
        for r in reversed(rs[:-1]):
            def bc2(n, r=r):
                ss = [pos[m] for m in succ.get(n, []) if rank[m] > r]
                return (sum(ss) / len(ss)) if ss else pos[n]
            layers[r].sort(key=bc2)
            refresh()
    return layers


def _sizes(h5):
    out = {}
    for n, v in (h5.get("nodes") or {}).items():
        at = str(v.get("ActivityType"))
        out[n] = (EVENT_W, EVENT_H) if at in ("7", "8") else (TASK_W, TASK_H)
    return out


SNAKE = True         # True=折行后反向走（蛇形，行尾直接落下一行行尾，不长线横跨）


def _bands(rs, max_per=None):
    """把层号切成若干"带"；返回 {层号: (band, 段内序号, 是否反向)}。

    带的层数**平均分配**，而不是"每满 max_per 就切一刀"——
    否则 7 层会被切成 6+1，末尾那一层单独占一条带，图和连线都会甩出去。
    例：7 层 → 4+3，13 层 → 5+4+4，14 层 → 5+5+4。
    """
    max_per = max_per or MAX_PER_BAND
    L = len(rs)
    nb = max(1, -(-L // max_per))          # ceil(L / max_per)
    base, extra = divmod(L, nb)
    info, idx = {}, 0
    for b in range(nb):
        for k in range(base + (1 if b < extra else 0)):
            info[rs[idx]] = (b, k, SNAKE and b % 2 == 1)
            idx += 1
    return info


def compute_layout(h5, start, end, mode="LR"):
    """mode: 'LR' 从左到右折行；'TB' 从上到下折列。"""
    nv = h5.get("nodes") or {}
    nodes = list(nv.keys())
    edges = []
    for ev in (h5.get("edges") or {}).values():
        s = (ev.get("source") or {}).get("id")
        t = (ev.get("target") or {}).get("id")
        if s in nodes and t in nodes:
            edges.append((s, t))

    keys = {n: (0 if n == start else 1, float(nv[n].get("y") or 0), float(nv[n].get("x") or 0))
            for n in nodes}
    back = find_back_edges(nodes, edges, keys)
    rank = compute_ranks(nodes, edges, back)
    if end in rank:
        top = max(rank[n] for n in nodes if n != end)
        rank[end] = max(rank[end], top)
    layers = order_layers(nodes, edges, rank, seed=keys)

    sizes = _sizes(h5)

    rs = sorted(layers)
    # TB 模式下"带"是竖着并排的一列，折列会让流程从底部跳回顶部，很别扭；
    # 只有层数特别多（>12）才折列，否则一列走到底。
    binfo = _bands(rs, MAX_PER_BAND_TB if mode == "TB" else MAX_PER_BAND)

    # "没有前置节点、只指向某一个节点"的节点（典型是「起草人修改」「起草人」）：
    # 不要和开始挤在同一列，改成放到它指向的那个节点的**正上方**。
    pred = {}
    for a, b in edges:
        pred.setdefault(b, []).append(a)
    floaters = {}
    if mode == "LR":      # 从上到下时，层内横向堆叠本身就已经把它放在上一行了
        for n in nodes:
            if n == start or pred.get(n):
                continue
            tg = [m for m in (b for a, b in edges if a == n)
                  if rank.get(m, 0) > rank.get(n, 0) and binfo[rank[m]][0] == 0]
            if len(tg) == 1:          # 只指向一个目标、且目标在第一行，才搬到它正上方
                floaters[n] = tg[0]
    for n in floaters:
        layers[rank[n]] = [m for m in layers[rank[n]] if m != n]

    # 每条带的"厚度"= 该带内最多节点数
    band_count = binfo[rs[-1]][0] + 1
    band_thick = [0] * band_count      # 该带内最多节点数（决定带有多厚）
    band_n = [0] * band_count          # 该带内有几层（折返时用来算反向列号）
    for r in rs:
        b = binfo[r][0]
        band_thick[b] = max(band_thick[b], len(layers[r]))
        band_n[b] += 1

    rects = {}
    if mode == "LR":
        # 层沿 x 推进，层内节点沿 y 堆叠；带沿 y 堆叠
        col_pitch = TASK_W + HGAP
        row_pitch = TASK_H + VGAP
        offsets = []
        acc = MARGIN
        for b in range(band_count):
            offsets.append(acc)
            acc += band_thick[b] * row_pitch + BAND_GAP
        for r in rs:
            b, pos, rev = binfo[r]
            col = (band_n[b] - 1 - pos) if rev else pos
            ns = layers[r]
            m = band_thick[b]
            pad = (m - len(ns)) * row_pitch / 2.0
            for i, n in enumerate(ns):
                w, h = sizes[n]
                cx = MARGIN + col * col_pitch + (TASK_W - w) / 2.0
                cy = offsets[b] + pad + i * row_pitch + (TASK_H - h) / 2.0
                rects[n] = (round(cx, 1), round(cy, 1), w, h)
    else:
        # 层沿 y 推进，层内节点沿 x 堆叠；带沿 x 堆叠
        row_pitch = TASK_H + VGAP
        col_pitch = TASK_W + HGAP
        offsets = []
        acc = MARGIN
        for b in range(band_count):
            offsets.append(acc)
            acc += band_thick[b] * col_pitch + BAND_GAP
        for r in rs:
            b, pos, rev = binfo[r]
            row = (band_n[b] - 1 - pos) if rev else pos
            ns = layers[r]
            m = band_thick[b]
            pad = (m - len(ns)) * col_pitch / 2.0
            for i, n in enumerate(ns):
                w, h = sizes[n]
                cx = offsets[b] + pad + i * col_pitch + (TASK_W - w) / 2.0
                cy = MARGIN + row * row_pitch + (TASK_H - h) / 2.0
                rects[n] = (round(cx, 1), round(cy, 1), w, h)

    # 浮动节点放到目标正上方一行，再把整张图往下推，保证不出现负坐标
    pitch = (TASK_H + VGAP) if mode == "LR" else (TASK_H + VGAP)
    top = {}
    for n, t in floaters.items():
        if t not in rects:
            continue
        w, h = sizes[n]
        tx, ty, tw, th = rects[t]
        top[n] = (round(tx + (tw - w) / 2.0, 1), round(ty - pitch + (th - h) / 2.0, 1), w, h)
    if top:
        drop = MARGIN - min(v[1] for v in top.values())
        if drop > 0:
            rects = {k: (v[0], round(v[1] + drop, 1), v[2], v[3]) for k, v in rects.items()}
            top = {k: (v[0], round(v[1] + drop, 1), v[2], v[3]) for k, v in top.items()}
        rects.update(top)

    bands = {n: binfo[rank[n]][0] for n in nodes}
    return rects, rank, back, edges, bands


def bbox(rects):
    if not rects:
        return 0.0, 0.0
    w = max(r[0] + r[2] for r in rects.values()) - min(r[0] for r in rects.values())
    h = max(r[1] + r[3] for r in rects.values()) - min(r[1] for r in rects.values())
    return w, h


def pick_mode(h5, start, end, max_height=780.0):
    """默认从左到右折行；只有当"一竖太高"（超过一屏）且换成从上到下明显更矮时，
    才改用从上到下。这样简单流程是一条横条，复杂的才不会变成一根长竖条。"""
    r_lr, rank, back, edges, bands = compute_layout(h5, start, end, "LR")
    w1, h1 = bbox(r_lr)
    if h1 <= max_height:
        return "LR", r_lr, rank, back, edges, bands
    r_tb, _, _, _, b_tb = compute_layout(h5, start, end, "TB")
    w2, h2 = bbox(r_tb)
    if h2 < h1 * 0.85:
        return "TB", r_tb, rank, back, edges, b_tb
    return "LR", r_lr, rank, back, edges, bands
