# -*- coding: utf-8 -*-
"""补齐/修正「表单发布」必勾字段（固定口径，不靠猜）

必勾字段（勾选，且除流程业务状态外一律隐藏）：
  主键ID id / 单位代码 company_code / 流程编号 flow_id / 流程实例ID flow_instance_id /
  流程状态 flow_startflag / 流程业务状态 flow_bizstate（可见，列表「流程状态」列）

另外隐藏：签章文件id fdd_dzqz_file_id / office 人员 id 列

用法: python fix_must_columns.py [--apply]
"""
import json, os, sys, uuid
from urllib.parse import quote, unquote
import prp

DIR = os.path.dirname(os.path.abspath(__file__))

MUST_HIDDEN = ['id', 'company_code', 'flow_id', 'flow_instance_id', 'flow_startflag']
MUST_VISIBLE = ['flow_bizstate']          # 流程业务状态：列表「流程状态」列，可见
EXTRA_HIDDEN = ['fdd_dzqz_file_id']

CODES = ['TS_dtts', 'TS_gcdb', 'TS_dbzc', 'TS_ydgl', 'TS_tsd', 'TS_qxgl', 'TS_ztts']


def build_col(code, meta, old, menu_id, hidden, sort=None, alias=None):
    e = {
        'id': (old or {}).get('id') or uuid.uuid4().hex,
        'menuId': menu_id,
        'code': code,
        'name': alias or meta.get('title'),
        'description': meta.get('title'),
        'sort': sort,
        'status': True,
        'formFieldId': code,
        'supportQuery': (old or {}).get('supportQuery') or False,
        'mobileSupportQuery': None,
        'dictCategoryNumber': None,
        'subForm': bool(meta.get('subForm')),
        'subFormCode': meta.get('subFormCode'),
        'title': meta.get('title'),
        'bindingTable': meta.get('bindingTable'),
        'bindingField': meta.get('bindingField'),
        'virtualField': bool(meta.get('virtualField')),
        'virtualBindingTable': meta.get('virtualBindingTable') or '',
        'virtualBindingField': meta.get('virtualBindingField') or '',
        'attributeJson': None,
        'datePattern': meta.get('datePattern'),
        'extendAttribute': meta.get('extendAttribute'),
        'viewStatus': None,
        'updateStatus': None,
        'headerQuery': False,
    }
    if alias:
        e['name'] = alias
        e['fieldAlias'] = alias
    attr = dict(e)
    if hidden:
        attr['isHidden'] = True
    e['fieldAttribute'] = quote(json.dumps(attr, ensure_ascii=False), safe='')
    return e


def fix_one(code, apply):
    st, r = prp.get('/dynamic/function/' + code)
    fn = r.get('data') or {}
    if not fn:
        print(code, '!! 功能不存在')
        return
    menu_id = fn['menuId']
    cols = fn.get('menuColumnDtoList') or []

    # 注册表
    fid = fn['formId']
    for _ in range(4):
        st, r2 = prp.get('/dynamic/form/field/' + fid)
        meta = {x['code']: x for x in (r2.get('data') or [])}
        if meta:
            break
    by_field = {}
    for c in meta.values():
        if not c.get('subForm'):
            by_field.setdefault(c.get('bindingField'), c)

    changed = []
    # 1) 已有列：按 bindingField 校正 isHidden
    for c in cols:
        try:
            attr = json.loads(unquote(c.get('fieldAttribute') or '{}'))
        except Exception:
            attr = {}
        bf = attr.get('bindingField') or c.get('bindingField')
        if bf in MUST_HIDDEN or bf in EXTRA_HIDDEN:
            want_hidden = True
        elif bf in MUST_VISIBLE:
            want_hidden = False
        elif (attr.get('code') or '').startswith('office') and not (attr.get('code') or '').endswith('Name'):
            want_hidden = True
        else:
            continue
        cur = bool(attr.get('isHidden'))
        if cur != want_hidden:
            if want_hidden:
                attr['isHidden'] = True
            else:
                attr.pop('isHidden', None)
            c['fieldAttribute'] = quote(json.dumps(attr, ensure_ascii=False), safe='')
            changed.append('%s %s→%s' % (bf, '隐藏' if cur else '显示', '隐藏' if want_hidden else '显示'))

    # 2) 缺的必勾列补上
    present = set()
    for c in cols:
        try:
            a = json.loads(unquote(c.get('fieldAttribute') or '{}'))
        except Exception:
            a = {}
        present.add(a.get('bindingField') or c.get('bindingField'))
    for bf in MUST_HIDDEN + EXTRA_HIDDEN:
        if bf in present or bf not in by_field:
            continue
        cols.append(build_col(by_field[bf]['code'], by_field[bf], None, menu_id, True))
        changed.append('补列 %s(%s)' % (bf, by_field[bf]['title']))
    for bf in MUST_VISIBLE:
        if bf in present or bf not in by_field:
            continue
        cols.append(build_col(by_field[bf]['code'], by_field[bf], None, menu_id, False,
                              sort=1, alias='流程状态'))
        changed.append('补列 %s(流程状态,可见)' % bf)

    print('%-8s 列数=%-3d 修正 %d 项: %s' % (code, len(cols), len(changed), '; '.join(changed) or '无需改'))
    if not changed or not apply:
        return
    body = {k: fn.get(k) for k in ('id', 'type', 'menuTypeList', 'path', 'menuId', 'menuSort',
                                   'parentMenuId', 'code', 'name', 'pushStatus', 'functionConfig',
                                   'formId')}
    body['dyFunctionButtonAddDtoList'] = [
        {'functionId': fn['id'],
         'formButtonId': b['formButtonId'] if isinstance(b, dict) and b.get('formButtonId') else b.get('id')}
        for b in (fn.get('dyFunctionButtonVoList') or [])]
    body['menuColumnDtoList'] = cols
    body['customJs'] = fn.get('customJs')
    st, r = prp.req('PUT', '/dynamic/function', body)
    print('   PUT ->', st, r.get('code'), str(r.get('msg'))[:60])


def main():
    apply = '--apply' in sys.argv
    for code in CODES:
        fix_one(code, apply)


if __name__ == '__main__':
    main()
