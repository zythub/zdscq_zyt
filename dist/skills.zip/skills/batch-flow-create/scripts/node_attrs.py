# -*- coding: utf-8 -*-
"""节点属性（nodeAttrs）补齐 + 全量校验。

要解决的三件事（2026-11-03 实测）：
  1. 发布报「流程模型节点[xxx]基础属性未填写！节点ID：[Activity_p12]」
     -> 模板 entity.xml 的 nodeAttrs 只有 p1..p11，多出来的 userTask 没有记录
  2. 设计器右上角不显示节点 ID
     -> nodeAttrs 缺 8 个表单字段（nodeFormId/nodeFormType/phoneNodeFormId/
        phoneNodeFormType/childField/childTable/parentField/messageType）
  3. 节点没有审批人 / 没有节点表单
     -> nodeUsers、nodeForms 覆盖不全

平台**没有**可用的「新建节点属性」接口
（PUT /workflow/design-node-attribute/addAndEdit 对不存在的记录直接
 NullPointerException），所以只能**从线上导出 -> 改包 -> importModel 原地覆盖**。

用法：
  python scripts/node_attrs.py --list              # 列出全部模型
  python scripts/node_attrs.py --check --model PRP_CGLX
  python scripts/node_attrs.py --check --all
  python scripts/node_attrs.py --apply --model PRP_CGLX --form <formId>
  python scripts/node_attrs.py --apply --all --form <formId>
"""
import argparse
import os
import re
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import prp_env as E          # noqa: E402

TS = 1793584566711

NEED = ("nodeFormId", "nodeFormType", "phoneNodeFormId", "phoneNodeFormType",
        "childField", "childTable", "parentField", "messageType")

# nodeAttrs 条目模板（8 个表单字段齐全）
TPL = """     <object class="com.best.flow.domain.WfDesignNodeAttribute">
      <void property="autoAgree"><string>0</string></void>
      <void property="childField"><string></string></void>
      <void property="childTable"><string></string></void>
      <void property="createBy"><string></string></void>
      <void property="delFlag"><string>0</string></void>
      <void property="doCopy"><string>0</string></void>
      <void property="messageType"><string></string></void>
      <void property="modelId"><string>%(modelId)s</string></void>
      <void property="nodeFormId"><string>%(formId)s</string></void>
      <void property="nodeFormType"><string>0</string></void>
      <void property="nodeId"><string>%(nodeId)s</string></void>
      <void property="nodeKey"><string>%(nodeKey)s</string></void>
      <void property="nodeMustOpinion"><string>0</string></void>
      <void property="nodeName"><string><![CDATA[%(nodeName)s]]></string></void>
      <void property="nodeType"><string>userTask</string></void>
      <void property="nodeUserSingle"><string>0</string></void>
      <void property="openRevoke"><string>1</string></void>
      <void property="parentField"><string></string></void>
      <void property="phoneNodeFormId"><string>%(formId)s</string></void>
      <void property="phoneNodeFormType"><string>0</string></void>
      <void property="selectUserSingleton"><string>0</string></void>
      <void property="submitMustUser"><string>0</string></void>
      <void property="taskInstName"><string>["${InstNameKey}"]</string></void>
      <void property="updateBy"><string></string></void>
     </object>
"""

# nodeForms 条目（formSourceType=2）
FORM_TPL = """<void method="add">
     <object class="com.best.flow.domain.WfDesignNodeForm">
      <void property="createBy"><string></string></void>
      <void property="createTime">
       <object class="java.util.Date"><long>%(ts)s</long></object>
      </void>
      <void property="delFlag"><string>0</string></void>
      <void property="formId"><string>%(formId)s</string></void>
      <void property="formSourceType"><string>2</string></void>
      <void property="modelId"><string>%(modelId)s</string></void>
      <void property="nodeId"><string>%(nodeId)s</string></void>
      <void property="updateBy"><string></string></void>
      <void property="updateTime">
       <object class="java.util.Date"><long>%(ts)s</long></object>
      </void>
      <void property="wfDesignNodeFormauthList">
       <object class="java.util.ArrayList"/>
      </void>
     </object>
    </void>
   """


# ------------------------------------------------------------------ 解析
def user_tasks(xml):
    """[(id, name)]，保持 XML 顺序。"""
    out = []
    for m in re.finditer(r"<userTask([^>]*)>", xml):
        a = m.group(1)
        i = re.search(r'id="([^"]+)"', a)
        n = re.search(r'name="([^"]*)"', a)
        if i:
            out.append((i.group(1), n.group(1) if n else i.group(1)))
    return out


def _block_end(s, start):
    """从 start 处的 <object> 起，按 <object/</object> 计数找配对的 </object>。"""
    m = re.match(r"<object\b[^>]*/>", s[start:])
    if m:
        return start + m.end()
    depth = 0
    for m in re.finditer(r"<object\b[^>]*/>|<object\b|</object>", s[start:]):
        tok = m.group(0)
        if tok.endswith("/>"):
            continue
        if tok.startswith("</"):
            depth -= 1
            if depth == 0:
                return start + m.end()
        else:
            depth += 1
    raise ValueError("块不闭合")


def _entries(entity, prop, cls):
    """某 ArrayList 属性下所有条目 -> (p, q, [(nodeId, seg)])"""
    p = entity.find('<void property="%s">' % prop)
    if p < 0:
        return None, None, []
    o = entity.find("<object", p)
    q = _block_end(entity, o)
    block = entity[p:q]
    out = []
    head = '<void method="add">'
    i = block.find(head)
    while i >= 0:
        o2 = block.find("<object", i)
        e2 = _block_end(block, o2)
        seg = block[i:e2]
        if not cls or cls in seg:
            m = re.search(r'property="nodeId">\s*<string>([^<]+)</string>', seg)
            out.append((m.group(1) if m else None, seg))
        i = block.find(head, e2)
    return p, q, out


def _insert(entity, prop, chunks):
    """把若干 <void method="add"> 块插到该 ArrayList 结束标签之前。"""
    p, q, _ = _entries(entity, prop, "")
    if p is None:
        return entity
    end = entity.rfind("</object>", p, q)
    if end < 0:
        m = re.search(r'(<void property="%s">\s*)<object class="java\.util\.ArrayList"\s*/>' % prop,
                      entity[p:q])
        if not m:
            raise ValueError("%s 块结构异常" % prop)
        a, b = p + m.end(1), p + m.end()
        return entity[:a] + '\n   <object class="java.util.ArrayList">\n   ' + "".join(chunks) \
               + '\n   </object>\n  ' + entity[b:]
    return entity[:end] + "   " + "".join(chunks) + entity[end:]


def _apply_edits(entity, edits):
    """按位置降序回写，避免下标漂移（★ 这是批量改 entity 最容易踩的坑）。"""
    for a, b, new in sorted(edits, key=lambda e: e[0], reverse=True):
        entity = entity[:a] + new + entity[b:]
    return entity


def _prop(seg, prop):
    m = re.search(r'property="%s">\s*<string>([^<]*)</string>' % prop, seg)
    return m.group(1) if m else None


def _set_prop(seg, prop, val):
    pat = r'(property="%s">\s*<string>)[^<]*(</string>)' % prop
    if not re.search(pat, seg):
        return seg, False
    new = re.sub(pat, lambda m: m.group(1) + val + m.group(2), seg)
    return new, new != seg


# ------------------------------------------------------------------ 修复
def fix(entity, xml, form_id=None):
    """补齐节点属性。form_id 为空表示不绑表单（节点表单字段写空串）。
    返回 (新 entity, [改动说明])。"""
    tasks = user_tasks(xml)
    names = dict(tasks)
    log = []
    explicit_form = form_id
    node_form = form_id if form_id is not None else ""

    # 1. 纠正 nodeName（按 BPMN XML 真名）
    p, q, spans = _entries(entity, "nodeAttrs", "WfDesignNodeAttribute")
    edits = []
    for nid, seg in spans:
        if nid not in names:
            continue
        m = re.search(r'property="nodeName">\s*<string><!\[CDATA\[(.*?)\]\]></string>', seg, re.S)
        if m and m.group(1) != names[nid]:
            new = seg[:m.start(1)] + names[nid] + seg[m.end(1):]
            log.append("改名 %s: %s -> %s" % (nid, m.group(1), names[nid]))
            edits.append((entity.find(seg), entity.find(seg) + len(seg), new))
    entity = _apply_edits(entity, edits)

    # 2. 补缺失的 nodeAttrs 条目
    p, q, spans = _entries(entity, "nodeAttrs", "WfDesignNodeAttribute")
    have = {s[0] for s in spans}
    if spans:
        mid = re.search(r'property="modelId">\s*<string>([^<]+)</string>', entity).group(1)
        add = []
        for nid, nname in tasks:
            if nid in have:
                continue
            log.append("补属性 %s (%s)" % (nid, nname))
            add.append('<void method="add">\n' + TPL % {"modelId": mid, "nodeId": nid,
                                                       "nodeKey": nid, "nodeName": nname,
                                                       "formId": form_id or ""}
                       + '</void>\n   ')
        if add:
            entity = _insert(entity, "nodeAttrs", add)

    # 3. 给已有条目补 8 个表单字段（只针对 userTask，连线不碰）
    p, q, spans = _entries(entity, "nodeAttrs", "WfDesignNodeAttribute")
    task_ids = {t[0] for t in tasks}
    edits = []
    for nid, seg in spans:
        if nid not in task_ids:
            continue
        new = seg
        for prop in ("nodeFormId", "phoneNodeFormId"):
            v = _prop(new, prop)
            if v is None:
                new, _ = _set_prop(new, prop, node_form)
            elif v != node_form:
                new, _ = _set_prop(new, prop, node_form)
        for prop in ("nodeFormType", "phoneNodeFormType"):
            if 'property="%s"' % prop not in new:
                new = new.replace("     </object>",
                                  '      <void property="%s"><string>0</string></void>\n     </object>' % prop, 1)
        for f in ("childField", "childTable", "parentField", "messageType"):
            if 'property="%s"' % f not in new:
                new = new.replace("     </object>",
                                  '      <void property="%s"><string></string></void>\n     </object>' % f, 1)
        if new != seg:
            log.append("补表单字段 %s" % nid)
            edits.append((entity.find(seg), entity.find(seg) + len(seg), new))
    entity = _apply_edits(entity, edits)

    # 4. nodeForms：缺时间戳的补上；显式给了表单才建条目
    p, q, forms = _entries(entity, "nodeForms", "WfDesignNodeForm")
    edits = []
    for nid, seg in forms:
        new = seg
        for prop in ("createTime", "updateTime"):
            if 'property="%s"' % prop not in new:
                new = new.replace("     </object>",
                                  '      <void property="%s"><object class="java.util.Date">'
                                  '<long>%d</long></object></void>\n     </object>' % (prop, TS), 1)
        if new != seg:
            log.append("补时间戳 %s" % nid)
            edits.append((entity.find(seg), entity.find(seg) + len(seg), new))
    entity = _apply_edits(entity, edits)

    p, q, forms = _entries(entity, "nodeForms", "WfDesignNodeForm")
    fhave = {f[0] for f in forms}
    if form_id:
        mid = re.search(r'property="modelId">\s*<string>([^<]+)</string>', entity).group(1)
        add = []
        for nid, _ in tasks:
            if nid in fhave:
                continue
            log.append("补节点表单 %s" % nid)
            add.append(FORM_TPL % {"formId": form_id, "modelId": mid, "nodeId": nid, "ts": TS})
        if add:
            entity = _insert(entity, "nodeForms", add)

    # 5. nodeUsers：补缺失的审批人占位条目（照抄第一条，只换 nodeId）
    p, q, users = _entries(entity, "nodeUsers", "WfDesignNodeUser")
    uhave = {u[0] for u in users}
    tpl = next((s for n, s in users if n), None)
    if tpl:
        add = []
        for nid, _ in tasks:
            if nid in uhave:
                continue
            seg = re.sub(r'(property="nodeId">\s*<string>)[^<]*(</string>)',
                         r'\g<1>%s\g<2>' % nid, tpl)
            log.append("补审批人 %s" % nid)
            add.append(seg + '</void>\n   ')
        if add:
            entity = _insert(entity, "nodeUsers", add)

    # 6. 起始表单（只在显式给了表单时才写）
    if explicit_form:
        for prop in ("startFormId", "phoneStartFormId"):
            entity, ch = _set_prop(entity, prop, explicit_form)
            if ch:
                log.append("%s = %s" % (prop, explicit_form))

    return entity, log


# ------------------------------------------------------------------ 校验
def check_package(entity, xml):
    """单张流程的节点配置体检。返回各类问题清单。"""
    tasks = user_tasks(xml)
    names = dict(tasks)
    p, q, spans = _entries(entity, "nodeAttrs", "WfDesignNodeAttribute")
    by_id = {n: s for n, s in spans}
    bad_attr, bad_field = [], []
    for nid, nname in tasks:
        seg = by_id.get(nid)
        if seg is None:
            bad_attr.append((nid, "缺基础属性"))
            continue
        nm = re.search(r'property="nodeName">\s*<string><!\[CDATA\[(.*?)\]\]></string>', seg, re.S)
        if nm and nm.group(1) != nname:
            bad_attr.append((nid, "nodeName %r != %r" % (nm.group(1), nname)))
        miss = [f for f in NEED if 'property="%s"' % f not in seg]
        if miss:
            bad_field.append((nid, ",".join(miss)))
    p, q, users = _entries(entity, "nodeUsers", "WfDesignNodeUser")
    uids = {n for n, _ in users}
    bad_user = [nid for nid, _ in tasks if nid not in uids]
    p, q, forms = _entries(entity, "nodeForms", "WfDesignNodeForm")
    return {"bad_attr": bad_attr, "bad_field": bad_field, "bad_user": bad_user,
            "nodeforms": len(forms), "tasks": len(tasks)}


def check_model(rec):
    blob = E.export_model(rec["modelId"])
    names, data, xn, xml, ent = E.read_package(blob)
    r = check_package(ent, xml)
    sf = re.search(r'property="startFormId">\s*<string>([^<]*)</string>', ent)
    r["startFormId"] = sf.group(1) if sf else ""
    cat = re.search(r'property="categoryId">\s*<string>([^<]+)</string>', ent)
    r["categoryId"] = cat.group(1) if cat else ""
    return r


# ------------------------------------------------------------------ 应用
def apply_one(rec, form_id=None, dry=False):
    key = rec["modelKey"]
    blob = E.export_model(rec["modelId"])
    names, data, xn, xml, ent = E.read_package(blob)
    new_ent, log = fix(ent, xml, form_id)
    if not log:
        print("  %-14s 无需改动" % key)
        return True
    if dry:
        print("  %-14s %s" % (key, "；".join(log[:6]) + ("…" if len(log) > 6 else "")))
        return True
    packed = E.rebuild_package(names, data, xn,
                               "%s#&%s#&xml.xml" % (key, E.CATEGORY), new_ent)
    ok, resp = E.import_zip(packed, key + ".zip")
    print("  %-14s %-4s %s" % (key, "OK" if ok else "!!",
                               "；".join(log[:4]) + ("…" if len(log) > 4 else "")))
    if not ok:
        print("      ", resp[:200])
    return ok


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--apply", action="store_true")
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--model", help="modelKey")
    ap.add_argument("--form", help="要绑的表单 ID")
    ap.add_argument("--dry", action="store_true")
    a = ap.parse_args()

    recs = E.models()
    if a.model:
        recs = [r for r in recs if r["modelKey"] == a.model]
    if a.list or not (a.check or a.apply):
        print("模型 %d 个" % len(recs))
        for r in recs:
            print("   %-16s %-30s %s" % (r["modelKey"], r["modelName"], r["modelId"]))
        return

    if a.check:
        tot = {"bad_attr": 0, "bad_field": 0, "bad_user": 0}
        for r in sorted(recs, key=lambda x: x["modelKey"]):
            try:
                c = check_model(r)
            except Exception as ex:
                print("  %-14s !! %s" % (r["modelKey"], ex))
                continue
            for k in tot:
                tot[k] += len(c[k])
            flag = "OK" if not (c["bad_attr"] or c["bad_field"] or c["bad_user"]) else "!!"
            print("  %-14s %-3s 任务%2d 节点表单%2d 缺属性%d 缺字段%d 缺审批人%d"
                  % (r["modelKey"], flag, c["tasks"], c["nodeforms"],
                     len(c["bad_attr"]), len(c["bad_field"]), len(c["bad_user"])))
            for x in c["bad_attr"][:3]:
                print("        缺基础属性:", x)
            for x in c["bad_field"][:3]:
                print("        缺字段:", x)
        print("\n合计：缺基础属性 %d / 字段不全 %d / 缺审批人 %d"
              % (tot["bad_attr"], tot["bad_field"], tot["bad_user"]))
        return

    # apply
    bad = 0
    for r in sorted(recs, key=lambda x: x["modelKey"]):
        try:
            if not apply_one(r, a.form, a.dry):
                bad += 1
        except Exception as ex:
            print("  %-14s !! %s" % (r["modelKey"], ex))
            bad += 1
        if not a.dry:
            time.sleep(E.IMPORT_GAP)
    print("完成，失败 %d 个" % bad)
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
