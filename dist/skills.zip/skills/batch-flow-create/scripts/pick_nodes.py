# -*- coding: utf-8 -*-
"""从表单设计提取审批节点清单 → nodes.json（build_flows.py 动态建流程的输入）

提取规则（bestdt 系统实测口径）：
  1. 候选 = 表单设计里的 office 控件（dataField 以 _id 结尾的主表选人控件）
  2. 顺序 = 控件在表单里的出现顺序（画表单即画审批流）
  3. 判定：
     - 有同名 _date 字段  → 审批节点（日期要回填）      auto=yes(date配对)
     - label 命中范围词典 → 审批节点                    auto=yes(范围)
     - 都不满足          → 排除（如「责任人」这类填写字段）auto=no
  4. nodes.json 里 auto=no / 不想要的行直接删掉或改 want=false

用法: python pick_nodes.py TS_xxx ...   （读 tables.json）
"""
import json, os, re, sys
import prp

DIR = os.path.dirname(os.path.abspath(__file__))

# 范围词典：审批节点候选的 label 关键词（用户口径：参建单位 + 建设单位部门/负责人）
SCOPE_WORDS = ['施工单位', '监理', '设计单位', '造价', '代保管',
               '工程部', '安质部', '计划部', '物资部', '建设单位']


def form_attr(form_id):
    for _ in range(5):
        st, d = prp.get('/dynamic/form/attribute/' + form_id)
        if st == 200 and d.get('data'):
            return d['data']
        time_sleep = __import__('time').sleep(1)
    raise SystemExit('attribute 拉取失败: ' + form_id)


def pick(form_id, table):
    d = form_attr(form_id)
    fa = json.loads(d['formAttributeJson'])
    dates = set()

    class W:
        seq = 0
        out = []

    def rec(n):
        if isinstance(n, dict):
            p = n.get('props') or {}
            bind = p.get('dataBind')
            if bind and not bind.endswith('Name') and not bind.startswith('subtable_') \
                    and not p.get('virtualField'):
                f = p.get('dataField')
                t = p.get('dataTable')
                if t == table and f:
                    if bind.startswith('date_'):
                        dates.add(f)
                    elif bind.startswith('office_') and f.endswith('_id'):
                        W.seq += 1
                        W.out.append({'seq': W.seq, 'field': f, 'label': p.get('label') or f,
                                      'code': bind, 'nameField': p.get('dataNameField') or None})
            for v in n.values():
                rec(v)
        elif isinstance(n, list):
            for v in n:
                rec(v)
    rec(fa)

    nodes = []
    for c in W.out:
        base = c['field'][:-3]  # 去 _id
        has_date = (base + '_date') in dates
        hit = any(w in c['label'] for w in SCOPE_WORDS)
        if has_date:
            why, want = 'date配对', True
        elif hit:
            why, want = '范围命中', True
        else:
            why, want = '不在范围且无日期', False
        nodes.append({'seq': c['seq'], 'field': c['field'], 'label': c['label'],
                      'code': c['code'], 'nameField': c['nameField'],
                      'dateField': (base + '_date') if has_date else None,
                      'auto': why, 'want': want})
    return nodes


def main():
    tables = json.load(open(os.path.join(DIR, 'tables.json'), encoding='utf-8'))
    codes = sys.argv[1:] or list(tables)
    out = {}
    for code in codes:
        cfg = tables[code]
        nodes = pick(cfg['form'], cfg['table'])
        out[code] = {'table': cfg['table'], 'nodes': nodes}
        print('== %s (%s)' % (code, cfg['table']))
        for n in nodes:
            print('  %d. %-14s %-12s date=%-12s %s → %s' % (
                n['seq'], n['label'], n['field'], n['dateField'] or '-', n['auto'],
                '生成' if n['want'] else '跳过'))
    p = os.path.join(DIR, 'nodes.json')
    old = {}
    if os.path.exists(p):
        old = json.load(open(p, encoding='utf-8'))
        for k, v in out.items():   # 保留人工改过的 want
            if k in old:
                om = {x['field']: x.get('want') for x in old[k]['nodes']}
                for n in v['nodes']:
                    if n['field'] in om:
                        n['want'] = om[n['field']]
    json.dump(out, open(p, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print('\n→', p, '（不要的节点把 want 改 false 或整行删掉）')


if __name__ == '__main__':
    main()
