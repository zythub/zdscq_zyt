# -*- coding: utf-8 -*-
"""动态生成流程模型（节点数/顺序由 nodes.json 驱动，模板 zip 只当骨架）

用法:
  python detect_forms.py TS_xxx ...            # ① 表单 → tables.json
  python pick_nodes.py  TS_xxx ...             # ② 表单设计 → nodes.json（人工删不要的节点）
  python build_flows.py --template 模板.zip     # ③ dry-run 生成模型 zip
  python build_flows.py --template 模板.zip --apply

约定：流程名称=表单名称；流程编号=表单编号(功能 code)；节点=nodes.json 里 want=true 的行
（顺序=表单设计里控件的出现顺序）。模板 BPMN 只提供骨架（attr/按钮/auth 形状），
节点全部动态生成，模板里有没有残留节点、有几个节点都无所谓。
"""
import copy, io, json, os, re, sys, time, uuid, zipfile
import xml.etree.ElementTree as ET
import prp

DIR = os.path.dirname(os.path.abspath(__file__))
OUT_DIR = os.path.join(DIR, 'tmp_models')
os.makedirs(OUT_DIR, exist_ok=True)
USER = '1023f2f07eb790966dce67621f0f889c'


# ---------- XMLDecoder 工具 ----------
def ptext(vel):
    s = vel.find('string') if vel is not None else None
    return s.text if s is not None else None


def setptext(vel, val):
    s = vel.find('string')
    if s is None:
        s = ET.SubElement(vel, 'string')
    s.text = val


def first_obj(vel):
    for c in vel:
        if c.tag == 'object':
            return c
    return None


def props(o):
    return {v.get('property'): v for v in o.findall('void')}


def date_now():
    o = ET.Element('object', {'class': 'java.util.Date'})
    ET.SubElement(o, 'long').text = str(int(time.time() * 1000))
    return o


def new_auth_row(filed_key, nf_id, view='1', edit='2', required='2', typ='0'):
    o = ET.Element('object', {'class': 'com.best.flow.domain.WfDesignNodeFormauth'})
    add = ET.Element('void', {'method': 'add'})
    add.append(o)

    def put(name, val):
        v = ET.SubElement(o, 'void', {'property': name})
        ET.SubElement(v, 'string').text = val
    put('createBy', USER)
    v = ET.SubElement(o, 'void', {'property': 'createTime'}); v.append(date_now())
    put('delFlag', '0')
    put('edit', edit)
    put('filedKey', filed_key)
    put('nodeFormId', nf_id)
    put('required', required)
    put('type', typ)
    put('updateBy', USER)
    v = ET.SubElement(o, 'void', {'property': 'updateTime'}); v.append(date_now())
    put('view', view)
    return add


# ---------- 输入 ----------
def load(path, what):
    p = os.path.join(DIR, path)
    if not os.path.exists(p):
        print('!! 缺 %s（%s）' % (path, what))
        sys.exit(1)
    return json.load(open(p, encoding='utf-8'))


def form_attr(form_id):
    for _ in range(5):
        st, d = prp.get('/dynamic/form/attribute/' + form_id)
        if st == 200 and d.get('data'):
            return d['data']
        time.sleep(1)
    raise SystemExit('attribute 拉取失败: ' + form_id)


def controls_of(form_id):
    fa = json.loads(form_attr(form_id)['formAttributeJson'])
    out = {}

    def rec(n):
        if isinstance(n, dict):
            p = n.get('props') or {}
            bind = p.get('dataBind')
            if bind and not bind.endswith('Name') and not bind.startswith('subtable_'):
                out.setdefault(p.get('dataField'), {'code': bind, 'visible': p.get('visible') is not False})
            for v in n.values():
                rec(v)
        elif isinstance(n, list):
            for v in n:
                rec(v)
    rec(fa)
    return out


def subtables_of(form_id):
    fa = json.loads(form_attr(form_id)['formAttributeJson'])
    subs = []

    def rec(n):
        if isinstance(n, dict):
            if n.get('type') == 'subtable':
                subs.append(n.get('id'))
            for v in n.values():
                rec(v)
        elif isinstance(n, list):
            for v in n:
                rec(v)
    rec(fa)
    return subs


# ---------- 骨架：从模板 zip 抽对象行 ----------
def load_skeleton(tpl_zip_path):
    z = zipfile.ZipFile(tpl_zip_path)
    entity_bytes, bpmn_text, bpmn_name = None, None, None
    for n in z.namelist():
        if n.endswith('entity.xml'):
            entity_bytes = z.read(n)
        else:
            bpmn_name, bpmn_text = n, z.read(n).decode('utf-8')
    root = ET.fromstring(entity_bytes)
    top = {v.get('property'): v for v in root.find('object').findall('void')}

    def adds(key):
        lst = first_obj(top[key])
        return [first_obj(a) for a in lst.findall('void[@method="add"]')]

    acts = [o for o in adds('nodeAttrs')
            if (ptext(props(o).get('nodeId')) or '').startswith('Activity_')]
    flows = [o for o in adds('nodeAttrs')
             if (ptext(props(o).get('nodeId')) or '').startswith('Flow_')]
    nforms = adds('nodeForms')
    nusers = adds('nodeUsers')
    nvars = adds('nodeVars')
    # qssj 骨架行：type1=绑表字段的行（textParam≠taskInfo），type2=taskDate 行
    nv_t1 = [o for o in nvars if ptext(props(o).get('type')) == '1'
             and ptext(props(o).get('textParam')) != 'taskInfo']
    nv_t2 = [o for o in nvars if ptext(props(o).get('type')) == '2'
             and 'taskDate' in (ptext(props(o).get('text')) or '')]
    nbtns = adds('nodeButtons')
    return {
        'attr': first_obj(top['attr']),
        'act_attr': copy.deepcopy(acts[0]),
        'flow_attr': copy.deepcopy(flows[0]),
        'nform_t1': copy.deepcopy([o for o in nforms if ptext(props(o).get('formSourceType')) == '1'][0]),
        'nform_t2': copy.deepcopy([o for o in nforms if ptext(props(o).get('formSourceType')) == '2'][0]),
        'nuser': copy.deepcopy(nusers[0]),
        'nvar_t1': copy.deepcopy(nv_t1[0]) if nv_t1 else copy.deepcopy(nvars[0]),
        'nvar_t2': copy.deepcopy(nv_t2[0]) if nv_t2 else copy.deepcopy(nvars[-1]),
        'btn_rows': [copy.deepcopy(o) for o in nbtns],
        'rule_rows': [copy.deepcopy(o) for o in adds('ruleNames')],
        'root': root,
        'bpmn_name': bpmn_name,
    }


# ---------- 动态组装 ----------
def build(key, cfg, nodes_cfg, skel, tpl_zip_path):
    F, TB, MKEY = cfg['form'], cfg['table'], cfg['code']
    NAME = cfg.get('name') or (prp.get('/dynamic/function/' + MKEY)[1].get('data') or {}).get('name') or MKEY
    NEW_MID = str(uuid.uuid4())
    ctrls = controls_of(F)

    use = [n for n in nodes_cfg['nodes'] if n.get('want')]
    if not use:
        raise SystemExit('%s: nodes.json 里没有 want=true 的节点' % key)
    for n in use:
        if n['field'] not in ctrls:
            raise SystemExit('%s: 表单缺少审批字段 %s（%s）' % (key, n['field'], n['label']))

    N = len(use)
    ACT = ['Activity_n%d' % i for i in range(1, N + 1)]
    FLOW = ['Flow_n%d' % i for i in range(1, N + 2)]

    # ---- 1) 新 entity.xml 根：深拷贝模板 root，再逐段重写 ----
    root = copy.deepcopy(skel['root'])
    vo = root.find('object')
    top = {v.get('property'): v for v in vo.findall('void')}

    def reset_list(key_name):
        vel = top[key_name]
        for c in list(vel):
            vel.remove(c)
        return ET.SubElement(vel, 'object', {'class': 'java.util.ArrayList'})

    def clone_into(lst_obj, skel_obj, **overrides):
        o = copy.deepcopy(skel_obj)
        pp = props(o)
        for k, v in overrides.items():
            if pp.get(k) is not None:
                setptext(pp[k], v)
            else:
                vv = ET.SubElement(o, 'void', {'property': k})
                ET.SubElement(vv, 'string').text = v
        a = ET.SubElement(lst_obj, 'void', {'method': 'add'})
        a.append(o)
        return o

    # 1) 全局 modelId
    for v in root.iter('void'):
        if v.get('property') == 'modelId':
            setptext(v, NEW_MID)

    # 2) attr
    ap = props(first_obj(top['attr']))
    setptext(ap['modelKey'], MKEY)
    setptext(ap['modelName'], NAME)
    setptext(ap['startFormId'], F)
    setptext(ap['phoneStartFormId'], F)

    # 3) nodeAttrs：N 个 Activity + N+1 条 Flow（末线 finish，其余 going）
    na = reset_list('nodeAttrs')
    for i, n in enumerate(use):
        clone_into(na, skel['act_attr'], nodeId=ACT[i], nodeName=n['label'],
                   nodeFormId=F, phoneNodeFormId=F)
    for i, fid in enumerate(FLOW):
        fa_row = clone_into(na, skel['flow_attr'], nodeId=fid)
        pp = props(fa_row)
        lc = pp.get('lifeCycleState')
        if lc is not None:
            base_state = (ptext(lc) or 'going').rsplit('-', 1)[0]
            life = 'finish' if i == N else 'going'   # 末线（连接结束）= finish
            setptext(lc, base_state + '-' + life)

    # 4) nodeForms：每 Activity × type1/2，auth 全表控件重建
    nf = reset_list('nodeForms')
    for i in range(N):
        for skel_form, stype in ((skel['nform_t1'], '1'), (skel['nform_t2'], '2')):
            nf_id = uuid.uuid4().hex
            clone_into(nf, skel_form, nodeId=ACT[i], formId=F, formSourceType=stype)
            # 上面 clone 的 authList 是模板残留，重建
            row = nf.findall('void[@method="add"]')[-1]
            row_pp = props(first_obj(row))
            av = row_pp['wfDesignNodeFormauthList']
            for c in list(av):
                av.remove(c)
            lst = ET.SubElement(av, 'object', {'class': 'java.util.ArrayList'})
            for datafield, c in sorted(ctrls.items()):
                code = c['code']
                if code.endswith('Name') or code.startswith('subtable_'):
                    continue
                lst.append(new_auth_row(code, nf_id, view='1' if c['visible'] else '2'))
            for sub in subtables_of(F):
                lst.append(new_auth_row(sub, nf_id, view='1', edit='2', required='2', typ='3'))

    # 5) nodeUsers：每 Activity 绑本节点字段
    nu = reset_list('nodeUsers')
    for i, n in enumerate(use):
        clone_into(nu, skel['nuser'], nodeId=ACT[i], assignmentId=n['field'],
                   assignmentKey=TB, remark=ctrls[n['field']]['code'])

    # 6) nodeVars：有日期配对的节点绑 qssj
    nv = reset_list('nodeVars')
    for i, n in enumerate(use):
        if n.get('dateField'):
            clone_into(nv, skel['nvar_t1'], nodeId=ACT[i], text=n['dateField'],
                       textFiledId=ctrls[n['dateField']]['code'], textParam=TB)
            clone_into(nv, skel['nvar_t2'], nodeId=ACT[i])

    # 7) nodeButtons：模板第一个 Activity 的按钮集复制到每个新 Activity
    nb = reset_list('nodeButtons')
    tpl_btn_node = skel['btn_rows'][0] if skel['btn_rows'] else None
    tpl_btn_nodeId = ptext(props(tpl_btn_node).get('nodeId')) if tpl_btn_node is not None else None
    tpl_btn_ids = {id(o) for o in skel['btn_rows']}
    if tpl_btn_nodeId:
        for i in range(N):
            for o in skel['btn_rows']:
                if ptext(props(o).get('nodeId')) == tpl_btn_nodeId:
                    clone_into(nb, o, nodeId=ACT[i])

    # 8) ruleNames：前缀换名、formInfo 绑表.编号字段
    rn = reset_list('ruleNames')
    for o in skel['rule_rows']:
        pp = props(o)
        t = ptext(pp['type'])
        if t == 'fixedCode':
            val = ptext(pp['value']) or ''
            if val.startswith('请审批【'):
                clone_into(rn, o, name='请审批【\t%s :' % NAME, value='请审批【\t%s :' % NAME)
            else:
                clone_into(rn, o)
        elif t == 'formInfo':
            clone_into(rn, o, value='%s.%s' % (TB, cfg['bh']))

    # 9) variables 清空
    reset_list('variables')

    ET.indent(root, space=' ')
    entity = b'<?xml version="1.0" encoding="UTF-8"?>\n' + ET.tostring(root, encoding='utf-8')

    # ---- 2) 动态 BPMN ----
    L = []
    L.append('<?xml version="1.0" encoding="UTF-8"?>')
    L.append('<definitions xmlns="http://www.omg.org/spec/BPMN/20100524/MODEL" '
             'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" '
             'xmlns:xsd="http://www.w3.org/2001/XMLSchema" '
             'xmlns:flowable="http://flowable.org/bpmn" '
             'xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" '
             'xmlns:omgdc="http://www.omg.org/spec/DD/20100524/DC" '
             'xmlns:omgdi="http://www.omg.org/spec/DD/20100524/DI" '
             'typeLanguage="http://www.w3.org/2001/XMLSchema" '
             'expressionLanguage="http://www.w3.org/1999/XPath" '
             'targetNamespace="http://bpmn.io/schema/bpmn">')
    L.append('  <process id="%s" name="%s" isExecutable="true">' % (MKEY, NAME))
    L.append('    <startEvent id="EventStart_n1" name="开始">')
    L.append('      <extensionElements>')
    L.append('        <flowable:executionListener event="end" class="com.best.flow.common.listener.StartExecutionListener"></flowable:executionListener>')
    L.append('      </extensionElements>')
    L.append('    </startEvent>')
    L.append('    <endEvent id="EventEnd_n1" name="结束"></endEvent>')
    L.append('    <sequenceFlow id="%s" sourceRef="EventStart_n1" targetRef="%s">' % (FLOW[0], ACT[0]))
    L.append('      <conditionExpression xsi:type="tFormalExpression">'
             '<![CDATA[${sequenceAttrExpression.evaluate(execution, "%s")}]]></conditionExpression>' % FLOW[0])
    L.append('    </sequenceFlow>')
    for i, n in enumerate(use):
        L.append('    <userTask id="%s" name="%s">' % (ACT[i], n['label']))
        L.append('      <extensionElements>')
        L.append('        <flowable:taskListener event="create" class="com.best.flow.common.listener.UserTaskListener"></flowable:taskListener>')
        L.append('      </extensionElements>')
        L.append('    </userTask>')
        if i < N - 1:
            L.append('    <sequenceFlow id="%s" sourceRef="%s" targetRef="%s"></sequenceFlow>'
                     % (FLOW[i + 1], ACT[i], ACT[i + 1]))
    L.append('    <sequenceFlow id="%s" sourceRef="%s" targetRef="EventEnd_n1"></sequenceFlow>'
             % (FLOW[N], ACT[N - 1]))
    L.append('  </process>')
    # DI 坐标：蛇形折行，每行最多 6 个（用户要求，避免一张图拉太长缩得太小）
    COLS = 6
    W_A, H_A = 90, 60      # 审批节点
    W_E, H_E = 30, 30      # 开始/结束
    STEP_X, STEP_Y = 170, 150
    ORIGIN_X, ORIGIN_Y = 160, 170
    total = N + 2
    seq = ['EventStart_n1'] + ACT[:N] + ['EventEnd_n1']

    def pos(i):
        row, k = divmod(i, COLS)
        col = k if row % 2 == 0 else COLS - 1 - k
        is_act = 0 < i <= N
        w, h = (W_A, H_A) if is_act else (W_E, H_E)
        bx = ORIGIN_X + col * STEP_X
        by = ORIGIN_Y + row * STEP_Y
        x = bx + (W_A - w) / 2.0
        y = by + (H_A - h) / 2.0
        return x, y, w, h, bx + W_A / 2.0, by + H_A / 2.0

    L.append('  <bpmndi:BPMNDiagram id="BPMNDiagram_%s">' % MKEY)
    L.append('    <bpmndi:BPMNPlane bpmnElement="%s" id="BPMNPlane_%s">' % (MKEY, MKEY))
    for i, el in enumerate(seq):
        x, y, w, h, cx, cy = pos(i)
        sid = 'S_es' if i == 0 else ('S_ee' if i == total - 1 else 'S_a%d' % (i - 1))
        L.append('      <bpmndi:BPMNShape bpmnElement="%s" id="%s">'
                 '<omgdc:Bounds height="%.1f" width="%.1f" x="%.1f" y="%.1f"></omgdc:Bounds>'
                 '</bpmndi:BPMNShape>' % (el, sid, h, w, x, y))
    for i in range(total - 1):
        x1, y1, w1, h1, cx1, cy1 = pos(i)
        x2, y2, w2, h2, cx2, cy2 = pos(i + 1)
        if abs(cy1 - cy2) < 1.0:          # 同一行 → 水平线
            if cx2 > cx1:
                a, b = (x1 + w1, cy1), (x2, cy2)
            else:
                a, b = (x1, cy1), (x2 + w2, cy2)
        else:                             # 折行 → 垂直线
            a, b = (cx1, y1 + h1), (cx2, y2)
        L.append('      <bpmndi:BPMNEdge bpmnElement="%s" id="E_%d">'
                 '<omgdi:waypoint x="%.1f" y="%.1f"></omgdi:waypoint>'
                 '<omgdi:waypoint x="%.1f" y="%.1f"></omgdi:waypoint>'
                 '</bpmndi:BPMNEdge>' % (FLOW[i], i, a[0], a[1], b[0], b[1]))
    L.append('    </bpmndi:BPMNPlane>')
    L.append('  </bpmndi:BPMNDiagram>')
    L.append('</definitions>')
    bpmn = '\n'.join(L)

    zp = os.path.join(OUT_DIR, '%s.zip' % MKEY)
    cat = skel['bpmn_name'].split('#&')[1] if '#&' in skel['bpmn_name'] else 'f1c1a7c53268c385a1a3d389042d7217'
    with zipfile.ZipFile(zp, 'w', zipfile.ZIP_DEFLATED) as zo:
        zo.writestr('%s#&%s#&xml.xml' % (MKEY, cat), bpmn)
        zo.writestr('entity.xml', entity)
    print('%s -> %s (name=%s, %d 节点: %s)' % (
        MKEY, zp, NAME, N, ' → '.join(n['label'] for n in use)))
    return zp


def upload(zp):
    boundary = '----wkz%d' % int(time.time() * 1000)
    body = io.BytesIO()
    body.write(('--%s\r\nContent-Disposition: form-data; name="file"; filename="%s"\r\n'
                'Content-Type: application/zip\r\n\r\n' % (boundary, os.path.basename(zp))).encode())
    body.write(open(zp, 'rb').read())
    body.write(('\r\n--%s--\r\n' % boundary).encode())
    import urllib.request
    r = urllib.request.Request(prp.BASE + '/workflow/model/importModel', data=body.getvalue(), method='POST')
    r.add_header('Authorization', 'Bearer ' + prp.TOKEN)
    r.add_header('Content-Type', 'multipart/form-data; boundary=' + boundary)
    with urllib.request.urlopen(r, timeout=120) as resp:
        return json.loads(resp.read().decode() or '{}')


def deploy_by_key(key):
    ms = []
    for _ in range(5):
        ms = [m for m in prp.models() if m['modelKey'] == key]
        if ms:
            break
        time.sleep(2)
    if not ms:
        print('  !! %s 未落地' % key)
        return
    # 同一 key 可能有多条（重复导入），取最新创建的那条来部署
    ms.sort(key=lambda m: m.get('createTime') or '', reverse=True)
    st, r = prp.req('POST', '/workflow/model/deploy', {'modeId': ms[0]['modelId']})
    print('  deploy %s (model %s %s) -> %s %s' % (key, ms[0]['modelId'][:8], ms[0].get('createTime'), r.get('code'), r.get('msg')))
    time.sleep(5)


def main():
    argv = sys.argv[1:]
    apply = '--apply' in argv
    tpl = None
    if '--template' in argv:
        i = argv.index('--template')
        tpl = argv[i + 1]
        argv = argv[:i] + argv[i + 2:]
    if not tpl:
        print('用法: python build_flows.py --template 模板.zip [--apply] [code ...]')
        sys.exit(1)
    tables = load('tables.json', 'detect_forms.py')
    nodes = load('nodes.json', 'pick_nodes.py')
    skel = load_skeleton(tpl)
    keys = [a for a in argv if a in tables] or list(tables)
    for key in keys:
        zp = build(key, tables[key], nodes[key], skel, tpl)
        if apply:
            r = upload(zp)
            print('  import ->', r.get('code'), r.get('msg'))
            time.sleep(6)
            deploy_by_key(key)


if __name__ == '__main__':
    main()
