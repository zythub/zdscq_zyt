# -*- coding: utf-8 -*-
"""流程图几何工具：尺寸规范、端点吸附、正交走线、自动校验、尺寸修复。

★ 为什么有这个模块（2026-11-03 血泪）
  「线偏移」**不是画线技巧问题，是节点尺寸写错**。
  平台渲染 userTask 一律 90x60（不认 XML 里写多大），而早期人工排版的流程把
  Bounds 写成 140x56，线端点按 140x56 算 -> 平台画出来的框只有 90x60 宽，
  箭头必然悬空 25~50px，表现为「线飘了 / 没连到节点上」。
  实测：36 张 PRP 流程共 325 条边，端点未贴边 6 条，全部集中在 140x56 的 3 张；
  平台原生样例（缺陷管理 TS_qxgl）userTask=90x60、事件=30x30，端点严格贴边。

  所以铁律：**节点 Bounds 必须写平台真实渲染尺寸**，端点由算法吸附，不许手算。

本模块提供
  常量      TASK_W/TASK_H/EVENT_W/EVENT_H
  parse     解析 BPMN XML -> (kinds, shapes, edges, flows)
  check     一键体检：尺寸 / 端点贴边 / 斜线 / 穿节点 / 零长度线
  normalize 修复：尺寸归一 + 端点重新吸附 + 路径正交化
  snap      端点吸附（给定矩形某条边上的点）
  route     两个矩形之间的正交折线（首尾自动吸附）

坐标系：BPMN 原点在左上，y 向下。
waypoint 命名空间是 omgdi(http://www.omg.org/spec/DD/20100524/DI)，
**不是** bpmndi(.../BPMN/20100524/DI)——解析时别用错。
"""
import re
import xml.etree.ElementTree as ET

NS = {
    "b": "http://www.omg.org/spec/BPMN/20100524/MODEL",
    "di": "http://www.omg.org/spec/BPMN/20100524/DI",
    "dc": "http://www.omg.org/spec/DD/20100524/DC",
    "di2": "http://www.omg.org/spec/DD/20100524/DI",
}

# ---- 平台真实渲染尺寸（唯一真源）------------------------------------
TASK_W, TASK_H = 90.0, 60.0        # 人工节点
EVENT_W, EVENT_H = 36.0, 36.0      # 开始 / 结束节点
TOL = 1.0                          # 端点贴边容差（px）

EVENT_KINDS = ("startEvent", "endEvent")


def node_size(kind):
    """按节点类型返回平台真实渲染尺寸。"""
    return (EVENT_W, EVENT_H) if kind in EVENT_KINDS else (TASK_W, TASK_H)


# ------------------------------------------------------------------ parse
def parse(xml):
    """-> (kinds, shapes, edges, flows)
    kinds : {id: 'userTask'/'startEvent'/...}
    shapes: {id: (x, y, w, h)}
    edges : {flowId: [(x, y), ...]}
    flows : [(flowId, sourceRef, targetRef)]
    """
    root = ET.fromstring(xml)
    proc = root.find("b:process", NS)
    kinds = {}
    if proc is not None:
        for tag in ("startEvent", "endEvent", "userTask", "exclusiveGateway",
                    "parallelGateway", "callActivity"):
            for e in proc.findall("b:" + tag, NS):
                kinds[e.get("id")] = tag
    shapes = {}
    for sh in root.iter("{%s}BPMNShape" % NS["di"]):
        b = sh.find("dc:Bounds", NS)
        if b is not None:
            shapes[sh.get("bpmnElement")] = tuple(float(b.get(k)) for k in ("x", "y", "width", "height"))
    edges = {}
    for ed in root.iter("{%s}BPMNEdge" % NS["di"]):
        edges[ed.get("bpmnElement")] = [(float(w.get("x")), float(w.get("y")))
                                        for w in ed.findall("di2:waypoint", NS)]
    flows = []
    if proc is not None:
        for e in proc.findall("b:sequenceFlow", NS):
            flows.append((e.get("id"), e.get("sourceRef"), e.get("targetRef")))
    return kinds, shapes, edges, flows


# ------------------------------------------------------------- anchor/snap
def snap(rect, side, offset=0.0):
    """矩形某条边上的锚点。side: left/right/top/bottom。"""
    x, y, w, h = rect
    if side == "left":
        return (x, y + h / 2.0 + offset)
    if side == "right":
        return (x + w, y + h / 2.0 + offset)
    if side == "top":
        return (x + w / 2.0 + offset, y)
    return (x + w / 2.0 + offset, y + h)


def _side_of(p, rect):
    """判断点 p 贴在矩形哪条边上；贴不住返回 None。"""
    x, y, w, h = rect
    if abs(p[0] - x) <= TOL and (y - TOL <= p[1] <= y + h + TOL):
        return "left"
    if abs(p[0] - (x + w)) <= TOL and (y - TOL <= p[1] <= y + h + TOL):
        return "right"
    if abs(p[1] - y) <= TOL and (x - TOL <= p[0] <= x + w + TOL):
        return "top"
    if abs(p[1] - (y + h)) <= TOL and (x - TOL <= p[0] <= x + w + TOL):
        return "bottom"
    return None


def _on_border(p, rect, tol=TOL):
    return _side_of(p, rect) is not None


# ------------------------------------------------------------------ route
def route(srect, drect, rects=(), skip=(), side=None):
    """两个矩形之间的正交折线；首尾点自动吸附到边界。

    side: 强制指定连线从源节点哪条边出 / 进目标节点哪条边，
          形如 ('right', 'left')；不给则自动判断。
    返回 [(x, y), ...]，至少 2 个点。
    """
    sx, sy, sw, sh = srect
    dx, dy, dw, dh = drect
    scx, scy = sx + sw / 2.0, sy + sh / 2.0
    dcx, dcy = dx + dw / 2.0, dy + dh / 2.0

    if side:
        ss, ts = side
    else:
        if abs(scx - dcx) >= abs(scy - dcy):
            ss = "right" if dcx > scx else "left"
            ts = "left" if dcx > scx else "right"
        else:
            ss = "bottom" if dcy > scy else "top"
            ts = "top" if dcy > scy else "bottom"

    a = snap(srect, ss)
    b = snap(drect, ts)

    # 两点已对齐（同一行/同一列）-> 直接连
    if (abs(a[0] - b[0]) < 0.01 or abs(a[1] - b[1]) < 0.01):
        return [a, b]

    pts = [a]
    if ss in ("left", "right"):
        # 水平出 -> 先水平走到中间列，再垂直，再水平进目标
        mx = (a[0] + b[0]) / 2.0
        pts.append((mx, a[1]))
        pts.append((mx, b[1]))
    else:
        my = (a[1] + b[1]) / 2.0
        pts.append((a[0], my))
        pts.append((b[0], my))
    pts.append(b)

    # 去掉共线中间点
    out = [pts[0]]
    for p in pts[1:]:
        if abs(p[0] - out[-1][0]) < 0.01 and abs(p[1] - out[-1][1]) < 0.01:
            continue
        out.append(p)
    return out


# ------------------------------------------------------------------ check
def _seg_hits_rect(p, q, r):
    """线段是否穿过矩形内部（Liang-Barsky 裁剪）。

    ⚠️ 斜线段**不能**直接返回 True——那会把「没碰到」的线也算成穿节点，
    实测导致 5 张本来合格的流程被误报。平台原生流程里 1px 的抖动很常见，
    所以这里用 Liang-Barsky 精确判定，而不是靠方向近似。
    """
    EPS = 2.0
    x, y, w, h = r
    x0, y0, x1, y1 = x + EPS, y + EPS, x + w - EPS, y + h - EPS
    if x1 <= x0 or y1 <= y0:
        return False
    px, py = p
    qx, qy = q
    dx, dy = qx - px, qy - py
    t0, t1 = 0.0, 1.0
    for pp, qq in ((-dx, px - x0), (dx, x1 - px), (-dy, py - y0), (dy, y1 - py)):
        if abs(pp) < 1e-9:
            if qq < 0:
                return False
        else:
            t = qq / pp
            if pp < 0:
                if t > t1:
                    return False
                if t > t0:
                    t0 = t
            else:
                if t < t0:
                    return False
                if t < t1:
                    t1 = t
    return True


def check(xml):
    """一键体检。返回 dict：
       size   : [(flow_id, node_id, kind, (w,h), 期望(w,h))]  尺寸不合规
       anchor : [(flow_id, 'start'/'end', node_id, dx, dy)]     端点未贴边
       diag   : [(flow_id, 段序号)]                              斜线
       cross  : [(flow_id, node_id)]                             穿节点
       zero   : [flow_id]                                       无 waypoint
       summary: 统计
    """
    kinds, shapes, edges, flows = parse(xml)
    rep = {"size": [], "anchor": [], "diag": [], "cross": [], "zero": [],
           "flows": len(flows)}
    for nid, kind in kinds.items():
        if nid in shapes and kind in ("userTask", "startEvent", "endEvent"):
            x, y, w, h = shapes[nid]
            exp = node_size(kind)
            if abs(w - exp[0]) > 0.5 or abs(h - exp[1]) > 0.5:
                rep["size"].append((nid, kind, (round(w, 1), round(h, 1)), exp))
    for fid, s, t in flows:
        pts = edges.get(fid) or []
        if len(pts) < 2:
            rep["zero"].append(fid)
            continue
        for label, p, node in (("start", pts[0], s), ("end", pts[-1], t)):
            if node in shapes and not _on_border(p, shapes[node]):
                x, y, w, h = shapes[node]
                dx = min(abs(p[0] - x), abs(p[0] - (x + w)))
                dy = min(abs(p[1] - y), abs(p[1] - (y + h)))
                rep["anchor"].append((fid, label, node, round(dx, 1), round(dy, 1)))
        for i in range(len(pts) - 1):
            # 容差 1px：平台原生数据常见 1px 抖动（330,200 -> 425,201），不算斜线
            if abs(pts[i][0] - pts[i + 1][0]) > 1.0 and abs(pts[i][1] - pts[i + 1][1]) > 1.0:
                rep["diag"].append((fid, i))
        for other, r in shapes.items():
            if other in (s, t):
                continue
            for i in range(len(pts) - 1):
                if _seg_hits_rect(pts[i], pts[i + 1], r):
                    rep["cross"].append((fid, other))
                    break
    rep["summary"] = {k: len(rep[k]) for k in ("size", "anchor", "diag", "cross", "zero")}
    rep["summary"]["flows"] = len(flows)
    return rep


def report(xml, title=""):
    rep = check(xml)
    s = rep["summary"]
    print("[%s] 线 %d 条 | 尺寸错 %d | 端点偏 %d | 斜线 %d | 穿节点 %d | 无点 %d"
          % (title, s["flows"], s["size"], s["anchor"], s["diag"], s["cross"], s["zero"]))
    for x in rep["size"][:10]:
        print("   尺寸 %s %s 实际 %s 期望 %s" % x)
    for x in rep["anchor"][:10]:
        print("   端点 %s %s @%s 偏 dx=%s dy=%s" % x)
    for x in rep["diag"][:6]:
        print("   斜线 %s 段%s" % x)
    for x in rep["cross"][:6]:
        print("   穿节点 %s @%s" % x)
    return rep


# -------------------------------------------------------------- normalize
def _orthogonalize(pts, tol=1.0):
    """把折线正交化：每段都是水平或垂直。

    ★ 端点 p[0] / p[n-1] 绝对不动 —— 端点贴着节点边界，一动就又偏了。

    两种斜段要分开处理（这是返工三次才想明白的关键）：
      a) 后一个点是内部折点 -> 把它拉成水平（b.y = a.y）
      b) 后一个点是**固定端点** -> 拉不动，改成**插入阶梯中间点**
         mid = (b.x, a.y)：a->mid 水平、mid->b 垂直
         典型场景：源节点右边界中点 y=283、目标节点左边界中点 y=285，
         两端都被节点边界钉死、差 2px，只能靠阶梯绕过。
    """
    out = [tuple(pts[0])]
    n = len(pts)
    for i in range(1, n):
        a = out[-1]
        b = tuple(pts[i])
        if abs(a[0] - b[0]) > tol and abs(a[1] - b[1]) > tol:
            if i < n - 1:
                b = (b[0], a[1])           # 后一个点可动 -> 拉成水平
            else:
                out.append((b[0], a[1]))  # 后一个是固定端点 -> 插阶梯
        out.append(b)
    # 去共线点
    res = [out[0]]
    for p in out[1:]:
        if abs(p[0] - res[-1][0]) < 0.01 and abs(p[1] - res[-1][1]) < 0.01:
            continue
        res.append(p)
    return res


def _bounds_re(node_id):
    """匹配某个 shape 的 Bounds 行（保留原格式，只改数值）。"""
    pat = (r'(<bpmndi:BPMNShape[^>]*bpmnElement="%s"[^>]*>\s*<omgdc:Bounds[^>]*?)'
           r'height="([\d.]+)"\s+width="([\d.]+)"\s+x="([\d.]+)"\s+y="([\d.]+)"'
           r'([^>]*>)' % re.escape(node_id))
    return pat


def normalize(xml):
    """把流程图几何修正到「不偏移」状态。

    三步：
      1. 尺寸归一：userTask 一律 90x60、事件一律 36x36，**节点中心不动**
      2. 端点重吸附：首/末 waypoint 重新贴到（新的）源/目标边界
      3. 路径正交化：中间拐点投影，保证每段都是水平或垂直

    返回 (新 XML, 报告)。用正则改，不走 ElementTree（避免命名空间被重排，
    平台对格式敏感）。
    """
    kinds, shapes, edges, flows = parse(xml)
    rep = {"resized": [], "reanchored": [], "ortho": []}

    # ---- 1. 尺寸归一（保持中心）
    new_shapes = {}
    for nid, kind in kinds.items():
        if nid not in shapes:
            continue
        x, y, w, h = shapes[nid]
        ew, eh = node_size(kind)
        if abs(w - ew) < 0.5 and abs(h - eh) < 0.5:
            new_shapes[nid] = (x, y, w, h)
            continue
        cx, cy = x + w / 2.0, y + h / 2.0
        nx, ny = round(cx - ew / 2.0, 1), round(cy - eh / 2.0, 1)
        new_shapes[nid] = (nx, ny, ew, eh)
        rep["resized"].append((nid, kind, (w, h), (ew, eh)))

    for nid, (x, y, w, h) in new_shapes.items():
        old = shapes[nid]
        if abs(old[2] - w) < 0.01 and abs(old[3] - h) < 0.01:
            continue
        pat = _bounds_re(nid)
        m = re.search(pat, xml)
        if not m:
            continue
        xml = re.sub(pat, lambda mm: '%sheight="%s" width="%s" x="%s" y="%s"%s'
                     % (mm.group(1), h, w, x, y, mm.group(6)), xml, count=1)

    # ---- 2 + 3. 端点重吸附 + 正交化
    def fix_edge(fid, s, t):
        pts = list(edges.get(fid) or [])
        if len(pts) < 2:
            return None
        changed = False
        if s in new_shapes:
            side = _side_of(pts[0], shapes.get(s) or new_shapes[s])
            if side:
                ns = snap(new_shapes[s], side)
                if ns != pts[0]:
                    pts[0] = ns
                    changed = True
                    rep["reanchored"].append((fid, "start"))
            else:
                # 原来就悬空：按中心连线方向贴最近边
                ns = snap(new_shapes[s], _guess_side(new_shapes[s], new_shapes.get(t) or new_shapes[s]))
                pts[0] = ns
                changed = True
                rep["reanchored"].append((fid, "start"))
        if t in new_shapes:
            side = _side_of(pts[-1], shapes.get(t) or new_shapes[t])
            if side:
                ns = snap(new_shapes[t], side)
                if ns != pts[-1]:
                    pts[-1] = ns
                    changed = True
                    rep["reanchored"].append((fid, "end"))
            else:
                ns = snap(new_shapes[t], _guess_side(new_shapes[t], new_shapes.get(s) or new_shapes[t]))
                pts[-1] = ns
                changed = True
                rep["reanchored"].append((fid, "end"))

        # 正交化：只动**内部折点**，端点绝不移动（动了就会破坏贴边）
        new_pts = _orthogonalize(pts)
        if new_pts != pts:
            rep["ortho"].append((fid, len(pts)))
            changed = True
            pts = new_pts
        # 去共线点
        out = [pts[0]]
        for p in pts[1:]:
            if abs(p[0] - out[-1][0]) < 0.01 and abs(p[1] - out[-1][1]) < 0.01:
                continue
            out.append(p)
        if len(out) != len(pts):
            changed = True
        pts = out
        return pts if changed else None

    def _guess_side(a, b):
        acx, acy = a[0] + a[2] / 2.0, a[1] + a[3] / 2.0
        bcx, bcy = b[0] + b[2] / 2.0, b[1] + b[3] / 2.0
        return "right" if bcx > acx else ("left" if bcx < acx else ("bottom" if bcy > acy else "top"))

    for fid, s, t in flows:
        newpts = fix_edge(fid, s, t)
        if not newpts:
            continue
        # 替换 XML 里该 edge 的 waypoint 列表
        pat = re.compile(r'(<bpmndi:BPMNEdge[^>]*bpmnElement="%s"[^>]*>)(.*?)(</bpmndi:BPMNEdge>)'
                         % re.escape(fid), re.S)
        m = pat.search(xml)
        if not m:
            continue
        body = "".join('\n        <omgdi:waypoint x="%s" y="%s"></omgdi:waypoint>'
                        % (round(p[0], 1), round(p[1], 1)) for p in newpts)
        xml = xml[:m.start()] + m.group(1) + body + m.group(3) + xml[m.end():]
        edges[fid] = newpts

    return xml, rep


# ------------------------------------------------------------------- CLI
def _load(path):
    import io
    import os
    import zipfile
    if path.endswith(".zip"):
        z = zipfile.ZipFile(path)
        n = [x for x in z.namelist() if x.endswith(".xml") and "entity" not in x.lower()]
        return z.read(n[0]).decode("utf-8")
    return io.open(path, encoding="utf-8").read()


def main():
    import argparse
    import io
    ap = argparse.ArgumentParser(description="流程图几何体检 / 修复")
    ap.add_argument("xml", nargs="+", help="BPMN xml 或流程包 zip")
    ap.add_argument("--fix", action="store_true", help="修复尺寸/端点/斜线并覆盖写回")
    ap.add_argument("--out", help="修复后的输出路径（xml 或 zip）")
    a = ap.parse_args()
    for p in a.xml:
        xml = _load(p)
        if not a.fix:
            report(xml, p)
            continue
        new, rep = normalize(xml)
        print("[%s] 修复：改尺寸 %d / 重吸附 %d / 正交化 %d"
              % (p, len(rep["resized"]), len(rep["reanchored"]), len(rep["ortho"])))
        report(new, p + " (修复后)")
        out = a.out or p
        if p.endswith(".zip"):
            import os
            import zipfile
            z = zipfile.ZipFile(p)
            names = z.namelist()
            xn = [x for x in names if x.endswith(".xml") and "entity" not in x.lower()][0]
            import io as _io
            buf = _io.BytesIO()
            with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as w:
                for n in names:
                    w.writestr(n, new.encode("utf-8") if n == xn else z.read(n))
            open(out, "wb").write(buf.getvalue())
        else:
            io.open(out, "w", encoding="utf-8").write(new)
        print("  -> %s" % out)


if __name__ == "__main__":
    main()
