# -*- coding: utf-8 -*-
"""PRP 一比一复刻（2026-11-02 定稿版）：含「起草人修改」类驳回落点节点；线按 PRP 原始折线
   一比一映射（走向/拐点与原图一致），端点=节点中心连线与边界的交点（正交居中）。
   生成 → 覆盖导入（同 modelKey）→ 部署 → 线状态全量复核。
   ★ 换环境/换流程只改顶部：BASE / TOKEN / MODEL_KEY / MODEL_NAME / SRC_JSON / SKELETON / OUT。
   ★ 部署要求模型绑起始表单：attr 顶层 startFormId/phoneStartFormId 必须是目标环境存在的表单，
     表单没迁移时 deploy 报「基础属性中的表单未设置」——图照常可看，部署等表单到位后再做。"""
import json, time, zipfile, re
import xml.etree.ElementTree as ET

BASE = 'http://172.19.18.223:1112/apis'
TOKEN = 'f02551a63f0252b0153849931d0a5c0f'
ADMIN = '1023f2f07eb790966dce67621f0f889c'
MODEL_KEY = 'PRP_CGLX'
MODEL_NAME = '集中采购立项请购审批表'
TS = int(time.time() * 1000)
SRC_JSON = r'C:\Users\Administrator\Desktop\prp迁移流程\集中采购立项请购审批表.json'
SKELETON = 'tmp_models/TUD_CSZDSCLC_full3.zip'
OUT = 'tmp_models/PRP_CGLX_1112.zip'


def req(method, path, body=None, timeout=90):
    import urllib.request, urllib.error
    data = json.dumps(body, ensure_ascii=False).encode() if body is not None else None
    r = urllib.request.Request(BASE + path, data=data, method=method)
    r.add_header('Authorization', 'Bearer ' + TOKEN)
    r.add_header('Content-Type', 'application/json')
    r.add_header('language', 'zh_CN')
    with urllib.request.urlopen(r, timeout=timeout) as resp:
        return json.loads(resp.read().decode() or '{}')


def mx(x): return (x + 27) * 1.35 + 60
def my(y): return (y + 11) * 0.95 + 80


def snap(pt, rect):
    x, y, w, h = rect
    px, py = pt
    px = min(max(px, x), x + w); py = min(max(py, y), y + h)
    dl, dr, dt, db = abs(px - x), abs(px - (x + w)), abs(py - y), abs(py - (y + h))
    d = min(dl, dr, dt, db)
    if d == dt: return (px, y)
    if d == db: return (px, y + h)
    if d == dl: return (x, py)
    return (x + w, py)


data = json.load(open(SRC_JSON, encoding='utf-8'))
nodes, edges = data['nodes'], data['edges']
incoming = {}
for e in edges.values():
    incoming.setdefault(e['target']['id'], []).append(1)

starts = [n for n in nodes.values() if n['ActivityType'] == 7]
ends = [n for n in nodes.values() if n['ActivityType'] == 8]
tasks = [n for n in nodes.values() if n['ActivityType'] == 1]
print('节点: start %d end %d task %d（一比一，全建）' % (len(starts), len(ends), len(tasks)))

idmap = {}
for s in starts: idmap[s['id']] = 'EventStart_1'
for e in ends: idmap[e['id']] = 'EventEnd_1'
for i, t in enumerate(sorted(tasks, key=lambda n: (n['y'], n['x'])), 1):
    idmap[t['id']] = 'Activity_p%d' % i

XY, NAMES = {}, {}
for n in nodes.values():
    nid = idmap[n['id']]
    cx, cy = mx(n['x'] + n['width'] / 2), my(n['y'] + n['height'] / 2)
    if n['ActivityType'] in (7, 8):
        XY[nid] = (cx - 15, cy - 15, 30, 30)
    else:
        XY[nid] = (cx - 70, cy - 28, 140, 56)
    if n['ActivityType'] == 1:
        NAMES[nid] = n['Caption']

# BPMN
L = ['<?xml version="1.0" encoding="UTF-8"?>',
     '<definitions xmlns="http://www.omg.org/spec/BPMN/20100524/MODEL" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" '
     'xmlns:flowable="http://flowable.org/bpmn" xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" '
     'xmlns:omgdc="http://www.omg.org/spec/DD/20100524/DC" xmlns:omgdi="http://www.omg.org/spec/DD/20100524/DI" '
     'targetNamespace="http://bpmn.io/schema/bpmn">',
     '  <process id="%s" name="%s" isExecutable="true">' % (MODEL_KEY, MODEL_NAME),
     '    <startEvent id="EventStart_1" name="开始">'
     '<extensionElements><flowable:executionListener event="end" class="com.best.flow.common.listener.StartExecutionListener"></flowable:executionListener></extensionElements>'
     '</startEvent>',
     '    <endEvent id="EventEnd_1" name="结束"></endEvent>']
flow_rows = []
i = 0
for eid, e in sorted(edges.items()):
    if e['source']['id'] not in idmap or e['target']['id'] not in idmap:
        continue
    i += 1
    fid = 'Flow_p%d' % i
    cap = e.get('Caption') or ''
    nm = ' name="%s"' % cap if cap else ''
    flow_rows.append((fid, idmap[e['source']['id']], idmap[e['target']['id']],
                      e.get('source', {}).get('id'), e.get('target', {}).get('id'),
                      e.get('points') or [], nm))
    L.append('    <sequenceFlow id="%s"%s sourceRef="%s" targetRef="%s"></sequenceFlow>'
             % (fid, nm, idmap[e['source']['id']], idmap[e['target']['id']]))
for t in sorted(tasks, key=lambda n: idmap[n['id']]):
    L.append('    <userTask id="%s" name="%s">'
             '<extensionElements><flowable:taskListener event="create" class="com.best.flow.common.listener.UserTaskListener"></flowable:taskListener></extensionElements>'
             '</userTask>' % (idmap[t['id']], t['Caption']))
L.append('  </process>')
L.append('  <bpmndi:BPMNDiagram id="BPMNDiagram_%s">' % MODEL_KEY)
L.append('    <bpmndi:BPMNPlane bpmnElement="%s" id="BPMNPlane_%s">' % (MODEL_KEY, MODEL_KEY))
for nid, (x, y, w, h) in XY.items():
    L.append('      <bpmndi:BPMNShape bpmnElement="%s" id="S_%s"><omgdc:Bounds height="%.0f" width="%.0f" x="%.0f" y="%.0f"></omgdc:Bounds></bpmndi:BPMNShape>'
             % (nid, nid, h, w, x, y))
for fid, src, dst, src_p, dst_p, points, nm in flow_rows:
    # PRP 完整路径：源中心 + 拐点 + 目标中心（老画布坐标），再映射；首段/末段裁剪到节点边界
    sp = nodes[src_p]; tp = nodes[dst_p]
    src_c = (sp['x'] + sp['width'] / 2, sp['y'] + sp['height'] / 2)
    dst_c = (tp['x'] + tp['width'] / 2, tp['y'] + tp['height'] / 2)
    full = [src_c] + [(p['x'], p['y']) for p in points] + [dst_c]
    mapped = [(mx(p[0]), my(p[1])) for p in full]

    def seg_exit(p0, p1, rect):
        x, y, w, h = rect
        dx, dy = p1[0] - p0[0], p1[1] - p0[1]
        ts = []
        if dx:
            for ex in (x, x + w):
                t = (ex - p0[0]) / dx
                if 0 < t <= 1:
                    yy = p0[1] + t * dy
                    if y - 0.5 <= yy <= y + h + 0.5:
                        ts.append((t, ex, yy))
        if dy:
            for ey in (y, y + h):
                t = (ey - p0[1]) / dy
                if 0 < t <= 1:
                    xx = p0[0] + t * dx
                    if x - 0.5 <= xx <= x + w + 0.5:
                        ts.append((t, xx, ey))
    # 出边交点（源）与入边交点（目标）
        t, ex, ey = min(ts) if ts else (0, p0[0], p0[1])
        return (round(ex), round(ey))

    first = seg_exit(mapped[0], mapped[1], XY[src])
    last = seg_exit(mapped[-1], mapped[-2], XY[dst])
    wps = [first] + mapped[1:-1] + [last]
    wp = ''.join('<omgdi:waypoint x="%.0f" y="%.0f"></omgdi:waypoint>' % p for p in wps)
    L.append('      <bpmndi:BPMNEdge bpmnElement="%s" id="E_%s">%s</bpmndi:BPMNEdge>' % (fid, fid, wp))
L.append('    </bpmndi:BPMNPlane>')
L.append('  </bpmndi:BPMNDiagram>')
L.append('</definitions>')
bpmn = '\n'.join(L)

# entity
zin = zipfile.ZipFile(SKELETON)
old_name = [n for n in zin.namelist() if n.endswith('xml.xml')][0]
cat = old_name.split('#&')[1]
entity = zin.read('entity.xml').decode('utf-8')
MID = '776cf781-d42e-11f1-a271-286ed488d29a'


def row(cls, props):
    s = '    <void method="add">\n     <object class="%s">\n' % cls
    for k, v in props:
        s += '      <void property="%s"><string>%s</string></void>\n' % (k, v)
    s += '     </object>\n    </void>\n'
    return s


def rebuild(entity, prop, rows):
    i = entity.find('property="%s"' % prop)
    end = entity.find('\n   </object>\n  </void>', i)
    return entity[:i] + 'property="%s">\n   <object class="java.util.ArrayList">\n' % prop + rows + entity[end:]


node_rows = ''
user_rows = ''
for nid in sorted(NAMES):
    node_rows += row('com.best.flow.domain.WfDesignNodeAttribute', [
        ('nodeId', nid), ('nodeKey', nid), ('nodeName', NAMES[nid]), ('modelId', MID),
        ('nodeType', 'userTask'), ('nodeMustOpinion', '0'), ('autoAgree', '0'), ('doCopy', '0'),
        ('submitMustUser', '0'), ('nodeUserSingle', '0'), ('selectUserSingleton', '0'),
        ('openRevoke', '1'), ('delFlag', '0'), ('taskInstName', '["${InstNameKey}"]'),
        ('createBy', ADMIN), ('updateBy', ADMIN)])
    user_rows += row('com.best.flow.domain.WfDesignNodeUser', [
        ('nodeId', nid), ('assignmentId', ADMIN), ('type', '1'), ('modelId', MID),
        ('delFlag', '0'), ('createBy', ADMIN), ('updateBy', ADMIN)])
rule_rows = row('com.best.flow.domain.WfDesignRulename', [
    ('name', '请审批【%s：' % MODEL_NAME), ('type', 'fixedCode'),
    ('value', '请审批【%s：' % MODEL_NAME), ('sortNum', 1), ('modelId', MID),
    ('delFlag', '0'), ('createBy', ADMIN), ('updateBy', ADMIN)])

entity = rebuild(entity, 'nodeAttrs', node_rows)
entity = rebuild(entity, 'nodeUsers', user_rows)
entity = rebuild(entity, 'ruleNames', rule_rows)
for prop in ('nodeForms', 'nodeVars', 'nodeSequences', 'variables'):
    entity = rebuild(entity, prop, '')
entity = entity.replace('<string>TUD_CSZDSCLC</string>', '<string>%s</string>' % MODEL_KEY)
entity = entity.replace('>测试自动生成流程<', '>%s<' % MODEL_NAME)
# 表单未迁移：attr 顶层的起始表单引用置空（1112 无该表单，deploy 会 204）
entity = re.sub(r'(property="(?:startFormId|phoneStartFormId)">\s*)<string>[^<]*</string>',
                r'\g<1><string></string>', entity)

with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED) as zo:
    zo.writestr('%s#&%s#&xml.xml' % (MODEL_KEY, cat), bpmn)
    zo.writestr('entity.xml', entity)
print('生成', OUT)


# ---- 上传/部署/线状态 ----
import io, os, urllib.request
boundary = '----wkz%d' % int(time.time() * 1000)
body = io.BytesIO()
body.write(('--%s\r\nContent-Disposition: form-data; name="file"; filename="%s"\r\n'
            'Content-Type: application/zip\r\n\r\n' % (boundary, os.path.basename(OUT))).encode())
body.write(open(OUT, 'rb').read())
body.write(('\r\n--%s--\r\n' % boundary).encode())
rq = urllib.request.Request(BASE + '/workflow/model/importModel', data=body.getvalue(), method='POST')
rq.add_header('Authorization', 'Bearer ' + TOKEN)
rq.add_header('Content-Type', 'multipart/form-data; boundary=' + boundary)
resp = json.loads(urllib.request.urlopen(rq, timeout=120).read().decode() or '{}')
print('import ->', resp.get('code'), resp.get('msg'))
time.sleep(7)
d = req('GET', '/workflow/model/list?currentPage=1&pageSize=50')['data']['records']
mid = [m for m in d if m['modelKey'] == MODEL_KEY][0]['modelId']
print('modelId', mid)
r2 = req('POST', '/workflow/model/deploy', {'modeId': mid})
print('deploy ->', r2.get('code'), r2.get('msg'))
time.sleep(6)

# 线状态（所有进结束的线=finish，其余=going；nodeName=BPMN 线 name）
B = 'http://www.omg.org/spec/BPMN/20100524/MODEL'
st, r = req('GET', '/workflow/model/' + mid), None
bpmn = req('GET', '/workflow/model/' + mid)['data']['bpmnXml']
root = ET.fromstring(bpmn)
proc = root.find('.//{%s}process' % B)
end_id = proc.find('{%s}endEvent' % B).get('id')
flws = [(f.get('id'), f.get('targetRef'), f.get('name') or '') for f in proc.findall('{%s}sequenceFlow' % B)]
fixed = 0
for fid, dst, fname in flws:
    target = 'FlowTemplateStates-flowstate-finish' if dst == end_id else 'FlowTemplateStates-flowstate-going'
    bo = {'nodeKey': fid, 'modelId': mid, 'nodeId': fid, 'nodeName': fname, 'nodeProgress': None,
          'messageType': '', 'nodeUserSingle': '0', 'nodeMustOpinion': '0', 'selectUserSingleton': '0',
          'submitMustUser': '0', 'childTable': '', 'childField': '', 'parentField': '',
          'taskInstName': '["${InstNameKey}"]', 'autoAgree': '0', 'openRevoke': '1',
          'confirmcopyMessageType': '', 'doCopy': '0', 'remark': '', 'sortNum': None,
          'lifeCycleState': target, 'messageApitypeJson': ''}
    rr = req('PUT', '/workflow/design-node-attribute/addAndEdit',
             {'modelId': mid, 'nodeId': fid, 'xml': bpmn, 'bo': bo})
    fixed += rr.get('code') == 200
    if rr.get('code') != 200:
        print('线状态FAIL', fid, json.dumps(rr, ensure_ascii=False)[:120])
    time.sleep(0.3)
print('线状态设置 %d/%d' % (fixed, len(flws)))
time.sleep(5)
r3 = req('POST', '/workflow/model/deploy', {'modeId': mid})
print('deploy2 ->', r3.get('code'), r3.get('msg'))
bad = []
for fid, dst, fname in flws:
    want = 'finish' if dst == end_id else 'going'
    cur = req('GET', '/workflow/design-node-attribute/list/%s/%s' % (mid, fid)).get('data') or {}
    if want not in (cur.get('lifeCycleState') or ''):
        bad.append(fid)
print('线状态复核: %d/%d' % (len(flws) - len(bad), len(flws)), '不符:', bad)
