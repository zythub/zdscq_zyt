# -*- coding: utf-8 -*-
"""流程模型改编号：导出 → 替换 modelKey/BPMN process id → 导入 → 发布

用法: python rename_model.py [--apply]            # 全部 7 个
      python rename_model.py dtts gcdb [--apply]  # 指定
"""
import io, json, os, sys, time, urllib.request, zipfile
import prp

DIR = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(DIR, 'tmp_rename')
os.makedirs(OUT, exist_ok=True)

# modelId 通过 model list 按 key 查；key 改名映射
RENAME = {
    'a1212': 'TS_dtts',
    'a1213': 'TS_gcdb',
    'a1214': 'TS_dbzc',
    'a1215': 'TS_ydgl',
    'a1216': 'TS_tsd',
    'a1217': 'TS_qxgl',
    'a1218': 'TS_ztts',
}


def raw_get(path):
    r = urllib.request.Request(prp.BASE + path)
    r.add_header('Authorization', 'Bearer ' + prp.TOKEN)
    with urllib.request.urlopen(r, timeout=120) as resp:
        return resp.read()


def upload_zip(data):
    boundary = '----wkz%d' % int(time.time() * 1000)
    body = io.BytesIO()
    body.write(('--%s\r\nContent-Disposition: form-data; name="file"; filename="model.zip"\r\n'
                'Content-Type: application/zip\r\n\r\n' % boundary).encode())
    body.write(data)
    body.write(('\r\n--%s--\r\n' % boundary).encode())
    r = urllib.request.Request(prp.BASE + '/workflow/model/importModel',
                               data=body.getvalue(), method='POST')
    r.add_header('Authorization', 'Bearer ' + prp.TOKEN)
    r.add_header('Content-Type', 'multipart/form-data; boundary=' + boundary)
    with urllib.request.urlopen(r, timeout=120) as resp:
        return json.loads(resp.read().decode() or '{}')


def process(old_key, new_key):
    print('=== %s -> %s' % (old_key, new_key))
    ms = [m for m in prp.models() if m['modelKey'] == old_key]
    if not ms:
        print('  !! 找不到模型', old_key)
        return None
    mid = ms[0]['modelId']
    data = raw_get('/workflow/model/exportModel?modelId=' + mid)
    zin = zipfile.ZipFile(io.BytesIO(data))
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as zout:
        for name in zin.namelist():
            content = zin.read(name)
            if name.endswith('entity.xml'):
                s = content.decode('utf-8')
                assert old_key in s, 'entity.xml 里没有 %s' % old_key
                content = s.replace(old_key, new_key).encode('utf-8')
            else:
                # bpmn：文件名和内容都换
                new_name = name.replace(old_key, new_key)
                content = content.decode('utf-8').replace(old_key, new_key).encode('utf-8')
                name = new_name
            zout.writestr(name, content)
    out_path = os.path.join(OUT, '%s.zip' % new_key)
    open(out_path, 'wb').write(buf.getvalue())
    print('  导出并改写 ->', out_path, '(%d bytes)' % buf.tell())
    return out_path, mid


def main():
    apply = '--apply' in sys.argv
    keys = [k for k in sys.argv[1:] if k in RENAME] or list(RENAME)
    plan = []
    for old in keys:
        r = process(old, RENAME[old])
        if r:
            plan.append((old, RENAME[old], r[0], r[1]))
    if not apply:
        print('\n[dry] 加 --apply 才导入')
        return
    for old, new, zp, old_mid in plan:
        r = upload_zip(open(zp, 'rb').read())
        print('  import %s ->' % new, r.get('code'), r.get('msg'))
        time.sleep(6)
    # 验证 + 发布
    time.sleep(2)
    for old, new, zp, old_mid in plan:
        ms = [m for m in prp.models() if m['modelKey'] == new]
        if not ms:
            print('  !! %s 未落地' % new)
            continue
        mid = ms[0]['modelId']
        print('  %s: modelId=%s name=%s' % (new, mid, ms[0]['modelName']))
        st, r = prp.req('POST', '/workflow/model/deploy', {'modeId': mid})
        print('  deploy ->', st, r.get('code'), r.get('msg'))
        time.sleep(4)


if __name__ == '__main__':
    main()
