# -*- coding: utf-8 -*-
"""把平台上的动态表单绑定到流程的「起始表单」（PC + 移动端）。

表单绑定存在两处，平台是同一份数据：
  读  GET  /apis/workflow/model/{modelId}   -> data.wfDesignAttribute.startFormId
  存  POST /apis/workflow/model/save         （整个 data 原样回传，只改两个字段）

表单可选项 GET /apis/workflow/form/data -> data.<组>[] = {code, value}
  code = 表单 ID，value = 表单名
校验单个表单 GET /apis/dynamic/form/attribute/{id}，不存在返回 code:900「表单不存在」。

formType 恒为 "0"（流程设计器表单）。
⚠️ save 会把 BPMN 里的 waypoint 坐标**取整**（x="183.2" -> "183.0"），
   所以校验不能拿导出包的 XML 字节一致当依据。

用法:
  export PRP_HOST=http://98.87.119.14
  export PRP_TOKEN=xxx
  python scripts/bind_form.py --list
  python scripts/bind_form.py --check
  python scripts/bind_form.py --flow PRP_CGLX --form fa0d6ad38e9acae8c3d5689e7c8262e9
  python scripts/bind_form.py --flow PRP_CGLX --auto
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import prp_env as E          # noqa: E402


def form_options():
    """[(表单ID, 表单名)]，平台按组返回，摊平。"""
    st, d = E.get("/workflow/form/data")
    out = []
    for v in (d.get("data") or {}).values():
        if isinstance(v, list):
            for x in v:
                if x.get("code"):
                    out.append((x["code"], str(x.get("value") or "").strip()))
    return out


def bind(model_id, form_id, dry=False):
    st, d = E.get("/workflow/model/" + model_id)
    data = d.get("data") or {}
    if not data.get("wfDesignAttribute"):
        raise SystemExit("取不到 wfDesignAttribute，modelId 可能不对")
    old = data["wfDesignAttribute"].get("startFormId")
    data["wfDesignAttribute"]["startFormId"] = form_id
    data["wfDesignAttribute"]["phoneStartFormId"] = form_id
    if dry:
        print("  [dry] %s -> %s" % (old, form_id))
        return True
    st, r = E.post("/workflow/model/save", data)
    ok = (r.get("code") == 200)
    print("  %s %s -> %s" % ("OK " if ok else "!! ", old, form_id))
    if not ok:
        print("      ", str(r)[:200])
    return ok


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--flow")
    ap.add_argument("--form")
    ap.add_argument("--auto", action="store_true")
    ap.add_argument("--dry", action="store_true")
    a = ap.parse_args()

    if a.list:
        for c, n in sorted(form_options(), key=lambda x: x[1]):
            print("%-34s %s" % (c, n))
        return

    if a.check:
        byname = {}
        for c, n in form_options():
            byname.setdefault(n, c)
        recs = E.models()
        hit = [(r["modelKey"], r["modelName"], byname[r["modelName"].strip()])
               for r in recs if r["modelName"].strip() in byname]
        print("流程 %d 张，能按同名对上表单的 %d 张:" % (len(recs), len(hit)))
        for k, n, c in hit:
            print("  %-12s %-28s %s" % (k, n, c))
        miss = [r["modelName"] for r in recs if r["modelName"].strip() not in byname]
        print("\n还没建表单的 %d 张: %s" % (len(miss), "、".join(miss)))
        return

    if not a.flow:
        ap.error("需要 --flow，或使用 --list / --check")
    recs = E.models()
    m = next((r for r in recs if r["modelKey"] == a.flow), None)
    if not m:
        raise SystemExit("没找到流程 " + a.flow)
    print("%s  %s  modelId=%s" % (m["modelKey"], m["modelName"], m["modelId"]))

    if a.auto:
        byname = {}
        for c, n in form_options():
            byname.setdefault(n, c)
        fid = byname.get(m["modelName"].strip())
        if not fid:
            raise SystemExit("没有同名表单，先用 --list 找，再 --form 指定")
        print("  自动匹配表单: %s" % fid)
    else:
        fid = a.form
        if not fid:
            ap.error("需要 --form 或 --auto")
        st, chk = E.get("/dynamic/form/attribute/" + fid)
        if chk.get("code") != 200:
            raise SystemExit("表单不存在: %s (%s)" % (fid, chk.get("msg")))

    ok = bind(m["modelId"], fid, a.dry)
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
