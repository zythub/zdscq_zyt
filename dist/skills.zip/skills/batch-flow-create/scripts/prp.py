# -*- coding: utf-8 -*-
"""1103 prp 平台接口小工具（所有排查脚本共用）"""
import json, urllib.request, urllib.error

BASE = 'http://172.19.18.223:1103/apis'
TOKEN = '132db4a6753b251914ab1670685af914'


def req(method, path, body=None, timeout=90):
    data = json.dumps(body, ensure_ascii=False).encode() if body is not None else None
    r = urllib.request.Request(BASE + path, data=data, method=method)
    r.add_header('Authorization', 'Bearer ' + TOKEN)
    r.add_header('Content-Type', 'application/json')
    r.add_header('language', 'zh_CN')
    r.add_header('platform', 'pc')
    r.add_header('accesstype', '1')
    try:
        with urllib.request.urlopen(r, timeout=timeout) as resp:
            return resp.status, json.loads(resp.read().decode() or '{}')
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read().decode() or '{}')
        except Exception:
            return e.code, {}


def get(path, **kw):
    return req('GET', path, **kw)


def models(page_size=400):
    st, d = req('GET', '/workflow/model/list?pageSize=%d' % page_size)
    return (d.get('data') or {}).get('records') or []


def node_user(model_id, node_id):
    st, d = req('GET', '/workflow/design-node-user/list/%s/%s' % (model_id, node_id))
    return d.get('data') or {}


if __name__ == '__main__':
    for m in models():
        print(m['modelId'], m['modelKey'], m['modelName'])
