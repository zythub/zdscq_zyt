# -*- coding: utf-8 -*-
"""bestdt 平台接口公共模块：环境配置 + 请求封装 + 模型/表单工具。

所有 PRP 迁移脚本共用这个文件。换环境只改这里（或用环境变量覆盖）。

  export PRP_HOST=http://98.87.119.14
  export PRP_TOKEN=xxxx
  export PRP_CATEGORY=501634ee51dc5ffd37f724a179788f8a

接口前缀固定 /apis；认证头 `authorization: Bearer <token>` + `accesstype: 1`。
"""
import io
import json
import os
import subprocess
import time
import urllib.error
import urllib.request
import uuid
import zipfile

# ----------------------------------------------------------------- 环境配置
BASE = os.environ.get("PRP_HOST", "http://98.87.119.14")
TOKEN = os.environ.get("PRP_TOKEN", "")
CATEGORY = os.environ.get("PRP_CATEGORY", "501634ee51dc5ffd37f724a179788f8a")
API = BASE.rstrip("/") + "/apis"

# importModel 防重复提交，实测要间隔 6~8s
IMPORT_GAP = 6


# ------------------------------------------------------------------- 请求
def _headers(extra=None):
    h = {"authorization": "Bearer " + TOKEN, "accesstype": "1",
         "language": "zh_CN", "platform": "pc"}
    if extra:
        h.update(extra)
    return h


def req(method, path, body=None, timeout=90, raw=False):
    """返回 (status, dict) 或 (status, bytes) —— raw=True 时返回原始字节。"""
    data = None
    hdr = _headers()
    if body is not None:
        if isinstance(body, (bytes, bytearray)):
            data = bytes(body)
        else:
            data = json.dumps(body, ensure_ascii=False).encode("utf-8")
            hdr["Content-Type"] = "application/json"
    url = path if path.startswith("http") else API + path
    r = urllib.request.Request(url, data=data, method=method)
    for k, v in hdr.items():
        r.add_header(k, v)
    try:
        with urllib.request.urlopen(r, timeout=timeout) as resp:
            content = resp.read()
            if raw:
                return resp.status, content
            try:
                return resp.status, json.loads(content.decode("utf-8") or "{}")
            except Exception:
                return resp.status, {"raw": content[:500].decode("utf-8", "replace")}
    except urllib.error.HTTPError as e:
        content = e.read()
        if raw:
            return e.code, content
        try:
            return e.code, json.loads(content.decode("utf-8") or "{}")
        except Exception:
            return e.code, {"raw": content[:500].decode("utf-8", "replace")}
    except Exception as e:
        return 0, {"error": str(e)}


def get(path, **kw):
    return req("GET", path, **kw)


def post(path, body=None, **kw):
    return req("POST", path, body, **kw)


def put(path, body=None, **kw):
    return req("PUT", path, body, **kw)


def curl_get(path, timeout=90):
    """用 curl 发 GET（导出 zip 这类大响应更稳）。"""
    url = path if path.startswith("http") else API + path
    out = subprocess.run(["curl", "-s", url,
                          "-H", "authorization: Bearer " + TOKEN,
                          "-H", "accesstype: 1", "--max-time", str(timeout)],
                         capture_output=True).stdout
    return out


# ------------------------------------------------------------------- 模型
def models(page_size=500):
    st, d = get("/workflow/model/list?currentPage=1&pageSize=%d" % page_size)
    return (d.get("data") or {}).get("records") or []


def model_by_key(key):
    for r in models():
        if r.get("modelKey") == key:
            return r
    return None


def export_model(model_id):
    """导出流程包 zip 字节流。"""
    return curl_get("/workflow/model/exportModel?modelId=" + model_id, timeout=120)


def read_package(blob):
    """拆流程包 -> (namelist, {name: bytes}, bpmn文件名, bpmn文本, entity文本)"""
    z = zipfile.ZipFile(io.BytesIO(blob))
    names = z.namelist()
    xn = [n for n in names if n.endswith(".xml") and "entity" not in n.lower()][0]
    return (names,
            {n: z.read(n) for n in names},
            xn,
            z.read(xn).decode("utf-8"),
            z.read("entity.xml").decode("utf-8"))


def import_zip(blob, filename, tries=5):
    """POST /workflow/model/importModel（multipart，字段名 file）。
    返回 (ok, 响应文本)。对已存在 modelKey 是幂等覆盖。"""
    resp = ""
    for i in range(tries):
        boundary = "----WebKitFormBoundary" + uuid.uuid4().hex[:16]
        body = b"".join([
            ("--%s\r\n" % boundary).encode(),
            ('Content-Disposition: form-data; name="file"; filename="%s"\r\n'
             % filename).encode(),
            b"Content-Type: application/zip\r\n\r\n",
            blob,
            ("\r\n--%s--\r\n" % boundary).encode(),
        ])
        st, content = req("POST", "/workflow/model/importModel", body,
                          timeout=180, raw=True)
        resp = content.decode("utf-8", "replace")
        if '"code":200' in resp:
            return True, resp
        time.sleep(1.5 * (i + 1))
    return False, resp


def rebuild_package(names, data_map, bpmn_name, new_bpmn_name, new_entity):
    """按目标分类重打包。"""
    out = io.BytesIO()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as w:
        for n in names:
            if n == "entity.xml":
                w.writestr(n, new_entity.encode("utf-8"))
            elif n == bpmn_name:
                w.writestr(new_bpmn_name, data_map[n])
            else:
                w.writestr(n, data_map[n])
    return out.getvalue()


# ------------------------------------------------------------------- 表单
def form_map():
    """{表单名: 表单ID} —— 平台「起始表单」可选列表。"""
    st, d = get("/workflow/form/data")
    out = {}
    for v in (d.get("data") or {}).values():
        if isinstance(v, list):
            for x in v:
                if x.get("code"):
                    out.setdefault(str(x.get("value") or "").strip(), x["code"])
    return out


def form_exists(form_id):
    st, d = get("/dynamic/form/attribute/" + form_id)
    return d.get("code") == 200


def known_form_ids():
    """线上真实存在的表单 ID 集合。"""
    return set(form_map().values())


# ------------------------------------------------------------------- 分类
def categories():
    st, d = get("/workflow/category/listAll")
    return d.get("data") or []


if __name__ == "__main__":
    print("BASE   :", BASE)
    print("TOKEN  :", (TOKEN[:6] + "...") if TOKEN else "(空)")
    print("分类   :", CATEGORY)
    ms = models()
    print("模型数 :", len(ms))
    for m in ms[:20]:
        print("   ", m["modelKey"], m["modelName"], m["modelId"])
