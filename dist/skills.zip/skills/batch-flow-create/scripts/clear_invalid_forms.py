# -*- coding: utf-8 -*-
"""统一清理流程包里指向「不存在表单」的引用。

背景：批量迁移过来的流程，起始表单 / 节点表单还指向**源环境**的表单 ID
（老环境的表单在新环境不存在，GET /apis/dynamic/form/attribute/{id} 返回
 code=900「表单不存在」）。后果：
  - 设计器打开流程，起始表单是坏的
  - 发布后发起流程会因为找不到表单而失败
  - 前端属性面板加载不出节点信息

处理原则：**表单不存在的引用一律清空**，而不是保留一个坏 ID。
表单建好之后用 bind_form.py / bind_node_forms.py 再绑回去。

清理范围（4 处）：
  attr 层      startFormId / phoneStartFormId
  nodeAttrs 层 nodeFormId / phoneNodeFormId（只动 userTask 条目）
  nodeForms 层 formId（节点表单记录）

判定「表单存在」的口径：
  1. 在 GET /apis/workflow/form/data 的可选表单 code 集合里 -> 一定存在
  2. 不在集合里，再查 GET /apis/dynamic/form/attribute/{id}
     （200 = 存在，900 = 不存在）
  两步都判不存在才清空，避免误删「存在但没进可选列表」的表单。

用法：
  export PRP_HOST=http://98.87.119.14
  export PRP_TOKEN=xxx
  python scripts/clear_invalid_forms.py --dry
  python scripts/clear_invalid_forms.py
  python scripts/clear_invalid_forms.py --model PRP_15776
"""
import argparse
import io
import os
import re
import sys
import time
import zipfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import prp_env as E          # noqa: E402

ATTR_FORMS = ("startFormId", "phoneStartFormId")
NODE_FORMS = ("nodeFormId", "phoneNodeFormId")


def form_exists(fid, known):
    if fid in known:
        return True
    if not fid:
        return False
    try:
        st, d = E.get("/dynamic/form/attribute/" + fid)
        return d.get("code") == 200
    except Exception:
        return True          # 查不到就保守认为存在，别误删


def _prop_value(ent, prop):
    m = re.search(r'property="%s">\s*<string>([^<]*)</string>' % prop, ent)
    return m.group(1) if m else None


def _set_prop(ent, prop, val):
    pat = r'(property="%s">\s*<string>)[^<]*(</string>)' % prop
    if not re.search(pat, ent):
        return ent, False
    new = re.sub(pat, lambda m: m.group(1) + val + m.group(2), ent)
    return new, new != ent


def _iter_entries(ent):
    """遍历 entity 里每个 <void method="add"> 块，产出 (start, end, seg)。"""
    i = ent.find('<void method="add">')
    while i >= 0:
        vo = ent.find("<object", i)
        if vo < 0:
            break
        depth = 0
        end = None
        for mm in re.finditer(r"<object\b[^>]*/>|<object\b|</object>", ent[vo:]):
            tok = mm.group(0)
            if tok.endswith("/>"):
                continue
            if tok.startswith("</"):
                depth -= 1
                if depth == 0:
                    end = vo + mm.end()
                    break
            else:
                depth += 1
        if end is None:
            break
        yield i, end, ent[i:end]
        i = ent.find('<void method="add">', end)


def clean_entity(ent, known, log):
    """清掉指向不存在表单的引用，返回 (entity, 是否改动)。"""
    changed = False
    for prop in ATTR_FORMS:
        v = _prop_value(ent, prop)
        if v and not form_exists(v, known):
            ent, ch = _set_prop(ent, prop, "")
            changed |= ch
            if ch:
                log.append("清空 %s（原 %s，表单不存在）" % (prop, v))

    # nodeAttrs：只动 WfDesignNodeAttribute（连线条目不动）
    for prop in NODE_FORMS:
        edits = []
        for s, e, seg in _iter_entries(ent):
            if "WfDesignNodeAttribute" not in seg:
                continue
            v = _prop_value(seg, prop)
            if v and not form_exists(v, known):
                seg2, ch = _set_prop(seg, prop, "")
                if ch:
                    log.append("清空 %s @ %s（原 %s）" %
                               (prop, _prop_value(seg, "nodeId") or "?", v))
                    changed = True
                    edits.append((s, e, seg2))
        for s, e, seg in reversed(edits):
            ent = ent[:s] + seg + ent[e:]

    # nodeForms：整条记录都绑着无效表单
    edits = []
    for s, e, seg in _iter_entries(ent):
        if "WfDesignNodeForm" not in seg:
            continue
        v = _prop_value(seg, "formId")
        if v and not form_exists(v, known):
            seg2, ch = _set_prop(seg, "formId", "")
            if ch:
                log.append("清空 nodeForms.formId @ %s（原 %s）" %
                           (_prop_value(seg, "nodeId") or "?", v))
                changed = True
                edits.append((s, e, seg2))
    for s, e, seg in reversed(edits):
        ent = ent[:s] + seg + ent[e:]

    return ent, changed


def handle(rec, known, dry=False):
    key = rec["modelKey"]
    blob = E.export_model(rec["modelId"])
    names, data, xn, xml, ent = E.read_package(blob)
    log = []
    new_ent, changed = clean_entity(ent, known, log)
    if not changed:
        print("  %-14s 无需改动" % key)
        return True
    if dry:
        print("  %-14s %s" % (key, "；".join(log[:6]) + ("…" if len(log) > 6 else "")))
        return True
    packed = E.rebuild_package(names, data, xn,
                               "%s#&%s#&xml.xml" % (key, E.CATEGORY), new_ent)
    ok, resp = E.import_zip(packed, key + ".zip")
    print("  %-14s %-4s %s" % (key, "OK" if ok else "!!",
                               "；".join(log[:3]) + ("…" if len(log) > 3 else "")))
    if not ok:
        print("      ", resp[:200])
    return ok


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry", action="store_true")
    ap.add_argument("--model")
    a = ap.parse_args()

    known = E.known_form_ids()
    recs = E.models()
    if a.model:
        recs = [r for r in recs if r["modelKey"] == a.model]
    print("处理 %d 个流程（线上表单 %d 张）%s"
          % (len(recs), len(known), "  [dry]" if a.dry else ""))
    bad = 0
    for rec in sorted(recs, key=lambda x: x["modelKey"]):
        try:
            if not handle(rec, known, a.dry):
                bad += 1
        except Exception as ex:
            print("  %-14s !! %s" % (rec["modelKey"], ex))
            bad += 1
        if not a.dry:
            time.sleep(E.IMPORT_GAP)
    print("完成，失败 %d 个" % bad)
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
