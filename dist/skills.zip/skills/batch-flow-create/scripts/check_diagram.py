# -*- coding: utf-8 -*-
"""线上流程图几何批量体检。

逐张导出线上模型，跑 diagram.check，输出「尺寸错 / 端点偏 / 斜线 / 穿节点」统计表。
这是判断「线偏移」的第一道关口——尺寸错 = 必偏移。

  export PRP_HOST=http://98.87.119.14
  export PRP_TOKEN=xxx
  python scripts/check_diagram.py
  python scripts/check_diagram.py --model PRP_CGLX
  python scripts/check_diagram.py --fix --model PRP_48267     # 自动修并回写
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import prp_env as E          # noqa: E402
import diagram as D          # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", help="只查某个 modelKey")
    ap.add_argument("--fix", action="store_true", help="自动修并回写线上")
    ap.add_argument("--quiet", action="store_true", help="只打印有问题的")
    a = ap.parse_args()

    recs = E.models()
    if a.model:
        recs = [r for r in recs if r["modelKey"] == a.model]

    print("体检 %d 个流程（标准：userTask 90x60 / 事件 36x36 / 端点贴边 / 全正交 / 不穿节点）\n" % len(recs))
    tot = {"size": 0, "anchor": 0, "diag": 0, "cross": 0, "zero": 0}
    rows = []
    for r in sorted(recs, key=lambda x: x["modelKey"]):
        key = r["modelKey"]
        try:
            blob = E.export_model(r["modelId"])
            names, data, xn, xml, ent = E.read_package(blob)
        except Exception as ex:
            print("  %-14s !! 导出失败 %s" % (key, ex))
            continue
        rep = D.check(xml)
        s = rep["summary"]
        for k in tot:
            tot[k] += s[k]
        bad = s["size"] or s["anchor"] or s["diag"] or s["zero"]
        rows.append((key, s, bad))
        if a.quiet and not bad:
            continue
        print("  %-14s %-4s 线%3d | 尺寸错%2d 端点偏%2d 斜线%2d 穿节点%2d 无点%2d"
              % (key, "OK" if not bad else "!!", s["flows"],
                 s["size"], s["anchor"], s["diag"], s["cross"], s["zero"]))
        for x in rep["size"][:4]:
            print("        尺寸 %s %s 实际%s 期望%s" % x)
        for x in rep["anchor"][:4]:
            print("        端点 %s %s @%s 偏 dx=%s dy=%s" % x)
        for x in rep["diag"][:3]:
            print("        斜线 %s 段%s" % x)
        if a.fix and bad:
            new_xml, fixrep = D.normalize(xml)
            if fixrep["resized"] or fixrep["reanchored"] or fixrep["ortho"]:
                packed = E.rebuild_package(
                    names, data, xn,
                    "%s#&%s#&xml.xml" % (key, E.CATEGORY), ent)
                # 把新 BPMN 写回包里
                import io
                import zipfile
                out = io.BytesIO()
                with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as w:
                    for n in names:
                        if n == "entity.xml":
                            w.writestr(n, ent.encode("utf-8"))
                        elif n == xn:
                            w.writestr("%s#&%s#&xml.xml" % (key, E.CATEGORY),
                                       new_xml.encode("utf-8"))
                        else:
                            w.writestr(n, data[n])
                ok, resp = E.import_zip(out.getvalue(), key + ".zip")
                print("        修复：改尺寸%d 重吸附%d 正交%d -> 导入%s"
                      % (len(fixrep["resized"]), len(fixrep["reanchored"]),
                         len(fixrep["ortho"]), "OK" if ok else "失败 " + resp[:80]))

    print("\n=== 汇总 ===")
    print("尺寸错 %d / 端点偏 %d / 斜线 %d / 穿节点 %d / 无点 %d"
          % (tot["size"], tot["anchor"], tot["diag"], tot["cross"], tot["zero"]))
    bad_rows = [x for x in rows if x[2]]
    if bad_rows:
        print("有问题的流程 %d 张：%s" % (len(bad_rows), ", ".join(x[0] for x in bad_rows)))
    else:
        print("全部合格 ✅")


if __name__ == "__main__":
    main()
