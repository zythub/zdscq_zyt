# -*- coding: utf-8 -*-
"""线生命周期状态批量设置（通用版，自动识别线清单）
   规则：target=endEvent 的那条线=已完成(finish)，其余全部=流程中(going)。
   契约（2026-10-30 抓包）：PUT /workflow/design-node-attribute/addAndEdit
     body = {modelId, nodeId, xml:<BPMN全文>, bo:{nodeKey,nodeId,modelId,nodeName,lifeCycleState,...}}
   注意：键名是 xml 不是 bpmnXml；状态在 bo 嵌套对象里；平铺写会被「模型主键ID为空」拦截。
   用法: python fix_lifecycle.py <modelId>   （需同目录 prp.py 配好环境）
"""
import json, re, sys, time
import xml.etree.ElementTree as ET
import prp

B = 'http://www.omg.org/spec/BPMN/20100524/MODEL'

MODEL_ID = sys.argv[1]
st, r = prp.get('/workflow/model/' + MODEL_ID)
bpmn = r['data']['bpmnXml']
root = ET.fromstring(bpmn)
proc = root.find('.//{%s}process' % B)
end_id = proc.find('{%s}endEvent' % B).get('id')
flows = [(f.get('id'), f.get('sourceRef'), f.get('targetRef'), f.get('name') or '')
         for f in proc.findall('{%s}sequenceFlow' % B)]
print('线 %d 条，结束前一条= %s' % (len(flows), next(f[0] for f in flows if f[2] == end_id)))

fixed, skipped, fail = 0, 0, []
for fid, src, dst, fname in flows:
    target = 'FlowTemplateStates-flowstate-finish' if dst == end_id else 'FlowTemplateStates-flowstate-going'  # 所有进结束的线都=已完成
    st, cur = prp.get('/workflow/design-node-attribute/list/%s/%s' % (MODEL_ID, fid))
    d = cur.get('data')
    if d and d.get('lifeCycleState') == target:
        skipped += 1
        continue
    bo = {
        'nodeKey': fid, 'modelId': MODEL_ID, 'nodeId': fid,
        'nodeName': fname, 'nodeProgress': None, 'messageType': '',
        'nodeUserSingle': '0', 'nodeMustOpinion': '0', 'selectUserSingleton': '0',
        'submitMustUser': '0', 'childTable': '', 'childField': '', 'parentField': '',
        'taskInstName': '["${InstNameKey}"]', 'autoAgree': '0', 'openRevoke': '1',
        'confirmcopyMessageType': '', 'doCopy': '0', 'remark': '', 'sortNum': None,
        'lifeCycleState': target, 'messageApitypeJson': '',
    }
    st, rr = prp.req('PUT', '/workflow/design-node-attribute/addAndEdit',
                     {'modelId': MODEL_ID, 'nodeId': fid, 'xml': bpmn, 'bo': bo})
    if rr.get('code') == 200:
        fixed += 1
    else:
        fail.append((fid, json.dumps(rr, ensure_ascii=False)[:120]))
    time.sleep(0.4)
print('设置 %d，跳过 %d，失败 %d' % (fixed, skipped, len(fail)))
if fail:
    print(json.dumps(fail, ensure_ascii=False))
    raise SystemExit(1)

time.sleep(5)
st, r2 = prp.req('POST', '/workflow/model/deploy', {'modeId': MODEL_ID})
print('deploy ->', r2.get('code'), r2.get('msg'))
time.sleep(6)

bad = []
for fid, src, dst, fname in flows:
    want = 'finish' if dst == end_id else 'going'
    st, cur = prp.get('/workflow/design-node-attribute/list/%s/%s' % (MODEL_ID, fid))
    got = ((cur.get('data') or {}).get('lifeCycleState') or '')
    if want not in got:
        bad.append((fid, got or '无行'))
print('复核: %d/%d 正确' % (len(flows) - len(bad), len(flows)))
if bad:
    print(json.dumps(bad, ensure_ascii=False))
    raise SystemExit(1)
