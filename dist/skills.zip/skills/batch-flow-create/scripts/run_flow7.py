# -*- coding: utf-8 -*-
"""7 张表统一流程测试：建数据 → 发起 → 走 4 节点 → 验证日期回填/状态

用法: python run_flow7.py [key ...]   key ∈ gcdb dbzc ydgl tsd qxgl ztts dtts
"""
import json, os, sys, time, uuid
from datetime import date
import prp

CFG = {
    'gcdb': dict(func='TS_gcdb', form='7390e6eb320788f67b48786287eed104', table='tts_gcdb_cybyd', bfield='number', model='TS_gcdb'),
    'dbzc': dict(func='TS_dbzc', form='fd740e456753081832cf9869fad71060', table='tts_dbzc',        bfield='bh',     model='TS_dbzc'),
    'ydgl': dict(func='TS_ydgl', form='5bcafee0aa894c93dc4a4d6fe1d8b204', table='tts_ydsq',        bfield='bh',     model='TS_ydgl'),
    'tsd':  dict(func='TS_tsd',  form='bba965a26c6c37bcfbed76e99bf0a2fe', table='tts_tsdgl',       bfield='bh',     model='TS_tsd'),
    'qxgl': dict(func='TS_qxgl', form='e8e8bda8e043329094912a7f3e023b4e', table='tts_qxgl',        bfield='bh',     model='TS_qxgl'),
    'ztts': dict(func='TS_ztts', form='3fc319030c744637a312347d33dc15b5', table='tts_ztts',        bfield='bh',     model='TS_ztts'),
    'dtts': dict(func='TS_dtts', form='d610096003c7d9185a8e1eedcee55846', table='tts_dtts',        bfield='bh',     model='TS_dtts'),
}


def latest_def(form_id, model_key):
    st, r = prp.get('/workflow/process/flowDefInfoList?formId=%s&formType=0' % form_id)
    best, bv = None, -1
    for x in (r.get('data') or []):
        pid = str(x.get('procdefId') or '')
        if not pid.startswith(model_key + ':'):
            continue
        try:
            v = int(pid.split(':')[1])
        except (IndexError, ValueError):
            v = 0
        if v > bv:
            best, bv = pid, v
    return best


def save_record(fn_id, table, bfield, bh, form_id):
    st, r = prp.get('/dynamic/form/field/' + form_id)
    fields = [x for x in (r.get('data') or [])
              if not x.get('subForm') and x.get('bindingTable') == table]
    row = {x['bindingField']: None for x in fields}
    row.pop('sys_deleteflag', None)
    new_id = uuid.uuid4().hex
    row['id'] = new_id
    row[bfield] = bh
    body = {table: row}
    st, r = prp.req('POST', '/dynamic/form/scheme/data/%s' % fn_id, body)
    return new_id, st, r


def read_record(fn_id, data_id):
    st, r = prp.get('/dynamic/form/scheme/data/%s/%s' % (fn_id, data_id))
    d = r.get('data') or {}
    out = {}
    mt = d.get('mainTable') or {}
    if mt:
        out[mt['table']] = {x['field']: x.get('value') for x in (mt.get('mainData') or [])}
    for s in d.get('subTable') or []:
        out[s['table']] = [{c['field']: c.get('value') for c in row}
                           for row in (s.get('subData') or [])]
    return out


def todo(ins):
    st, r = prp.get('/workflow/process/todoList?currentPage=1&pageSize=200')
    return [x for x in ((r.get('data') or {}).get('records') or [])
            if x.get('procInsId') == ins]


def run_one(key, bh_fixed=None):
    cfg = CFG[key]
    print('=' * 66)
    print('[%s] %s / %s' % (key, cfg['model'], cfg['table']))

    st, r = prp.get('/dynamic/function/' + cfg['func'])
    fn = (r.get('data') or {}).get('id')
    if not fn:
        print('  !! 找不到功能 %s: %s' % (cfg['func'], json.dumps(r, ensure_ascii=False)[:150]))
        return None
    proc = latest_def(cfg['form'], cfg['model'])
    if not proc:
        print('  !! 找不到已部署流程定义')
        return None
    print('  function=%s procdef=%s' % (fn, proc))

    bh = bh_fixed or ('FT-%s-%s' % (key.upper(), time.strftime('%H%M%S')))
    data_id, st, r = save_record(fn, cfg['table'], cfg['bfield'], bh, cfg['form'])
    ok = (st == 200 and r.get('code') == 200)
    print('  建数据 %s -> %s %s %s | id=%s' % (bh, st, r.get('code'), (r.get('msg') or ''), data_id))
    if not ok:
        print('   ', json.dumps(r, ensure_ascii=False)[:300])
        return None

    time.sleep(1)
    dict_data = read_record(fn, data_id)
    st, r = prp.req('POST', '/workflow/process/start/' + proc,
                    {'processDefId': proc, 'dictData': dict_data,
                     'nextUserIds': '', 'copyUserIds': '', 'comment': 'AI 批量测试发起'})
    print('  发起 ->', st, r.get('code'), r.get('msg'))
    if r.get('code') != 200:
        print('   ', json.dumps(r, ensure_ascii=False)[:300])
        return None
    ins = r['data']

    for step in range(1, 5):
        time.sleep(1.5)
        ts = todo(ins)
        if not ts:
            print('  第%d步：无待办（流程已结束）' % step)
            break
        t = ts[0]
        st, r2 = prp.req('POST', '/workflow/task/complete',
                         {'taskId': t['taskId'], 'procInsId': ins,
                          'comment': '同意(%s)' % t.get('taskName'),
                          'nextUserIds': '', 'copyUserIds': '', 'buttonCode': 'agree'})
        ok2 = (st == 200 and r2.get('code') == 200)
        print('  第%d步 %-12s complete -> %s %s' % (step, t.get('taskName'), r2.get('code'), (r2.get('msg') or '')[:60]))
        if not ok2:
            print('   ', json.dumps(r2, ensure_ascii=False)[:300])
            return {'key': key, 'dataId': data_id, 'ins': ins, 'ok': False}
    time.sleep(1.5)

    row = read_record(fn, data_id).get(cfg['table']) or {}
    today = date.today().isoformat()
    dates = {f: row.get(f) for f in ('sgdw_date', 'jldw_date', 'gcbzr_date')}
    dates_ok = all(str(v or '').startswith(today) for v in dates.values())
    biz = str(row.get('flow_bizstate') or '')
    biz_finish = biz.endswith('finish')
    print('  验证: bh=%s startflag=%s bizstate=%s dates=%s [%s]' % (
        row.get(cfg['bfield']), row.get('flow_startflag'), row.get('flow_bizstate'),
        dates, 'OK' if dates_ok and biz_finish else 'FAIL'))
    return {'key': key, 'dataId': data_id, 'ins': ins, 'bh': bh,
            'ok': bool(dates_ok and biz_finish),
            'row': {k: row.get(k) for k in (cfg['bfield'], 'flow_startflag', 'flow_bizstate')}, 'dates': dates}


def main():
    keys = [k for k in sys.argv[1:] if k in CFG] or list(CFG)
    bh_fixed = os.environ.get('BH') or None
    results = []
    for k in keys:
        try:
            results.append(run_one(k, bh_fixed) or {'key': k, 'ok': False})
        except Exception as e:
            print('  !! 异常:', repr(e)[:200])
            results.append({'key': k, 'ok': False, 'err': str(e)})
        time.sleep(2)
    print('\n' + '=' * 66)
    print('汇总:')
    for x in results:
        print('  %-5s %s %s' % (x['key'], 'PASS' if x.get('ok') else 'FAIL',
                                json.dumps({k: v for k, v in x.items() if k in ('bh', 'dataId', 'ins', 'err')}, ensure_ascii=False)))
    json.dump(results, open('capture/flow7_results.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)


if __name__ == '__main__':
    main()
