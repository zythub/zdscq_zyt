# 节点属性规范（nodeAttrs）+ 流程包 entity.xml 结构

> 适用：bestdt 平台上**所有**流程模型的节点基础属性配置。
> 这份规格是 2026-11-03 对着平台自带正常流程（缺陷管理 `TS_qxgl`）逐字段比对出来的，
> 是「能发布 / 设计器能显示节点 ID / 节点能绑表单」的最低要求。

---

## 一、nodeAttrs 必须带的 8 个字段

`entity.xml` 里 `nodeAttrs`（`WfDesignNodeAttribute`）的**每一条**（尤其 userTask）必须带齐：

| 字段 | 含义 | 缺了会怎样 |
| :--- | :--- | :--- |
| `nodeFormId` | 节点绑定的表单 ID | 前端属性面板加载不出来 |
| `nodeFormType` | 节点表单类型，`0` | 同上 |
| `phoneNodeFormId` | 移动端节点表单 ID | 移动端取不到表单 |
| `phoneNodeFormType` | 移动端节点表单类型，`0` | 同上 |
| `childField` | 子流程关联字段 | 子流程场景取不到关联 |
| `childTable` | 子流程业务表 | 同上 |
| `parentField` | 主流程关联字段 | 同上 |
| `messageType` | 消息类型 | — |

**这 8 个字段缺任意一个 → 设计器右上角不显示节点 ID、属性面板打不开、发布报「节点基础属性未填写」。**

### 完整条目模板

```xml
<void method="add">
 <object class="com.best.flow.domain.WfDesignNodeAttribute">
  <void property="autoAgree"><string>0</string></void>
  <void property="childField"><string></string></void>
  <void property="childTable"><string></string></void>
  <void property="createBy"><string></string></void>
  <void property="delFlag"><string>0</string></void>
  <void property="doCopy"><string>0</string></void>
  <void property="messageType"><string></string></void>
  <void property="modelId"><string>【线上 modelId】</string></void>
  <void property="nodeFormId"><string></string></void>
  <void property="nodeFormType"><string>0</string></void>
  <void property="nodeId"><string>Activity_p1</string></void>
  <void property="nodeKey"><string>Activity_p1</string></void>
  <void property="nodeMustOpinion"><string>0</string></void>
  <void property="nodeName"><string><![CDATA[节点名]]></string></void>
  <void property="nodeType"><string>userTask</string></void>
  <void property="nodeUserSingle"><string>0</string></void>
  <void property="openRevoke"><string>1</string></void>
  <void property="parentField"><string></string></void>
  <void property="phoneNodeFormId"><string></string></void>
  <void property="phoneNodeFormType"><string>0</string></void>
  <void property="selectUserSingleton"><string>0</string></void>
  <void property="submitMustUser"><string>0</string></void>
  <void property="taskInstName"><string>["${InstNameKey}"]</string></void>
  <void property="updateBy"><string></string></void>
 </object>
</void>
```

要点：
- `nodeName` **必须与 BPMN XML 里该 userTask 的 name 一致**（不一致 → 发布报「节点名称与流程图节点名称不一致」）
- `modelId` **必须是当前线上环境的 modelId**（旧环境的写不进去，子表插不进去 —— 见第四节）
- `nodeFormId` 没有表单时写**空串**，不要写占位 ID

---

## 二、entity.xml 顶层结构

流程包（`exportModel` 导出的 zip）里有 3 个文件：

```
{modelKey}#&{categoryId}#&xml.xml   ← BPMN 2.0 XML（流程图 + 节点 + 连线）
entity.xml                          ← Java XMLDecoder 序列化的 FwDesignVo 全量设计
```

`entity.xml` 的顶层属性（都是 `java.util.ArrayList`）：

| 属性 | 内容 |
| :--- | :--- |
| `attr` | 模型基本信息：`modelId` / `modelKey` / `modelName` / `categoryId` / `startFormId` / `phoneStartFormId` / `nodeFormId`… |
| `nodeAttrs` | 节点基础属性（`WfDesignNodeAttribute`），**userTask 和每条线各一条** |
| `nodeButtons` | 节点按钮 |
| `nodeCountersigns` | 会签配置 |
| `nodeForms` | 节点表单（`WfDesignNodeForm`），`formSourceType=2` |
| `nodeIntfaces` | 节点接口 |
| `nodeSequences` | **连线**的流转条件（`WfDesignSequenceAttribute`） |
| `nodeUsers` | 节点审批人（`WfDesignNodeUser`） |
| `nodeVars` | 审批回填变量（配合 `variables`） |
| `ruleNames` | 待办标题规则 |
| `variables` | 变量定义 |

### 解析 entity.xml 的三个坑

1. **定位属性段不能找「下一个 property」**——段内嵌套很多 `<object>`，要用 `<object>` 配对计数找段尾：
   ```python
   def block_end(s, start):
       m = re.match(r"<object\b[^>]*/>", s[start:])     # 自闭合直接返回
       if m: return start + m.end()
       depth = 0
       for m in re.finditer(r"<object\b[^>]*/>|<object\b|</object>", s[start:]):
           tok = m.group(0)
           if tok.endswith("/>"): continue               # 自闭合不计深度
           if tok.startswith("</"):
               depth -= 1
               if depth == 0: return start + m.end()
           else: depth += 1
       raise ValueError("块不闭合")
   ```
2. **自闭合 ArrayList 要展开再插**：
   ```python
   m = re.search(r'(<void property="nodeAttrs">\s*)<object class="java\.util\.ArrayList"\s*/>', ent)
   a, b = p + m.end(1), p + m.end()      # 用 end(1)，别用 start(1)（会删掉 property 标签）
   ent = ent[:a] + '\n   <object class="java.util.ArrayList">\n   ' + chunks + '\n   </object>\n  ' + ent[b:]
   ```
3. **批量改多段时必须逆序回写**：`entity[:a] + 新 + entity[b:]` 会改变长度，后续条目的 `a/b` 会漂移 →
   **按位置倒序处理**，否则值会写到隔壁条目上（真实踩过：nodeFormId 被写到 `Flow_p19` 这类连线条目上）。

---

## 三、nodeForms（节点表单）

```xml
<void method="add">
 <object class="com.best.flow.domain.WfDesignNodeForm">
  <void property="createBy"><string></string></void>
  <void property="createTime"><object class="java.util.Date"><long>1793584566711</long></object></void>
  <void property="delFlag"><string>0</string></void>
  <void property="formId"><string>【表单ID】</string></void>
  <void property="formSourceType"><string>2</string></void>
  <void property="modelId"><string>【线上 modelId】</string></void>
  <void property="nodeId"><string>Activity_p1</string></void>
  <void property="updateBy"><string></string></void>
  <void property="updateTime"><object class="java.util.Date"><long>1793584566711</long></object></void>
  <void property="wfDesignNodeFormauthList"><object class="java.util.ArrayList"/></void>
 </object>
</void>
```

- **缺 `createTime` / `updateTime` → 平台导入时整条丢弃**（nodeForms 数量不涨，接口却返回成功）
- `wfDesignNodeFormauthList` 字段权限列表，没有就写空 ArrayList，**不能省掉这个属性**
- `formSourceType=2` = 流程表单

---

## 四、改包重导的唯一正确姿势

**必须从线上导出再改**，不能直接改本地模板包：

```
线上 exportModel  →  改 entity.xml  →  改包内 XML 文件名为 {modelKey}#&{分类ID}#&xml.xml
                  →  POST /apis/workflow/model/importModel（multipart，file 字段）
```

原因：
1. **包里的 `attr.modelId` 是旧环境的** → 平台用 attr.modelId 写子表，插不进去（nodeForms 加了也不生效）
2. **包内 XML 文件名带分类 ID** → 必须是**目标环境**的分类 ID，否则流程会落到别的分类
3. `importModel` 对已存在的 `modelKey` 是**幂等**的：原地覆盖，modelId 不变、数量不变（不会产生重复模型）

配套：
- 连发 importModel 会撞「请勿重复提交」，**间隔 6~8 秒**
- 自写 curl multipart 会返回「导入数据错误!」，用 `migrate_to.import_zip` 的构造方式
- 校验不能拿 XML 字节一致当依据：`POST /model/save` 会把 waypoint 坐标**取整**（`x="183.2"` → `x="183.0"`）

---

## 五、常见报错对照

| 报错 / 现象 | 根因 | 修法 |
| :--- | :--- | :--- |
| `流程模型节点[xxx]基础属性未填写！节点ID：[Activity_p12]` | 该 userTask 没有 nodeAttrs 记录（模板只有 p1..p11） | 补齐 nodeAttrs 条目 |
| `节点名称与流程图节点名称不一致` | nodeAttrs.nodeName ≠ BPMN 里该节点 name | 按 XML 纠正 nodeName |
| 设计器右上角**不显示节点 ID** | nodeAttrs 缺那 8 个表单字段 | 补齐 8 字段 |
| nodeForms 加了但数量不变 | 缺 createTime/updateTime，或 attr.modelId 是旧环境的 | 从线上导出再改 + 补时间戳 |
| `导入数据错误!`（importModel） | XMLDecoder 解析失败 / multipart 构造不对 | 用 `migrate_to.import_zip` |
| `模型主键ID不能够为空` | PUT design-node-attribute 少了 `bo` 嵌套体 | 见 SKILL.md 二·九节 |
| `Cannot invoke "Object.getClass()" because "source" is null` | 对**不存在的** nodeAttrs 记录调 addAndEdit | 平台没提供「新建节点属性」接口 → 只能改包重导 |
| `模型ID为空！！` | `POST /workflow/model/deploy` 入参不是 `{modeId: modelId}` | 发布接口不可用 → 由用户在设计器点发布 |
| 节点表单绑了但前台不生效 | 没发布（页面跑部署快照） | 改完必须重新发布 |
