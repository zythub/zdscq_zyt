# PRP 流程迁移 SOP（批量，2026-11-03 实测 36 张跑通）

> 场景：把老系统（PRP）的流程图批量迁到 bestdt 平台新环境。
> 2026-11-03：36 张流程全部迁到 `98.87.119.14`「prp迁移」分类，节点属性/审批人/几何全部统一。

---

## 一、环境与坐标

| 项 | 值 |
| :--- | :--- |
| 新环境（本项目） | `http://98.87.119.14`，API 前缀 `/apis` |
| 老环境（源） | `http://172.19.18.223:1112`（token 会过期，需重新取） |
| 分类 ID | `501634ee51dc5ffd37f724a179788f8a`（「prp迁移」） |
| 流程图渲染 | bpmn-js；userTask 90×60、事件 36×36（**宽高写别的必偏移**，见 diagram-layout.md） |

认证头：`authorization: Bearer <token>` + `accesstype: 1`

---

## 二、端到端流水线

```
① 摸底       PRP json / 老环境流程图 → 节点、连线、分支
② 解析建图   nodes/edges → 有向图，找分支点、汇聚点、回退边
③ 生成 BPMN  ActivityType 7/8 → startEvent/endEvent；1 → userTask
④ 生成 entity 节点属性 / 审批人 / 节点表单 / 线条件 / 变量 / 标题规则
⑤ 排版       蛇形折行，每行 ≤6，90×60 / 36×36
⑥ 画线       正交折线，端点吸附
⑦ 体检       diagram.py check 五项全 0 才准进下一步
⑧ 导入       exportModel(线上) → 改包 → importModel（间隔 6~8s）
⑨ 补属性     nodeAttrs 8 字段 / nodeUsers / nodeForms
⑩ 绑表单     起始表单 + 节点表单
⑪ 校验       check_nodes.py 全量
⑫ 发布       由用户在设计器点（发布接口不可用）
⑬ 跑数据     发起 → 审批 → 验证
```

---

## 三、PRP json 结构与映射

```json
{"nodes": {"nodes_rect21j85i7km0": {"x":268,"y":234,"type":"rect","ActivityType":1,
                                     "Caption":"项目经理","OID":"3edad4c3-..."}},
 "edges": {"2_edges51j85inhfn": {"source":{"id":"nodes_rect61j85id9hf","PtSrc":14},
                                "target":{"id":"nodes_rect71j85idpvg","PtDst":6},
                                "Caption":"单源","lineKind":2}}}
```

| PRP | bestdt |
| :--- | :--- |
| ActivityType 7 / 8 | `startEvent` / `endEvent` |
| ActivityType 1 | `userTask`，name 取 Caption |
| 一个节点多条出边 + Caption | 多条 `sequenceFlow` + 各自 `conditionExpression` + 线属性（**不加网关**） |
| Caption 文本（「单源」「修改反馈」） | 转 `varText`(表单字段) + `varCondition` + `varOperation`，**字段口径必须问用户** |
| 回退线（「修改反馈」→前面节点） | 普通 sequenceFlow 指回前面节点 |
| 端口 `PtSrc`/`PtDst` | 2=上 6=右 10=下 14=左（325 条连线 100% 吻合） |

**PRP 特有处理**：
- 「起草人修改」类节点（有出线无入线）是老系统驳回落点 → **一比一建出来**（孤立 userTask，
  Flowable 允许、运行时不可达不影响流转，驳回时平台可指定回到它），其出线照建；prp_build.py 已按此实现
- 节点审批人暂绑管理员（nodeUsers type=1），表单迁移后改成表单字段取人
- modelKey 临时起（如 `PRP_CGLX`），表单迁移后按「流程编号=表名」用导出副本法改名
- 分支线 Caption 先写 BPMN 线 name；**条件（design-sequence-attr）等表单迁移后再配**（没表单没法指定 `表名.字段`）

---

## 四、接口清单（实测可用）

| 用途 | 接口 |
| :--- | :--- |
| 分类列表 | `GET /apis/workflow/category/listAll` |
| 模型列表 | `GET /apis/workflow/model/list?currentPage=1&pageSize=500` |
| 读模型 | `GET /apis/workflow/model/{modelId}` |
| 存模型 | `POST /apis/workflow/model/save` |
| **导出模型** | `GET /apis/workflow/model/exportModel?modelId=` |
| **导入模型** | `POST /apis/workflow/model/importModel`（multipart，字段名 `file`） |
| 节点属性读 | `GET /apis/workflow/design-node-attribute/list/{modelId}/{nodeId}` |
| 节点属性写 | `PUT /apis/workflow/design-node-attribute/addAndEdit`（**只改已有记录**） |
| 节点表单读 | `GET /apis/workflow/design-node-form/list/{modelId}/{nodeId}` |
| **节点表单写** | `PUT /apis/workflow/design-node-form/addAndEdit` |
| 可选表单 | `GET /apis/workflow/form/data` |
| 表单详情 | `GET /apis/dynamic/form/attribute/{formId}` |
| 动态表单字段 | `GET /apis/dynamic/form/field/{formId}` |
| 线条件读 | `GET /apis/workflow/design-sequence-attr/list/{modelId}/{flowId}` |
| 线条件写 | `PUT /apis/workflow/design-sequence-attr/addAndEdit`（**body 必须带 bpmnXml**） |
| 发布列表 | `GET /apis/workflow/deploy/list` |
| 部署详情 | `GET /apis/workflow/deploy/bpmnXmlAndAttr/{defId}` |
| 发起流程 | `POST /apis/workflow/process/start/{processDefId}` |
| 审批 | `POST /apis/workflow/task/complete` |
| 可发起定义 | `GET /apis/workflow/process/flowDefInfoList?formId=&formType=0` |

---

## 五、关键载荷格式

### 节点表单绑定（`PUT design-node-form/addAndEdit`）

```json
{"modelId": "<modelId>", "nodeId": "<nodeId>", "nodeKey": "<nodeId>",
 "formId": "<formId>", "formSourceType": "2", "xml": "<BPMN 全文>",
 "wfDesignNodeFormauthList": []}
```

- `wfDesignNodeFormauthList` **必须带**（哪怕空数组），否则不落库
- `formSourceType=2` = 流程表单

### 发起流程

```json
{"dictData": {"mainTable": {"字段key": "值"}}}
```

- **必须包一层 `mainTable`**，平铺字段会报「请传入业务数据ID！」
- 子表必填字段的值要放进子表行：`dictData[子表名] = [{...}]`
- 键是 `bindingField` 真实列名，不是控件 code

### 绑起始表单（`POST /model/save`）

- 整个 `data` 原样回传，只改 `startFormId` / `phoneStartFormId`
- `formType` / `phoneFormType` 恒为 `"0"`
- 注意 save 会把 waypoint 坐标**取整** → 不能拿 XML 字节一致当校验

---

## 六、故障排查（实测记录）

### 6.1 新环境发起流程报 `token ALL`

```
INSERT ALL INTO ACT_HI_VARINST ... SELECT * FROM dual
```

Flowable 把 `databaseType` 误判成 Oracle，druid 解析报 `token ALL`。

**对照实验**：

| 场景 | 结果 |
| :--- | :--- |
| 新环境 + 我们迁的流程 | ❌ 失败 |
| 新环境 + **平台自带的**「项目管理策划」 | ❌ 同样失败 |
| 老环境 + 同一调用 | ✅ 成功 |

→ **环境级问题，不是流程配置问题**。需要运维修新环境 Flowable 的数据库类型。
修好之前**无法在本环境模拟跑数据、无法覆盖多分支**，这条只能等运维。

### 6.2 其他坑

| 现象 | 原因 | 处理 |
| :--- | :--- | :--- |
| `请勿重复提交!` / `重复提交了` | importModel 防重复提交 | 间隔 6~8s |
| `token ALL` | 见 6.1 | 找运维 |
| 「表单不存在」`code:900` | 引用的表单 ID 在本环境没有 | `clear_invalid_forms.py` 清掉 |
| 节点属性加不上 | `attr.modelId` 是旧环境的 | 从**线上**导出再改包 |
| nodeForms 不生效 | 缺 createTime/updateTime | 补时间戳 |
| 发布报「基础属性未填写」 | 该 userTask 没 nodeAttrs | `batch_fix_attrs.py` 补齐 |
| 设计器不显示节点 ID | nodeAttrs 缺 8 个表单字段 | 同上 |
| 导出后端点位置变了 | 平台把事件端点吸附到自己的圆边框 | 平台行为，非缺陷 |

---

## 七、工具用法

```bash
# 1. 全量补齐节点属性（nodeAttrs 8 字段 / nodeUsers / nodeForms）
python scripts/batch_fix_attrs.py --dry          # 先看清单
python scripts/batch_fix_attrs.py                # 真跑（间隔 6~8s）

# 2. 清理指向不存在表单的引用（起始表单 / 节点表单）
python scripts/clear_invalid_forms.py --dry
python scripts/clear_invalid_forms.py

# 3. 绑起始表单（动态表单 -> 流程「起始表单」，PC + 移动端）
python scripts/bind_form.py --list
python scripts/bind_form.py --flow PRP_CGLX --form <formId>
python scripts/bind_form.py --auto               # 按流程名自动匹配

# 4. 给每个 userTask 建节点表单
python scripts/bind_node_forms.py --list
python scripts/bind_node_forms.py --all

# 5. 全量校验
python scripts/check_nodes.py

# 6. 流程图几何体检 / 修复
python scripts/diagram.py 模型.zip
python scripts/check_diagram.py --host <host> --token <token>
```

---

## 八、批量执行约定

1. **逐个跑，不要并行写库**（importModel 有频率限制，服务也会抖）
2. 每个失败即记录并继续，最后统一出报告（卡在哪一步、缺什么）
3. 对不上的字段**明确列出，不硬编**
4. 全部完成后统一核对：定义唯一、按钮、列、回填、分支行为
5. **改完必须重新发布**——页面跑的是部署快照，改设计不发布等于没改
